import {
  T, K, FX, KNames,
  N_KIND, N_TYPE, N_FX, N_A, N_B, N_C,
  FN_ASYNC, FN_GENERATOR, FN_ASYNC_GENERATOR,
  CONVERT_RANGE_KNOWN, CONVERT_SIGNED, CONVERT_CHECKED
} from './ir.js';
import { TYPES, TYPE_NAMES, ITERATOR_TYPES } from './types.js';
import { appModuleIds } from './modules.js'; // sproutboat P6
import { ieee754_binary64 } from './encoding.js';

// C type per IR value type
const CT = [];
CT[T.none] = 'void';
CT[T.f64] = 'f64';
CT[T.i32] = 'i32';
CT[T.u32] = 'u32';
CT[T.i64] = 'i64';
CT[T.u64] = 'u64';
CT[T.jsval] = 'jsval';
CT[T.ptr] = 'u32';

// C precedence (higher binds tighter)
const P_COMMA = 1, P_TERNARY = 3, P_LOR = 4, P_LAND = 5, P_BOR = 6, P_BXOR = 7,
  P_BAND = 8, P_EQ = 9, P_REL = 10, P_SHIFT = 11, P_ADD = 12, P_MUL = 13,
  P_UNARY = 14, P_CAST = 15, P_POSTFIX = 16, P_PRIM = 17;

const BIN_PREC = {
  '*': P_MUL, '/': P_MUL, '%': P_MUL,
  '+': P_ADD, '-': P_ADD,
  '<<': P_SHIFT, '>>': P_SHIFT,
  '<': P_REL, '<=': P_REL, '>': P_REL, '>=': P_REL,
  '==': P_EQ, '!=': P_EQ,
  '&': P_BAND, '^': P_BXOR, '|': P_BOR,
  '&&': P_LAND, '||': P_LOR
};

const cReservedNames = new Set([
  'select', // sproutboat: glibc select: sys/select.h redeclares it
  'auto', 'break', 'case', 'char', 'const', 'continue', 'default', 'do', 'double',
  'else', 'enum', 'extern', 'float', 'for', 'goto', 'if', 'inline', 'int', 'long',
  'register', 'restrict', 'return', 'short', 'signed', 'sizeof', 'static', 'struct',
  'switch', 'typedef', 'union', 'unsigned', 'void', 'volatile', 'while',
  '_Alignas', '_Alignof', '_Atomic', '_BitInt', '_Bool', '_Complex', '_Generic', '_Imaginary', '_Noreturn', '_Static_assert', '_Thread_local',
  'alignas', 'alignof', 'constexpr', 'nullptr', 'static_assert', 'thread_local', 'typeof_unqual',
  '__alignof', '__alignof__', '__nullptr', '__typeof_unqual', '__typeof_unqual__',
  'asm', 'typeof', 'main', '_return', 'porf_fr', 'porf_frs',
  'i8', 'u8', 'i16', 'u16', 'i32', 'u32', 'i64', 'u64', 'f32', 'f64', 'jsval',
  'NULL', 'NAN', 'INFINITY',
  'stdin', 'stdout', 'stderr', 'FILE', 'EOF',
  'printf', 'fprintf', 'putchar', 'exit', 'abort', 'atexit', 'getenv',
  'calloc', 'malloc', 'realloc', 'free', 'memcpy', 'memmove', 'memset', 'strlen',
  'log', 'read', 'write', 'close', 'signal', 'time',
  // unistd / posix
  'fork', 'sleep', 'usleep', 'sync', '_exit', 'pipe', 'dup', 'dup2', 'pause',
  'alarm', 'getpid', 'getppid', 'open', 'link', 'unlink', 'access', 'kill', 'raise',
  // stdlib
  'random', 'srandom', 'rand', 'srand', 'system', 'abs', 'labs', 'div', 'ldiv',
  'qsort', 'bsearch', 'atoi', 'atol', 'atof', 'gets', 'remove', 'rename',
  // math (libm)
  'log2', 'log10', 'log1p', 'pow', 'sqrt', 'cbrt', 'exp', 'exp2', 'expm1',
  'sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'atan2', 'sinh', 'cosh', 'tanh',
  'fabs', 'floor', 'ceil', 'round', 'trunc', 'fmod', 'hypot', 'remainder',
  'clock', 'times', 'gmtime', 'localtime',
  'HUGE', 'HUGE_VAL', 'HUGE_VALF', 'HUGE_VALL', 'MAXFLOAT', 'FP_NAN', 'FP_INFINITE', 'FP_ZERO', 'FP_NORMAL', 'FP_SUBNORMAL',
  'M_E', 'M_LOG2E', 'M_LOG10E', 'M_LN2', 'M_LN10', 'M_PI', 'M_PI_2', 'M_PI_4', 'M_1_PI', 'M_2_PI', 'M_2_SQRTPI', 'M_SQRT2', 'M_SQRT1_2', 'errno',
  // string.h / strings.h (index is the big one: legacy strchr alias)
  'index', 'rindex', 'bcopy', 'bzero', 'bcmp', 'ffs', 'ffsl', 'ffsll', 'fls', 'flsl', 'flsll',
  'strcasecmp', 'strncasecmp', 'strcpy', 'strncpy', 'strcat', 'strncat', 'strcmp', 'strncmp',
  'strchr', 'strrchr', 'strstr', 'strtok', 'strdup', 'strndup', 'strerror', 'strspn', 'strcspn',
  'strpbrk', 'strcoll', 'strxfrm', 'strsep', 'stpcpy', 'stpncpy', 'strnlen', 'strlcpy', 'strlcat',
  'memchr', 'memcmp', 'memccpy', 'swab',
  // stdio
  'puts', 'fputs', 'fgets', 'fgetc', 'fputc', 'getc', 'putc', 'getchar', 'scanf', 'sscanf',
  'fscanf', 'snprintf', 'sprintf', 'vsnprintf', 'vsprintf', 'vprintf', 'vfprintf', 'fopen',
  'freopen', 'fclose', 'fread', 'fwrite', 'fseek', 'fseeko', 'ftell', 'ftello', 'rewind',
  'perror', 'tmpfile', 'tmpnam', 'setbuf', 'setvbuf', 'fflush', 'ungetc', 'feof', 'ferror',
  'clearerr', 'fileno', 'fdopen', 'popen', 'pclose',
  // setjmp / errno / predefined macros
  'setjmp', 'longjmp', '_setjmp', '_longjmp', 'sigsetjmp', 'siglongjmp', 'errno',
  'bool', 'true', 'false', 'unix', 'linux',
  // stdlib
  'strtol', 'strtoul', 'strtoll', 'strtoull', 'strtod', 'strtof', 'strtold', 'mblen', 'mbtowc',
  'wctomb', 'mbstowcs', 'wcstombs', 'realpath', 'mkstemp', 'mkdtemp', 'mktemp', 'setenv',
  'unsetenv', 'putenv', 'posix_memalign', 'aligned_alloc', 'arc4random', 'valloc', 'alloca',
  // math (libm) continued
  'acosh', 'asinh', 'atanh', 'erf', 'erfc', 'tgamma', 'lgamma', 'fmax', 'fmin', 'fma', 'fdim',
  'copysign', 'nearbyint', 'rint', 'lrint', 'llrint', 'lround', 'llround', 'frexp', 'ldexp',
  'modf', 'scalbn', 'scalbln', 'ilogb', 'logb', 'nan', 'nanf', 'nextafter', 'nexttoward',
  'remquo', 'j0', 'j1', 'jn', 'y0', 'y1', 'yn', 'gamma', 'drem', 'finite', 'significand',
  // signal
  'sigaction', 'sigaddset', 'sigdelset', 'sigemptyset', 'sigfillset', 'sigismember',
  'sigprocmask', 'sigsuspend', 'sigpending', 'sigwait', 'killpg', 'psignal',
  // unistd / posix continued
  'lseek', 'chdir', 'fchdir', 'getcwd', 'isatty', 'ttyname', 'execv', 'execve', 'execvp',
  'execl', 'execlp', 'execle', 'getuid', 'geteuid', 'getgid', 'getegid', 'setuid', 'setgid',
  'seteuid', 'setegid', 'getpgrp', 'setpgid', 'setsid', 'getsid', 'truncate', 'ftruncate',
  'rmdir', 'chown', 'fchown', 'lchown', 'readlink', 'symlink', 'nice', 'crypt', 'encrypt',
  'brk', 'sbrk', 'gethostname', 'sethostname', 'getlogin', 'fsync', 'fdatasync', 'pread',
  'pwrite', 'environ', 'getopt', 'optarg', 'optind', 'opterr', 'optopt', 'confstr', 'pathconf',
  'fpathconf', 'sysconf', 'chroot', 'vfork', 'daemon', 'setgroups', 'getgroups',
  // dirent
  'opendir', 'readdir', 'closedir', 'rewinddir', 'seekdir', 'telldir', 'scandir', 'alphasort',
  'dirfd', 'fdopendir',
  // sys/mman, sys/stat, sys/wait
  'mmap', 'munmap', 'mprotect', 'madvise', 'msync', 'mlock', 'munlock', 'mlockall',
  'munlockall', 'mincore', 'shm_open', 'shm_unlink',
  'stat', 'fstat', 'lstat', 'fstatat', 'chmod', 'fchmod', 'fchmodat', 'mkdir', 'mkdirat',
  'mkfifo', 'mknod', 'umask', 'futimens', 'utimensat',
  'wait', 'waitpid', 'wait3', 'wait4',
  // time.h continued
  'mktime', 'ctime', 'asctime', 'strftime', 'strptime', 'difftime', 'timegm', 'timelocal',
  'tzset', 'daylight', 'timezone', 'tzname', 'nanosleep', 'clock_gettime', 'clock_settime',
  'clock_getres', 'ctime_r', 'asctime_r', 'gmtime_r', 'localtime_r', 'gettimeofday'
]);

// inlining these has little perf benefit and significantly increases binary size
const NEVER_INLINE = new Set([
  '__Porffor_object_get_icMiss', '__Porffor_object_set_icMiss', '__Porffor_object_get_withHash', '__Porffor_array_holeGet',
  '__ecma262_ToNumeric', '__RegExp_prototype_exec'
]);

// hot property lookup helpers: inlined into the generic get/set paths
const ALWAYS_INLINE = new Set([
  '__Porffor_object_lookup', '__Porffor_object_lookupEntry', '__Porffor_object_hash', '__Porffor_object_underlyingPtr',
  '__Porffor_object_find', '__Porffor_object_shapeFind', '__Porffor_object_shapeDescriptors', '__Porffor_object_valueAt', '__Porffor_object_typeAt',
  '__Porffor_object_slotFlags', '__Porffor_object_slotValue', '__Porffor_object_slotWrite', '__Porffor_object_slotRead', '__Porffor_object_entryIs', '__Porffor_strcmp'
]);

const sanitizeMemo = new Map();
const sanitizeUsed = new Set();
export const sanitize = str => {
  const memod = sanitizeMemo.get(str);
  if (memod != null) return memod;

  let out = '';
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    const ok = (code >= 48 && code <= 57) || (code >= 65 && code <= 90) ||
      (code >= 97 && code <= 122) || code === 95;
    if (ok) out += String.fromCharCode(code);
      else out += '_' + code.toString(16);
  }
  if (out.length === 0) out = 'anon';
  if (out[0] >= '0' && out[0] <= '9') out = '_' + out;
  // keep prefixing: one '_' can itself collide (exit -> _exit), and all-caps names may be header macros (FALSE, ENOENT)
  while (cReservedNames.has(out) || /^[A-Z][A-Z0-9_]*$/.test(out) || sanitizeUsed.has(out)) out = '_' + out;
  sanitizeUsed.add(out);
  sanitizeMemo.set(str, out);
  return out;
};

// jsval encoding constants (must match runtime header below)
const JV_PATTERN = 0xFFF8000000000000n;
const jvConstBits = (typeId, payload) =>
  JV_PATTERN | (BigInt(typeId & 0xFF) << 43n) | BigInt(payload >>> 0);
const JV_ZERO_BITS = jvConstBits(TYPES.number, 0);

// lz4 block format, chained-hash lazy matching (~lz4hc ratio, ~25% smaller than greedy).
// used by --compress-data to shrink the static data image in the binary
const lz4Compress = src => {
  const n = src.length;
  const out = new Uint8Array(n + ((n / 255) | 0) + 16);
  const head = new Uint32Array(1 << 16);
  const prev = new Uint32Array(n);
  const read32 = i => src[i] | (src[i + 1] << 8) | (src[i + 2] << 16) | (src[i + 3] << 24);
  let op = 0, anchor = 0, i = 0, ins = 0, mLen = 0, mPos = 0;
  const mflimit = n - 12;

  const emitSeq = (litLen, offset, mlen) => {
    out[op++] = (Math.min(litLen, 15) << 4) | (offset === 0 ? 0 : Math.min(mlen - 4, 15));
    if (litLen >= 15) {
      let rest = litLen - 15;
      while (rest >= 255) { out[op++] = 255; rest -= 255; }
      out[op++] = rest;
    }
    for (let k = 0; k < litLen; k++) out[op++] = src[anchor + k];
    if (offset === 0) return;
    out[op++] = offset & 0xff;
    out[op++] = offset >> 8;
    if (mlen - 4 >= 15) {
      let rest = mlen - 4 - 15;
      while (rest >= 255) { out[op++] = 255; rest -= 255; }
      out[op++] = rest;
    }
  };

  const insertTo = limit => {
    while (ins < limit) {
      const h = (Math.imul(read32(ins), 2654435761) >>> 16) & 0xffff;
      prev[ins] = head[h];
      head[h] = ins + 1;
      ins++;
    }
  };

  const findMatch = at => {
    const maxLen = n - 5 - at;
    const minPos = at > 0xffff ? at - 0xffff : 0;
    let cand = head[(Math.imul(read32(at), 2654435761) >>> 16) & 0xffff] - 1;
    let depth = 64;
    mLen = 3;
    while (cand >= minPos && depth > 0) {
      depth--;
      if (src[cand + mLen] === src[at + mLen]) {
        let len = 0;
        while (len < maxLen && src[cand + len] === src[at + len]) len++;
        if (len > mLen) { mLen = len; mPos = cand; }
      }
      cand = prev[cand] - 1;
    }
  };

  while (i <= mflimit) {
    insertTo(i);
    findMatch(i);
    if (mLen < 4) { i++; continue; }
    let len = mLen, pos = mPos;
    while (i + 1 <= mflimit) { // lazy: prefer a longer match starting one byte later
      insertTo(i + 1);
      findMatch(i + 1);
      if (mLen > len) { i++; len = mLen; pos = mPos; }
        else break;
    }
    emitSeq(i - anchor, i - pos, len);
    i += len;
    anchor = i;
  }
  emitSeq(n - anchor, 0, 0);
  return { out, len: op };
};

// the executable's file, and where porf_data is in it, to map the image's pages from
const DATA_MAP = `#include <fcntl.h>
#if defined(__APPLE__) && !defined(__TINYC__)
#include <mach-o/ldsyms.h>
#endif
static int porf_data_file(off_t *off) {
#ifdef __TINYC__
  return -1;
#else
  if (sysconf(_SC_PAGESIZE) > 16384) return -1;
  char path[4096];
#ifdef __APPLE__
  uint32_t size = sizeof(path);
  if (_NSGetExecutablePath(path, &size) != 0) return -1;
  // __TEXT starts the file
  *off = (off_t)(porf_data - (const u8*)&_mh_execute_header);
#else
  // the mapping holding porf_data: its start, file offset and path
  FILE *maps = fopen("/proc/self/maps", "r");
  if (!maps) return -1;
  *off = -1;
  while (*off < 0 && fgets(path, sizeof(path), maps)) {
    unsigned long lo, hi, at;
    int name = 0;
    if (sscanf(path, "%lx-%lx %*s %lx %*s %*s %n", &lo, &hi, &at, &name) < 3 || name == 0 || (uintptr_t)porf_data < lo || (uintptr_t)porf_data >= hi) continue;
    memmove(path, path + name, strlen(path + name) + 1);
    path[strcspn(path, "\\n")] = 0;
    *off = (off_t)((uintptr_t)porf_data - lo + at);
  }
  fclose(maps);
  if (*off < 0) return -1;
#endif
  return open(path, O_RDONLY);
#endif
}

`;

const LZ4_DECODE = `static void porf_lz4_decode(const u8* src, u32 slen, u8* dst) {
  const u8* send = src + slen;
  while (src < send) {
    u32 token = *src++;
    u32 len = token >> 4;
    if (len == 15) { u32 b; do { b = *src++; len += b; } while (b == 255); }
    memcpy(dst, src, len); dst += len; src += len;
    if (src >= send) break;
    u32 off = src[0] | ((u32)src[1] << 8); src += 2;
    len = (token & 15) + 4;
    if (len == 19) { u32 b; do { b = *src++; len += b; } while (b == 255); }
    const u8* m = dst - off;
    while (len--) *dst++ = *m++;
  }
}

`;

const f64Lit = value => {
  if (Number.isNaN(value)) return 'NAN';
  if (value === Infinity) return 'INFINITY';
  if (value === -Infinity) return '-INFINITY';
  if (value === 0) return 1 / value === -Infinity ? '-0.0' : '0.0';

  const str = value.toString();
  if (Number.isInteger(value) && !/[eE]/.test(str)) return str.includes('.') ? str : str + '.0';

  const bytes = ieee754_binary64(value);
  let hex = '';
  for (let i = 7; i >= 0; i--) hex += bytes[i].toString(16).padStart(2, '0');
  return `porf_bits_to_f64(0x${hex}ull)`;
};

export default ({ funcs, data = [], dataUnits = [], globals = [], entry = null, prefs = {}, usedTypes = null, units = null, bigints = true }) => {
  // split: one C file per unit sharing a header, link-time constants as externs
  const split = !!prefs.split;
  const st = split ? '' : 'static ';

  const funcByName = new Map();
  for (const f of funcs) if (f) funcByName.set(f.name, f);
  const proxyCall = funcByName.get('__Porffor_proxy_call');
  const funcOf = ref => typeof ref === 'number' ? funcs[ref] : funcByName.get(ref);

  // contiguous function indices per unit in source order: fnbase_<unit> + local
  const unitOf = f => f.internal ? 'builtins' : f.unit ?? 'main';
  const funcsByUnit = new Map();
  for (const f of funcs) {
    if (!f) continue;
    if (!funcsByUnit.has(unitOf(f))) funcsByUnit.set(unitOf(f), []);
    funcsByUnit.get(unitOf(f)).push(f);
  }
  const unitOrder = [ 'builtins', ...(units ?? []).map(u => u.id) ];
  for (const u of funcsByUnit.keys()) if (u !== 'main' && !unitOrder.includes(u)) unitOrder.push(u);
  for (const u of dataUnits) if (u !== 'main' && !unitOrder.includes(u)) unitOrder.push(u);
  unitOrder.push('main');
  // sproutboat P2: app units last, pinned ABI regions
  { const appIds = (units ?? []).filter(u => appModuleIds.has(u.id)).map(u => u.id).filter(id => unitOrder.includes(id)); for (const id of appIds) unitOrder.splice(unitOrder.indexOf(id), 1); unitOrder.push(...appIds); }

  const linkFuncs = [], fnBase = {}, linkIdx = [];
  for (const u of unitOrder) {
    fnBase[u] = linkFuncs.length;
    const unitFuncs = funcsByUnit.get(u) ?? [];
    unitFuncs.sort((a, b) => (a.start ?? 1e9) - (b.start ?? 1e9) || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0) || a.index - b.index);
    for (const f of unitFuncs) {
      linkIdx[f.index] = linkFuncs.length;
      linkFuncs.push(f);
    }
  }

  const syms = [], symsUsed = Object.create(null);
  const fnSym = f => {
    let sym = syms[f.index];
    if (sym) return sym;
    sym = `p_${sanitize(unitOf(f))}_${sanitize(String(f.name))}`;
    while (symsUsed[sym]) sym += '_';
    symsUsed[sym] = true;
    syms[f.index] = sym;
    return sym;
  };
  // flags are derived here (only consumer), no stored func.flags. coroFlags = FN_* kind, fnFlags byte:
  // bits 0-2 coroutine kind, 3 callable (has return type), 4 constructor, 5 generator init suspension, 6 sloppy ordinary function
  const FN_CORO_INIT = 1 << 5;
  const coroKind = f => f?.async && f?.generator ? FN_ASYNC_GENERATOR : (f?.async ? FN_ASYNC : 0) | (f?.generator ? FN_GENERATOR : 0);
  const coroFlags = f => coroKind(f) | (f?.coroInit ? FN_CORO_INIT : 0);
  const isCoro = f => !!(f && (f.async || f.generator));
  const needsCoro = f => !!(f && (f.generator || (f.async && f.hasAwait)));
  const isSyncAsync = f => !!(f && f.async && !f.generator && !needsCoro(f));
  const fnFlags = f => f ? (coroFlags(f) | (f.returnType != null ? 1 << 3 : 0) | (f.constr ? 1 << 4 : 0) | (f.constr && !f.strict && !f.internal ? 1 << 6 : 0)) : 0;
  const jsArg = n => n[N_TYPE] === T.jsval ? rx(n, P_COMMA) : `porf_box_num(${rx(n, P_COMMA)})`;
  const packArg = n => `porf_pack(${jsArg(n)})`;

  // dynamic calls with few args pass them in registers to a per-func thunk
  const DYN_REGS = 6;
  const hasParam = (f, name) => f.params.some(p => p.name === name);
  const dynRegThunk = f => f.indirect && coroKind(f) === 0 && !hasParam(f, '#rest') && !hasParam(f, '#allargs');
  const dynRegs = (n = DYN_REGS) => Array.from({ length: n }, (_, j) => `jsval a${j}`);
  const dynCallParams = n => [ 'jsval fn', 'jsval thisv', ...dynRegs(n) ].join(', ');
  const dynThunkParams = [ 'u64 ra', 'jsval thisv', ...dynRegs() ].join(', ');
  let usesDynReg = false;

  let usesMath = false;
  let usesCoro = false;
  let usesSyncAsync = false;
  const gcEnabled = prefs.gc !== false;
  for (const f of funcs) {
    if (needsCoro(f)) usesCoro = true;
    if (isSyncAsync(f)) usesSyncAsync = true;
  }
  const promiseResolveFunc = funcByName.get('__Porffor_promise_resolve');
  const settleAsyncResult = promiseResolveFunc
    ? (value, promise) => `(void)${fnSym(promiseResolveFunc)}(${value}, ${promise});`
    : (value, promise) => `porf_promise_settle_direct(${promise}, ${value}, 1);`;
  // rejecting through the builtin tracks the promise for unhandled rejection reporting
  const promiseRejectFunc = funcByName.get('__ecma262_RejectPromise');
  const rejectAsyncResult = promiseRejectFunc
    ? (value, promise) => `(void)${fnSym(promiseRejectFunc)}(${promise}, ${value});`
    : (value, promise) => `porf_promise_settle_direct(${promise}, ${value}, 2);`;

  // static layout: one data block per unit, then function records, then name strings, then all-zero segments (not stored)
  const align8 = x => (x + 7) & ~7;
  const dataOffsets = [], dbase = {}, zbase = {};
  const zeroed = data.map(seg => !seg.staticArray && seg.every(b => b === 0));
  let off = 16; // 0 reserved (null), small pad
  const placeData = (bases, zero) => {
    for (const u of unitOrder) {
      bases[u] = off;
      // sproutboat P3: a unit's segments by content, not by creation order (which follows first use, and so the app)
      const ids = [];
      for (let i = 0; i < data.length; i++) if (dataUnits[i] === u && zeroed[i] === zero) ids.push(i);
      const keys = new Map();
      let prevKey = null, prevOff = 0;
      const key = i => { if (!keys.has(i)) { const seg = data[i]; keys.set(i, seg.staticArray ? 'A' + JSON.stringify(seg.staticArray.map(it => it.str !== undefined ? ['s', key(it.str)] : it)) : 'B' + Array.from(seg, b => String.fromCharCode(b)).join('')); } return keys.get(i); };
      if (!zero) ids.sort((x, y) => key(x) < key(y) ? -1 : key(x) > key(y) ? 1 : 0);
      for (const i of ids) {
        // P3b: identical immutable byte segments (string literals) share one offset, so equal-content ties cannot swap
        if (!zero && !data[i].staticArray && prevKey === key(i)) { dataOffsets[i] = prevOff; continue; }
        dataOffsets[i] = off; prevKey = zero ? null : key(i); prevOff = off;
        off += align8(data[i].length);
      }
    }
  };
  placeData(dbase, false);
  if (off >= 1048576) throw new Error('static data exceeds module ABI region');
  const fnrecBase = 1048576; off = fnrecBase;
  off += linkFuncs.length * 8;
  const builtinName = name => {
    const accessor = name.match(/\$([gs]et)$/)?.[1];
    if (accessor) name = name.slice(0, -4);
    const proto = name.indexOf('_prototype_');
    const owner = name.indexOf('_', 2);
    name = proto !== -1 ? name.slice(proto + 11) : owner !== -1 ? name.slice(owner + 1) : name.slice(2);
    if (name.startsWith('Symbol_')) name = `[Symbol.${name.slice(7)}]`;
    return accessor ? `${accessor} ${name}` : name;
  };

  if (linkFuncs.length >= 65536) throw new Error('function capacity exceeded');
  off = 2097152;
  // empty names reuse offset 0 (0-length bytestring in the null region)
  const fnNameSegs = [];
  const fnNameOff = [];
  for (const f of linkFuncs) {
    const name = f.jsName ?? (f.name.startsWith('__') ? builtinName(f.name) : f.name.split('#')[0]);
    if (name.length === 0) { fnNameOff.push(0); continue; }
    const bytes = [ name.length & 0xff, (name.length >>> 8) & 0xff, (name.length >>> 16) & 0xff, (name.length >>> 24) & 0xff ];
    for (let k = 0; k < name.length; k++) bytes.push(name.charCodeAt(k) & 0xff);
    fnNameOff.push(off);
    fnNameSegs.push({ off, bytes });
    off += align8(bytes.length);
  }
  const imageEnd = off;
  if (off >= 4194304) throw new Error('function names exceed module ABI region');
  off = 4194304;
  placeData(zbase, true);
  const staticEnd = off;

  // per-unit output and what it references (externs and prototypes in split mode)
  const unitParts = Object.create(null);
  const partsOf = u => unitParts[u] ??= { out: [], chunks: [], protos: [], globals: Object.create(null), fnbases: Object.create(null), dbases: Object.create(null), zbases: Object.create(null) };
  let cur = partsOf('main');
  let emitBuf = null;
  const emit = s => {
    if (emitBuf) { emitBuf.push(s); return; }
    cur.out.push(s);
    if (cur.out.length === 4096) {
      cur.chunks.push(cur.out.join(''));
      cur.out.length = 0;
    }
  };

  const fnIdxExpr = f => {
    // tree-shaken func captured by a closure: traps if ever called
    if (!f) return '0xffffffffu';
    if (!split) return `${linkIdx[f.index]}u`;
    const u = unitOf(f);
    cur.fnbases[u] = true;
    return `(porf_fnbase_${sanitize(u)} + ${linkIdx[f.index] - fnBase[u]}u)`;
  };

  let depth = 1;
  const ind = () => '\t'.repeat(depth);

  // break/continue lower to plain C when targeting the innermost breakable, else goto,
  // labels are only emitted when goto'd
  const loopStack = [];
  const breakStack = [];
  // try depth at each label so a break or continue leaving a try body can unwind porf_try_depth
  const labelTry = new Map();
  let activeTryDepth = 0;
  let usedLabels = new Set();

  const paren = (s, p, need) => p < need ? `(${s})` : s;

  const isNode = node => Array.isArray(node) && typeof node[0] === 'number' &&
    KNames[node[0]] !== undefined && node.length === 6;

  // a naked break here would bind to the enclosing C construct (loops/switches rebind it: don't descend)
  const hasNakedBreak = node => {
    if (!Array.isArray(node)) return false;
    if (isNode(node)) {
      const k = node[N_KIND];
      if (k === K.Break) return !node[N_A];
      if (k === K.Loop || k === K.Switch || k === K.TypeSwitch) return false;
      return hasNakedBreak(node[N_A]) || hasNakedBreak(node[N_B]) || hasNakedBreak(node[N_C]);
    }
    return node.some(hasNakedBreak);
  };

  const hasRawC = node => {
    if (!Array.isArray(node)) return false;
    if (isNode(node)) {
      if (node[N_KIND] === K.RawC) return true;
      return hasRawC(node[N_A]) || hasRawC(node[N_B]) || hasRawC(node[N_C]);
    }
    return node.some(hasRawC);
  };

  // a leading simple test that returns is inlined before direct calls
  const guards = [];
  const guardOf = f => {
    if (guards[f.index] !== undefined) return guards[f.index];
    const s = f.body?.[0];
    const params = new Set(f.params.map(p => p.name));
    let size = 0;
    const simple = n => {
      if (!Array.isArray(n)) return true;
      if (!isNode(n)) return n.every(simple);
      if (++size > 16 || n[N_KIND] === K.RawC || (n[N_FX] & (FX.call | FX.writeMem | FX.writeLocal)) !== 0) return false;
      if (n[N_KIND] === K.Local && !params.has(n[N_A])) return false;
      return simple(n[N_A]) && simple(n[N_B]) && simple(n[N_C]);
    };
    return guards[f.index] = !isCoro(f) && isNode(s) && s[N_KIND] === K.If && !s[N_C]?.length &&
      s[N_B].length === 1 && isNode(s[N_B][0]) && s[N_B][0][N_KIND] === K.Return && simple(s[N_A]) && simple(s[N_B][0][N_A]) ? s : null;
  };

  // code after these in a list is unreachable
  const TERMINATOR_KINDS = new Set([ K.Return, K.Throw, K.ThrowNew, K.Unreachable, K.Break, K.Continue ]);

  const renderExpr = node => {
    switch (node[N_KIND]) {
      case K.Const: {
        const t = node[N_TYPE], v = node[N_A];
        if (t === T.jsval) return [`porf_box_num(${f64Lit(v)})`, P_POSTFIX]; // number jsval = its f64 bits
        if (t === T.f64) return [f64Lit(v), v < 0 ? P_UNARY : P_PRIM];
        if (t === T.i64) return [`${v}ll`, v < 0 ? P_UNARY : P_PRIM];
        if (t === T.u64) return [`${v}ull`, P_PRIM];
        if (t === T.u32 || t === T.ptr) return [`${v >>> 0}u`, P_PRIM];
        return [String(v | 0), v < 0 ? P_UNARY : P_PRIM];
      }

      case K.JvConst:
        return [`porf_box((f64)${node[N_B] >>> 0}u, ${node[N_A]})`, P_POSTFIX];

      case K.DataRef: {
        const id = node[N_A];
        if (!split) return [`${dataOffsets[id]}u`, P_PRIM];
        const u = dataUnits[id];
        if (zeroed[id]) {
          cur.zbases[u] = true;
          return [`(porf_zbase_${sanitize(u)} + ${dataOffsets[id] - zbase[u]}u)`, P_PRIM];
        }
        cur.dbases[u] = true;
        return [`(porf_dbase_${sanitize(u)} + ${dataOffsets[id] - dbase[u]}u)`, P_PRIM];
      }

      case K.FuncIdx:
        return [fnIdxExpr(funcOf(node[N_A])), P_PRIM];
      case K.FuncRec: {
        const f = funcOf(node[N_A]);
        return [split ? `(porf_fnrecs + ${fnIdxExpr(f)} * 8u)` : `${fnrecBase + linkIdx[f.index] * 8}u`, P_PRIM];
      }

      case K.Global:
        cur.globals[node[N_A]] = true;
      case K.Local:
        return [sanitize(node[N_A]), P_PRIM];

      case K.Bin: {
        const op = node[N_A], t = node[N_B][N_TYPE] === T.none ? node[N_TYPE] : node[N_B][N_TYPE];
        // special spellings
        if (op === 'rotl' || op === 'rotr') {
          const fn = (t === T.i64 || t === T.u64) ? `porf_${op}64` : `porf_${op}32`;
          return [`${fn}(${rx(node[N_B], P_COMMA)}, ${rx(node[N_C], P_COMMA)})`, P_POSTFIX];
        }
        if (op === 'min' || op === 'max' || op === 'copysign') {
          usesMath = true;
          const fn = op === 'copysign' ? 'copysign' : `porf_f64_${op}`;
          return [`${fn}(${rx(node[N_B], P_COMMA)}, ${rx(node[N_C], P_COMMA)})`, P_POSTFIX];
        }
        if (op === '%' && t === T.f64) {
          usesMath = true;
          return [`porf_mod(${rx(node[N_B], P_COMMA)}, ${rx(node[N_C], P_COMMA)})`, P_POSTFIX];
        }
        if ((op === '==' || op === '!=') && (node[N_B][N_TYPE] === T.jsval || node[N_C][N_TYPE] === T.jsval)) {
          const eq = `porf_jv_eq(${rx(node[N_B], P_COMMA)}, ${rx(node[N_C], P_COMMA)})`;
          return [op === '==' ? eq : `!${eq}`, op === '==' ? P_POSTFIX : P_UNARY];
        }
        const prec = BIN_PREC[op];
        const ct = CT[node[N_B][N_TYPE]] ?? CT[node[N_TYPE]];
        let l = rx(node[N_B], prec);
        let r = rx(node[N_C], prec + 1);
        if (op === '<<' || op === '>>') {
          if (node[N_B][N_KIND] === K.Bin && BIN_PREC[node[N_B][N_A]] === P_ADD) l = `(${l})`;
          if (node[N_C][N_KIND] === K.Bin && BIN_PREC[node[N_C][N_A]] === P_ADD) r = `(${r})`;
        }
        // shifts: C UB on overshift; IR guarantees masked shift via codegen
        return [`${l} ${op} ${r}`, prec];
      }

      case K.Un: {
        const op = node[N_A], v = node[N_B];
        switch (op) {
          case 'neg': return [`-${rx(v, P_CAST)}`, P_UNARY];
          case '!': return [`!${rx(v, P_UNARY)}`, P_UNARY];
          case '~': return [`~${rx(v, P_UNARY)}`, P_UNARY];
          case 'abs': usesMath = true; return [`fabs(${rx(v, P_COMMA)})`, P_POSTFIX];
          case 'floor': case 'ceil': case 'trunc': case 'sqrt':
            usesMath = true; return [`${op}(${rx(v, P_COMMA)})`, P_POSTFIX];
          case 'round': usesMath = true; return [`porf_round(${rx(v, P_COMMA)})`, P_POSTFIX];
          case 'nearest': usesMath = true; return [`porf_nearest(${rx(v, P_COMMA)})`, P_POSTFIX];
          case 'clz': return [`porf_clz32(${rx(v, P_COMMA)})`, P_POSTFIX];
          case 'ctz': return [`porf_ctz32(${rx(v, P_COMMA)})`, P_POSTFIX];
          case 'popcnt': return [`__builtin_popcount(${rx(v, P_COMMA)})`, P_POSTFIX];
          case 'touint32': usesMath = true; return [`porf_to_uint32(${rx(v, P_COMMA)})`, P_POSTFIX];
        }
        throw new Error(`render: unknown unary op ${op}`);
      }

      case K.Select:
        return [`${rx(node[N_A], P_LOR)} ? ${rx(node[N_B], P_TERNARY)} : ${rx(node[N_C], P_TERNARY)}`, P_TERNARY];

      case K.Convert: {
        const to = node[N_TYPE], from = node[N_A], v = node[N_B], flags = node[N_C];
        // f64 -> int without range knowledge: saturate (JS ToInt semantics live above this)
        if (from === T.f64 && (to === T.i32 || to === T.u32 || to === T.ptr) && !(flags & CONVERT_RANGE_KNOWN)) {
          // an int that went through f64 clamps as an int
          if (v[N_KIND] === K.Convert && (v[N_A] === T.i32 || v[N_A] === T.u32 || v[N_A] === T.ptr)) {
            const signed = v[N_A] === T.i32;
            if (signed === (to === T.i32)) return [`(${CT[to]})${rx(v[N_B], P_CAST)}`, P_CAST];
            return [`${signed ? 'porf_i32_to_u32' : 'porf_u32_to_i32'}(${rx(v[N_B], P_COMMA)})`, P_POSTFIX];
          }
          if (flags & CONVERT_CHECKED) return [`porf_sat_u32(${rx(v, P_COMMA)})`, P_POSTFIX];
          return [`${to === T.i32 ? 'porf_f64_to_i32' : 'porf_f64_to_u32'}(${rx(v, P_COMMA)})`, P_POSTFIX];
        }
        if (to === T.f64 && (from === T.u32 || from === T.ptr) && !(flags & CONVERT_SIGNED)) {
          return [`(f64)${rx(v, P_CAST)}`, P_CAST];
        }
        return [`(${CT[to]})${rx(v, P_CAST)}`, P_CAST];
      }

      case K.Reinterpret:
        if (node[N_B] === 'bitsToF32') return [`porf_bits_to_f32(${rx(node[N_A], P_COMMA)})`, P_POSTFIX];
        if (node[N_B] === 'f32ToBits') return [`porf_f32_to_bits(${rx(node[N_A], P_COMMA)})`, P_POSTFIX];
        return [node[N_TYPE] === T.f64
          ? `porf_bits_to_f64(${rx(node[N_A], P_COMMA)})`
          : `porf_f64_to_bits(${rx(node[N_A], P_COMMA)})`, P_POSTFIX];

      case K.Canon:
        return [`porf_canon(${rx(node[N_A], P_COMMA)})`, P_POSTFIX];

      case K.Box: {
        const v = node[N_A], tExpr = node[N_B];
        const payload = v[N_TYPE] === T.jsval ? `(${rx(v, P_POSTFIX)}.val)` : rx(v, P_COMMA);
        if (tExpr[N_KIND] === K.Const) {
          const tid = tExpr[N_A];
          if (tid === TYPES.number) return [`porf_box_num(${payload})`, P_POSTFIX];
          return [`porf_box(${payload}, ${tid})`, P_POSTFIX];
        }
        return [`porf_box(${payload}, ${rx(tExpr, P_COMMA)})`, P_POSTFIX];
      }
      case K.JvType: return [`porf_jv_type(${rx(node[N_A], P_COMMA)})`, P_POSTFIX];
      case K.JvNum: return [`(${rx(node[N_A], P_POSTFIX)}.val)`, P_POSTFIX];
      case K.JvPtr: return [`(u32)${rx(node[N_A], P_POSTFIX)}.val`, P_CAST];
      case K.JvBits: return [`porf_pack(${rx(node[N_A], P_COMMA)})`, P_POSTFIX];
      case K.JvFromBits: return [`porf_unpack(${rx(node[N_A], P_COMMA)})`, P_POSTFIX];
      case K.JvIsNum: return [`porf_jv_is_num(${rx(node[N_A], P_COMMA)})`, P_POSTFIX];
      case K.Eq: return [`${node[N_A] === 2 ? 'porf_loose_eq_raw' : node[N_A] ? 'porf_strict_eq' : 'porf_loose_eq'}(${jsArg(node[N_B])}, ${jsArg(node[N_C])})`, P_POSTFIX];
      case K.Add: return [`porf_add(${jsArg(node[N_A])}, ${jsArg(node[N_B])})`, P_POSTFIX];
      case K.Cmp: return [`porf_cmp(${jsArg(node[N_A])}, ${jsArg(node[N_B])})`, P_POSTFIX];
      case K.JvTruthy: return [`porf_truthy(${jsArg(node[N_A])})`, P_POSTFIX];
      case K.JvFalsy: return [`porf_falsy(${jsArg(node[N_A])})`, P_POSTFIX];
      case K.JvNullish: return [`porf_nullish(${jsArg(node[N_A])})`, P_POSTFIX];

      case K.Load: {
        const ctype = node[N_A];
        const [off, unaligned] = node[N_C];
        const addr = `MEM + ${rx(node[N_B], P_ADD)}${off ? ` + ${off}u` : ''}`;
        if (unaligned) {
          // signed unaligned: load unsigned width, cast (u8/i8 are always aligned)
          if (ctype === 'i16') return [`(int16_t)porf_load_un_u16(${addr})`, P_CAST];
          if (ctype === 'i32') return [`(i32)porf_load_un_u32(${addr})`, P_CAST];
          if (ctype === 'i64') return [`(i64)porf_load_un_u64(${addr})`, P_CAST];
          if (ctype === 'jsval') return [`porf_unpack(porf_load_un_u64(${addr}))`, P_POSTFIX];
          return [`porf_load_un_${ctype}(${addr})`, P_POSTFIX];
        }
        if (ctype === 'jsval') return [`porf_unpack(*(jsbits*)(${addr}))`, P_POSTFIX];
        return [`*(${ctype === 'i8' ? 'int8_t' : ctype === 'i16' ? 'int16_t' : ctype}*)(${addr})`, P_UNARY];
      }

      case K.Call: {
        if (node[N_A] === '__Porffor_coroutine_resume' || node[N_A] === '__Porffor_coroutine_value') usesCoro = true;
        const f = funcOf(node[N_A]);
        if (f) cur.protos[f.index] = f;
        // direct call to a coroutine starts it instead of running the body: split args into the invocation shape
        if (f && isCoro(f)) {
          let callee = 'JV_UNDEFINED', env = '0', thisv = 'JV_UNDEFINED', newtv = 'JV_UNDEFINED';
          const rawArgv = Array.isArray(node[N_C]) ? node[N_C] : null;
          const argv = rawArgv ?? [];
          node[N_B].forEach((a, i) => {
            const s = rx(a, P_COMMA), pn = f.params[i]?.name;
            if (pn === '#callee') callee = s;
            else if (pn === '#env') env = s;
            else if (pn === '#this') thisv = s;
            else if (pn === '#newtarget') newtv = s;
            else if (!rawArgv) argv.push(a);
          });
          // static (envless) generators still know their function: instances get its .prototype
          if (callee === 'JV_UNDEFINED' && f.generator && !f.params.some(p => p.name === '#env'))
            callee = `porf_box((f64)(${split ? `porf_fnrecs + ${fnIdxExpr(f)} * 8u` : `${fnrecBase + linkIdx[f.index] * 8}u`}), ${TYPES.function})`;
          const argvArr = argv.length ? `(jsbits[]){ ${argv.map(a => packArg(a)).join(', ')} }` : '(jsbits[]){JV_UNDEFINED_BITS}';
          return [needsCoro(f)
            ? `porf_coro_start(${coroFlags(f)}u, ${fnIdxExpr(f)}, ${callee}, ${env}, ${thisv}, ${newtv}, ${argv.length}, ${argvArr})`
            : `porf_async_call_sync(${fnIdxExpr(f)}, ${callee}, ${env}, ${thisv}, ${newtv}, ${argv.length}, ${argvArr})`, P_POSTFIX];
        }
        const name = f ? fnSym(f) + (guardOf(f) ? '_g' : '') : sanitize(String(node[N_A]));
        const args = node[N_B].map(a => rx(a, P_COMMA)).join(', ');
        return [`${name}(${args})`, P_POSTFIX];
      }

      case K.StrJoin:
        return [`porf_str_join(${node[N_A].length}, (jsval[]){ ${node[N_A].map(jsArg).join(', ')} })`, P_POSTFIX];

      case K.CallDynamic: {
        const [args, newTarget, spreadArr] = node[N_C];
        const newt = newTarget ? rx(newTarget, P_COMMA) : 'JV_UNDEFINED';
        if (spreadArr) {
          return [`porf_call_dynamic_arr(${rx(node[N_A], P_COMMA)}, ${rx(node[N_B], P_COMMA)}, ${newt}, ${rx(spreadArr, P_COMMA)})`, P_POSTFIX];
        }
        if (!newTarget && args.length <= DYN_REGS) {
          usesDynReg = true;
          return [`porf_call${args.length}(${[ node[N_A], node[N_B] ].map(a => rx(a, P_COMMA)).concat(args.map(jsArg)).join(', ')})`, P_POSTFIX];
        }
        const argv = args.length === 0 ? '(jsbits[]){JV_UNDEFINED_BITS}'
          : `(jsbits[]){ ${args.map(packArg).join(', ')} }`;
        return [`porf_call_dynamic(${rx(node[N_A], P_COMMA)}, ${rx(node[N_B], P_COMMA)}, ${newt}, ${args.length}, ${argv})`, P_POSTFIX];
      }

      case K.Await:
      case K.Yield:
        throw new Error(`render: ${KNames[node[N_KIND]]} outside a coroutine body`);

      case K.Alloc: return [`porf_alloc(${rx(node[N_A], P_COMMA)}, ${node[N_B]}u)`, P_POSTFIX];

      case K.ArrGet: return [`porf_arr_get(${rx(node[N_A], P_COMMA)}, ${rx(node[N_B], P_COMMA)})`, P_POSTFIX];
      case K.LenGet: return [`*(i32*)(MEM + ${rx(node[N_A], P_ADD)})`, P_UNARY];

      default:
        throw new Error(`render: cannot render ${KNames[node[N_KIND]]} as expression`);
    }
  };

  const rx = (node, need) => {
    const [code, prec] = renderExpr(node);
    return paren(code, prec, need);
  };

  const renderStmts = stmts => {
    for (let i = 0; i < stmts.length; i++) {
      const s = stmts[i];
      renderStmt(s);
      if (s != null && isNode(s) && TERMINATOR_KINDS.has(s[N_KIND]) &&
          !stmts.slice(i + 1).some(hasRawC)) return;
    }
  };

  const renderStmt = node => {
    if (node == null) return;
    switch (node[N_KIND]) {
      case K.Assign:
        if (coro && isSuspend(node[N_B])) return renderSuspend(node[N_A], node[N_B]);
        if (node[N_A][N_KIND] === K.Global) cur.globals[node[N_A][N_A]] = true;
        emit(`${ind()}${sanitize(node[N_A][N_A])} = ${rx(node[N_B], P_COMMA)};\n`);
        return;

      case K.Store: {
        const ctype = node[N_A];
        const [off, unaligned, value] = node[N_C];
        const addr = `MEM + ${rx(node[N_B], P_ADD)}${off ? ` + ${off}u` : ''}`;
        if (unaligned) {
          const un = { i16: 'u16', i32: 'u32', i64: 'u64', jsval: 'u64' }[ctype] ?? ctype;
          emit(`${ind()}porf_store_un_${un}(${addr}, ${ctype === 'jsval' ? packArg(value) : rx(value, P_COMMA)});\n`);
        } else if (ctype === 'jsval') emit(`${ind()}*(jsbits*)(${addr}) = ${packArg(value)};\n`);
          else emit(`${ind()}*(${ctype === 'i8' ? 'int8_t' : ctype === 'i16' ? 'int16_t' : ctype}*)(${addr}) = ${rx(value, P_COMMA)};\n`);
        return;
      }

      case K.MemCopy: {
        const [bytes, mayOverlap] = node[N_C];
        emit(`${ind()}${mayOverlap ? 'memmove' : 'memcpy'}(MEM + ${rx(node[N_A], P_ADD)}, MEM + ${rx(node[N_B], P_ADD)}, ${rx(bytes, P_COMMA)});\n`);
        return;
      }

      case K.MemFill:
        emit(`${ind()}memset(MEM + ${rx(node[N_A], P_ADD)}, ${rx(node[N_B], P_COMMA)}, ${rx(node[N_C], P_COMMA)});\n`);
        return;

      case K.If: {
        emit(`${ind()}if (${rx(node[N_A], P_COMMA)}) {\n`);
        depth++; renderStmts(node[N_B]); depth--;
        if (node[N_C] && node[N_C].length) {
          emit(`${ind()}} else {\n`);
          depth++; renderStmts(node[N_C]); depth--;
        }
        emit(`${ind()}}\n`);
        return;
      }

      case K.Loop: {
        const cond = node[N_A], update = node[N_B];
        const [stmts, label] = node[N_C];
        const updateC = update == null ? null
          : update[N_KIND] === K.Assign
            ? `${sanitize(update[N_A][N_A])} = ${rx(update[N_B], P_COMMA)}`
            : rx(update, P_COMMA);
        // resume through the header, a second loop entry would make the cfg irreducible
        const region = coro && hasSuspend(stmts) ? { id: coro.regions.length, cases: [] } : null;
        if (region) {
          coro.regions.push(region);
          emit(`${ind()}_porf_t${region.id}:\n`);
          emit(`${ind()}for (;; ${updateC ?? ''}) {\n`);
          emit(`${ind()}\tif (porf_fr->resume) switch (porf_fr->resume) {\x00${region.id}\x00}\n`);
          if (cond) emit(`${ind()}\telse if (!(${rx(cond, P_COMMA)})) break;\n`);
          coro.path.push(region);
        } else if (update) emit(`${ind()}for (; ${cond ? rx(cond, P_COMMA) : ''}; ${updateC}) {\n`);
          else if (cond) emit(`${ind()}while (${rx(cond, P_COMMA)}) {\n`);
        else emit(`${ind()}while (1) {\n`);
        loopStack.push(label);
        breakStack.push(label);
        if (label) labelTry.set(label, activeTryDepth);
        depth++;
        renderStmts(stmts);
        if (region) coro.path.pop();
        if (label && usedLabels.has(label + '_c')) emit(`${ind()}${sanitize(label)}_c:;\n`);
        depth--;
        breakStack.pop();
        loopStack.pop();
        emit(`${ind()}}\n`);
        if (label && usedLabels.has(label + '_b')) emit(`${ind()}${sanitize(label)}_b:;\n`);
        return;
      }

      case K.Break: {
        const target = labelTry.get(node[N_A]);
        if (activeTryDepth > target) emit(`${ind()}porf_try_depth -= ${activeTryDepth - target};\n`);
        if (node[N_A] && node[N_A] !== breakStack[breakStack.length - 1]) {
          usedLabels.add(node[N_A] + '_b');
          emit(`${ind()}goto ${sanitize(node[N_A])}_b;\n`);
        } else emit(`${ind()}break;\n`);
        return;
      }

      case K.Continue: {
        const target = labelTry.get(node[N_A]);
        if (activeTryDepth > target) emit(`${ind()}porf_try_depth -= ${activeTryDepth - target};\n`);
        if (node[N_A] && node[N_A] !== loopStack[loopStack.length - 1]) {
          usedLabels.add(node[N_A] + '_c');
          emit(`${ind()}goto ${sanitize(node[N_A])}_c;\n`);
        } else emit(`${ind()}continue;\n`);
        return;
      }

      case K.Block: {
        if (node[N_A].length === 0 && !node[N_B]) return;
        // left-nested blocks (lowered switches) go thousands deep, so the inner ones render flat
        const chain = [ node ];
        for (let first = node[N_A][0]; isNode(first) && first[N_KIND] === K.Block; first = first[N_A][0]) chain.push(first);
        for (const block of chain) if (block[N_B]) labelTry.set(block[N_B], activeTryDepth);
        emit(`${ind()}{\n`);
        depth++;
        for (let i = chain.length - 1; i >= 0; i--) {
          const block = chain[i];
          renderStmts(i === chain.length - 1 ? block[N_A] : block[N_A].slice(1));
          if (i > 0 && block[N_B] && usedLabels.has(block[N_B] + '_b')) emit(`${ind()}${sanitize(block[N_B])}_b:;\n`);
        }
        depth--;
        emit(`${ind()}}\n`);
        if (node[N_B] && usedLabels.has(node[N_B] + '_b')) emit(`${ind()}${sanitize(node[N_B])}_b:;\n`);
        return;
      }

      case K.Switch:
      case K.TypeSwitch: {
        const isType = node[N_KIND] === K.TypeSwitch;
        const subj = node[N_A];
        const kept = [];
        for (const [values, stmts, fallthrough] of node[N_B]) {
          const vals = isType && usedTypes ? values.filter(v => usedTypes.has(v)) : values;
          if (vals.length !== 0) kept.push([ vals, stmts, fallthrough ]);
        }
        const def = node[N_C] && node[N_C].length ? node[N_C] : null;

        // 0/1 surviving cases: if/else instead of switch. blocked by a naked break (must
        // bind to the switch) and re-evaluation hazards: dropping the subject needs it
        // effect-free, repeating it (multi-value condition) needs it trivial
        const subjTrivial = subj[N_KIND] === K.Local || subj[N_KIND] === K.Global || subj[N_KIND] === K.Const;
        if (kept.length <= 1 &&
            !hasNakedBreak(kept.length ? kept[0][1] : null) && !hasNakedBreak(def) &&
            (kept.length === 1
              ? kept[0][0].length === 1 || subjTrivial
              : (subj[N_FX] & (FX.call | FX.writeMem | FX.writeLocal)) === 0)) {
          if (kept.length === 0) {
            if (def) renderStmts(def);
            return;
          }
          const [ vals, stmts, fallthrough ] = kept[0];
          const subjS = () => isType && subj[N_TYPE] === T.jsval ? `porf_jv_type(${rx(subj, P_COMMA)})` : rx(subj, P_EQ + 1);
          emit(`${ind()}if (${vals.map(v => `${subjS()} == ${v}`).join(' || ')}) {\n`);
          depth++; renderStmts(stmts); depth--;
          if (def && !fallthrough) {
            emit(`${ind()}} else {\n`);
            depth++; renderStmts(def); depth--;
          }
          emit(`${ind()}}\n`);
          if (def && fallthrough) renderStmts(def);
          return;
        }

        const subjCode = isType && subj[N_TYPE] === T.jsval ? `porf_jv_type(${rx(subj, P_COMMA)})` : rx(subj, P_COMMA);
        emit(`${ind()}switch (${subjCode}) {\n`);
        breakStack.push(null);
        depth++;
        for (const [vals, stmts, fallthrough] of kept) {
          emit(ind());
          for (const v of vals) emit(`case ${v}: `);
          emit('{\n');
          depth++; renderStmts(stmts); depth--;
          emit(`${ind()}}\n`);
          if (!fallthrough) emit(`${ind()}break;\n`);
        }
        if (def) {
          emit(`${ind()}default:\n${ind()}{\n`);
          depth++; renderStmts(def); depth--;
          emit(`${ind()}}\n`);
        }
        depth--;
        breakStack.pop();
        emit(`${ind()}}\n`);
        return;
      }

      case K.Return:
        if (activeTryDepth !== 0 && node[N_A]) {
          emit(`${ind()}{\n`);
          depth++;
          emit(`${ind()}${CT[node[N_A][N_TYPE]]} _return = ${rx(node[N_A], P_COMMA)};\n`);
          emit(`${ind()}porf_try_depth -= ${activeTryDepth};\n`);
          emit(`${ind()}return _return;\n`);
          depth--;
          emit(`${ind()}}\n`);
          return;
        }
        if (activeTryDepth !== 0) emit(`${ind()}porf_try_depth -= ${activeTryDepth};\n`);
        emit(node[N_A] ? `${ind()}return ${rx(node[N_A], P_COMMA)};\n` : `${ind()}return;\n`);
        return;

      case K.Unreachable:
        emit(`${ind()}porf_unreachable(${node[N_A] ? JSON.stringify(String(node[N_A])) : '0'});\n`);
        return;

      case K.Try: {
        // resume re-enters the try from the top to re-arm its jmp_buf
        const region = coro && hasSuspend(node[N_A]) ? { id: coro.regions.length, cases: [] } : null;
        emit(`${ind()}{\n`);
        depth++;
        if (region) {
          coro.regions.push(region);
          emit(`${ind()}_porf_t${region.id}:;\n`);
        }
        emit(`${ind()}porf_try_depth++;\n`);
        emit(`${ind()}if (_setjmp(porf_try_ensure()[porf_try_depth - 1]) == 0) {\n`);
        activeTryDepth++;
        depth++;
        if (region) {
          emit(`${ind()}if (porf_fr->resume) switch (porf_fr->resume) {\x00${region.id}\x00}\n`);
          coro.path.push(region);
        }
        renderStmts(node[N_A]);
        if (region) coro.path.pop();
        activeTryDepth--;
        emit(`${ind()}porf_try_depth--;\n`);
        depth--;
        emit(`${ind()}} else {\n`);
        depth++;
        emit(`${ind()}porf_try_depth--;\n`);
        emit(`${ind()}${coro ? '' : 'jsval '}${sanitize(node[N_B])} = porf_exception;\n`);
        renderStmts(node[N_C]);
        depth--;
        emit(`${ind()}}\n`);
        depth--;
        emit(`${ind()}}\n`);
        return;
      }

      case K.Throw:
        emit(`${ind()}porf_throw(${rx(node[N_A], P_COMMA)});\n`);
        return;

      case K.ThrowNew:
        emit(`${ind()}porf_throw_new(${node[N_A]}, ${rx(node[N_B], P_COMMA)});\n`);
        return;

      case K.GcBarrier:
        if (node[N_C]) emit(`${ind()}porf_gc_card(${rx(node[N_A], P_COMMA)});\n`);
          else emit(`${ind()}porf_gc_barrier(${rx(node[N_A], P_COMMA)}, ${rx(node[N_B], P_COMMA)});\n`);
        return;

      case K.ArrSet:
        emit(`${ind()}porf_arr_set(${rx(node[N_A], P_COMMA)}, ${rx(node[N_B], P_COMMA)}, ${jsArg(node[N_C])});\n`);
        return;

      case K.ArrLenSet:
        emit(`${ind()}porf_arr_set_len(${rx(node[N_A], P_COMMA)}, ${rx(node[N_B], P_COMMA)});\n`);
        return;

      case K.LenSet:
        emit(`${ind()}*(i32*)(MEM + ${rx(node[N_A], P_ADD)}) = ${rx(node[N_B], P_COMMA)};\n`);
        return;

      case K.RawC:
        emit(`${ind()}${node[N_A]}${node[N_B] ? ';' : ''}\n`);
        return;

      default: {
        if ((node[N_FX] & (FX.call | FX.writeMem | FX.writeLocal)) !== 0) {
          emit(`${ind()}${node[N_TYPE] !== T.none ? '(void)' : ''}${rx(node, node[N_TYPE] !== T.none ? P_CAST : P_COMMA)};\n`);
        }
        return;
      }
    }
  };

  const invokeArgs = (f, v) => {
    const pre = [], args = [];
    let j = 0;
    for (const p of f.params) {
      if (p.name === '#env') { args.push(v.env); continue; }
      if (p.name === '#this') { args.push(v.thisv); continue; }
      if (p.name === '#newtarget') { args.push(v.newtv); continue; }
      if (p.name === '#callee') { args.push(v.callee); continue; }
      if (p.name === '#allargs') {
        pre.push(`u32 _aa = porf_arr_new(${v.argc}, ${v.argc} > 4 ? ${v.argc} : 4);`);
        pre.push(`for (i32 _k = 0; _k < ${v.argc}; _k++) porf_arr_set(_aa, (u32)_k, porf_unpack(${v.argv}[_k]));`);
        args.push(`porf_box((f64)_aa, ${TYPES.array})`);
        continue;
      }
      if (p.name === '#rest') {
        // pack remaining argv into an array (twin helpers; die at step 3)
        pre.push(`u32 _rest = porf_arr_new(0, ${v.argc} > ${j} ? ${v.argc} - ${j} : 4);`);
        pre.push(`for (i32 _k = ${j}; _k < ${v.argc}; _k++) (void)porf_arr_push(_rest, porf_unpack(${v.argv}[_k]));`);
        args.push(`porf_box((f64)_rest, ${TYPES.array})`);
        continue;
      }
      const src = v.arg(j);
      if (p.type === T.f64) args.push(`(${src}).val`);
        else if (p.type === T.i64 || p.type === T.u64) args.push(`(i64)(${src}).val`);
        else if (p.type === T.i32 || p.type === T.u32 || p.type === T.ptr) args.push(`(i32)(${src}).val`);
        else args.push(src);
      j++;
    }
    return { pre, args };
  };

  // stackless coroutines: suspend spills live locals to the frame and returns, resume reloads + gotos
  const isSuspend = n => n[N_KIND] === K.Await || n[N_KIND] === K.Yield;
  let suspendMemo = null;
  const hasSuspend = node => {
    if (!Array.isArray(node)) return false;
    if (!isNode(node)) {
      for (let i = 0; i < node.length; i++) if (hasSuspend(node[i])) return true;
      return false;
    }
    const k = node[N_KIND];
    if ((node[N_FX] & FX.call) === 0 && k !== K.If && k !== K.Loop && k !== K.Block &&
      k !== K.Switch && k !== K.TypeSwitch && k !== K.Try) return false;
    let r = suspendMemo.get(node);
    if (r === undefined) {
      r = k === K.Await || k === K.Yield || hasSuspend(node[N_A]) || hasSuspend(node[N_B]) || hasSuspend(node[N_C]);
      suspendMemo.set(node, r);
    }
    return r;
  };

  const kidsOf = (v, out) => {
    if (!Array.isArray(v)) return;
    if (isNode(v)) out.push(v);
      else for (let i = 0; i < v.length; i++) kidsOf(v[i], out);
  };
  const mapVal = (v, fn) => !Array.isArray(v) ? v : isNode(v) ? fn(v) : v.map(x => mapVal(x, fn));
  const mapKids = (node, fn) => {
    const copy = node.slice();
    for (let i = N_A; i <= N_C; i++) copy[i] = mapVal(node[i], fn);
    return copy;
  };
  const isStable = n => {
    const k = n[N_KIND];
    return k === K.Const || k === K.JvConst || k === K.DataRef || k === K.FuncIdx || k === K.FuncRec || k === K.Local;
  };

  let coroTmps = null, coroTmpN = 0, coroLocals = null;
  const coroTmp = type => {
    let name;
    do name = `#coro${coroTmpN++}`; while (name in coroLocals);
    coroTmps[name] = type;
    coroLocals[name] = true;
    return [K.Local, type, FX.none, name, 0, 0];
  };
  const assignTo = (target, value) => [K.Assign, T.none, FX.writeLocal | value[N_FX], target, value, 0];
  const suspendOf = (node, arg) => [node[N_KIND], T.jsval, FX.call, arg, node[N_B], 0];

  const lowerExpr = (node, out) => {
    if (!hasSuspend(node)) return node;
    const k = node[N_KIND];
    if (k === K.Await || k === K.Yield) {
      const arg = lowerExpr(node[N_A], out);
      const t = coroTmp(T.jsval);
      out.push(assignTo(t, suspendOf(node, arg)));
      return t;
    }

    if (k === K.Select) {
      const cond = lowerExpr(node[N_A], out);
      const t = coroTmp(node[N_TYPE]);
      const a = [], b = [];
      a.push(assignTo(t, lowerExpr(node[N_B], a)));
      b.push(assignTo(t, lowerExpr(node[N_C], b)));
      out.push([K.If, T.none, cond[N_FX], cond, a, b]);
      return t;
    }
    if (k === K.Bin && (node[N_A] === '&&' || node[N_A] === '||')) {
      const l = lowerExpr(node[N_B], out);
      const t = coroTmp(T.i32);
      const rest = [];
      const r = lowerExpr(node[N_C], rest);
      rest.push(assignTo(t, [K.Bin, T.i32, r[N_FX], '!=', r, [K.Const, r[N_TYPE], FX.none, 0, 0, 0]]));
      const and = node[N_A] === '&&';
      out.push(assignTo(t, [K.Const, T.i32, FX.none, and ? 0 : 1, 0, 0]));
      out.push([K.If, T.none, l[N_FX], and ? l : [K.Un, T.i32, l[N_FX], '!', l, 0], rest, null]);
      return t;
    }

    // spill operands evaluated before the last suspend
    const kids = [];
    kidsOf(node[N_A], kids); kidsOf(node[N_B], kids); kidsOf(node[N_C], kids);
    let last = -1;
    for (let i = 0; i < kids.length; i++) if (hasSuspend(kids[i])) last = i;
    let at = 0;
    return mapKids(node, kid => {
      const i = at++;
      if (i > last) return kid;
      const x = lowerExpr(kid, out);
      if (i === last || isStable(x)) return x;
      const t = coroTmp(x[N_TYPE]);
      out.push(assignTo(t, x));
      return t;
    });
  };

  const lowerStmts = stmts => {
    const out = [];
    for (let i = 0; i < stmts.length; i++) lowerStmt(stmts[i], out);
    return out;
  };
  const lowerStmt = (s, out) => {
    if (s == null || !hasSuspend(s)) {
      out.push(s);
      return;
    }
    switch (s[N_KIND]) {
      case K.If: {
        const cond = lowerExpr(s[N_A], out);
        out.push([K.If, T.none, s[N_FX], cond, lowerStmts(s[N_B]), s[N_C] ? lowerStmts(s[N_C]) : null]);
        return;
      }
      case K.Block:
        out.push([K.Block, T.none, s[N_FX], lowerStmts(s[N_A]), s[N_B], 0]);
        return;
      case K.Try:
        out.push([K.Try, T.none, s[N_FX], lowerStmts(s[N_A]), s[N_B], lowerStmts(s[N_C])]);
        return;
      case K.Switch:
      case K.TypeSwitch: {
        const subj = lowerExpr(s[N_A], out);
        const cases = s[N_B].map(c => {
          const x = c.slice();
          x[1] = lowerStmts(c[1]);
          return x;
        });
        out.push([s[N_KIND], T.none, s[N_FX], subj, cases, s[N_C] ? lowerStmts(s[N_C]) : null]);
        return;
      }
      case K.Loop: {
        const cond = s[N_A], update = s[N_B];
        const [stmts, label] = s[N_C];
        if (!hasSuspend(cond) && !hasSuspend(update)) {
          out.push([K.Loop, T.none, s[N_FX], cond, update, [lowerStmts(stmts), label]]);
          return;
        }
        // suspend in the header: test and update move into the body
        const first = coroTmp(T.i32);
        out.push(assignTo(first, [K.Const, T.i32, FX.none, 1, 0, 0]));
        const body = [];
        if (update) {
          const u = [];
          lowerStmt(update, u);
          body.push([K.If, T.none, FX.none, [K.Un, T.i32, FX.none, '!', first, 0], u, null]);
        }
        body.push(assignTo(first, [K.Const, T.i32, FX.none, 0, 0, 0]));
        if (cond) {
          const c = lowerExpr(cond, body);
          body.push([K.If, T.none, c[N_FX], [K.Un, T.i32, c[N_FX], '!', c, 0], [ [K.Break, T.none, FX.none, label, 0, 0] ], null]);
        }
        for (const x of lowerStmts(stmts)) body.push(x);
        out.push([K.Loop, T.none, FX.none, null, null, [body, label]]);
        return;
      }
      case K.Assign: {
        const v = s[N_B];
        if (isSuspend(v) && s[N_A][N_KIND] === K.Local) {
          out.push(assignTo(s[N_A], suspendOf(v, lowerExpr(v[N_A], out))));
          return;
        }
        out.push(assignTo(s[N_A], lowerExpr(v, out)));
        return;
      }
      default: {
        const x = lowerExpr(s, out);
        if (x[N_KIND] !== K.Local) out.push(x);
        return;
      }
    }
  };
  const collectCatchNames = node => {
    if (!Array.isArray(node)) return;
    if (isNode(node)) {
      const k = node[N_KIND];
      if (k === K.Try) coroLocals[node[N_B]] ??= T.jsval;
      if (k === K.If || k === K.Loop || k === K.Block || k === K.Switch || k === K.TypeSwitch || k === K.Try) {
        collectCatchNames(node[N_A]); collectCatchNames(node[N_B]); collectCatchNames(node[N_C]);
      }
      return;
    }
    for (let i = 0; i < node.length; i++) collectCatchNames(node[i]);
  };

  // locals live across some suspend, null = all (RawC)
  const coroLive = body => {
    const saved = new Set();
    let all = false;
    const reads = (node, set) => {
      if (!Array.isArray(node)) return;
      if (isNode(node)) {
        const k = node[N_KIND];
        if (k === K.Local) { set.add(node[N_A]); return; }
        if (k === K.RawC) all = true;
        reads(node[N_A], set); reads(node[N_B], set); reads(node[N_C], set);
        return;
      }
      for (let i = 0; i < node.length; i++) reads(node[i], set);
    };
    const union = (a, b) => {
      const out = new Set(a);
      for (const x of b) out.add(x);
      return out;
    };
    const same = (a, b) => {
      if (a.size !== b.size) return false;
      for (const x of a) if (!b.has(x)) return false;
      return true;
    };
    const withLabel = (map, label, set) => {
      if (!label) return map;
      const out = new Map(map);
      out.set(label, set);
      return out;
    };

    const list = (stmts, out, ctx) => {
      let live = out;
      for (let i = stmts.length - 1; i >= 0; i--) live = stmt(stmts[i], live, ctx);
      return live;
    };
    const stmt = (s, out, ctx) => {
      if (s == null) return out;
      switch (s[N_KIND]) {
        case K.Assign: {
          const live = new Set(out);
          if (s[N_A][N_KIND] === K.Local) live.delete(s[N_A][N_A]);
          if (isSuspend(s[N_B])) {
            for (const x of live) saved.add(x);
            for (const x of ctx.extra) saved.add(x);
          }
          reads(s[N_B], live);
          return live;
        }
        case K.If: {
          const live = union(list(s[N_B], out, ctx), s[N_C] ? list(s[N_C], out, ctx) : out);
          reads(s[N_A], live);
          return live;
        }
        case K.Block:
          return list(s[N_A], out, { ...ctx, brk: withLabel(ctx.brk, s[N_B], out) });
        case K.Loop: {
          const cond = s[N_A], update = s[N_B];
          const [body, label] = s[N_C];
          let head = new Set(cond ? out : []);
          if (cond) reads(cond, head);
          for (;;) {
            const cont = update ? stmt(update, head, ctx) : head;
            const inner = { ...ctx, brk: withLabel(ctx.brk, label, out), cont: withLabel(ctx.cont, label, cont), innerBrk: out, innerCont: cont };
            const next = union(cond ? out : [], list(body, cont, inner));
            if (cond) reads(cond, next);
            if (same(next, head)) return head;
            head = next;
          }
        }
        case K.Switch:
        case K.TypeSwitch: {
          const inner = { ...ctx, innerBrk: out };
          const def = s[N_C] && s[N_C].length ? s[N_C] : null;
          // fallthrough may skip dropped cases: flow into everything after
          let after = def ? list(def, out, inner) : out;
          const live = new Set(after);
          after = union(after, out);
          for (let i = s[N_B].length - 1; i >= 0; i--) {
            const c = s[N_B][i];
            const caseIn = list(c[1], c[2] ? after : out, inner);
            for (const x of caseIn) live.add(x);
            after = union(after, caseIn);
          }
          reads(s[N_A], live);
          return live;
        }
        case K.Try: {
          const catchIn = new Set(list(s[N_C], out, ctx));
          catchIn.delete(s[N_B]);
          return union(list(s[N_A], out, { ...ctx, extra: union(ctx.extra, catchIn) }), catchIn);
        }
        case K.Break: {
          const to = s[N_A] ? ctx.brk.get(s[N_A]) : ctx.innerBrk;
          if (to == null) all = true;
          return to ?? out;
        }
        case K.Continue: {
          const to = s[N_A] ? ctx.cont.get(s[N_A]) : ctx.innerCont;
          if (to == null) all = true;
          return to ?? out;
        }
        case K.Return: {
          const live = new Set();
          reads(s[N_A], live);
          return live;
        }
        case K.Throw:
        case K.ThrowNew: {
          const live = new Set(ctx.extra);
          reads(s[N_A], live);
          reads(s[N_B], live);
          return live;
        }
        case K.Unreachable:
          return new Set();
        default: {
          const live = new Set(out);
          reads(s, live);
          return live;
        }
      }
    };

    list(body, new Set(), { brk: new Map(), cont: new Map(), innerBrk: null, innerCont: null, extra: new Set() });
    return all ? null : saved;
  };

  // regions: the function, then each loop/try holding a suspend. path: regions enclosing the current stmt
  let coro = null;
  const coroFrameBytes = [];
  const renderSuspend = (target, node) => {
    const k = ++coro.points;
    const path = coro.path;
    path[path.length - 1].cases.push(`case ${k}: goto _porf_r${k};`);
    for (let i = 0; i < path.length - 1; i++) path[i].cases.push(`case ${k}: goto _porf_t${path[i + 1].id};`);

    const t = sanitize(target[N_A]);
    const leave = `porf_fr->resume = ${k};${activeTryDepth ? ` porf_try_depth -= ${activeTryDepth};` : ''} goto _porf_save;`;
    emit(`${ind()}porf_fr->channel = ${rx(node[N_A], P_COMMA)};${node[N_KIND] === K.Await ? ' porf_fr->awaiting = 1;' : ''} ${leave}\n`);
    emit(`${ind()}_porf_r${k}: ${t} = porf_coro_received(porf_fr, ${node[N_B]});\n`);
  };

  const zeroReturn = t => t === T.none ? 'return;' : t === T.jsval ? 'return JV_UNDEFINED;' : 'return 0;';

  const renderCoroFunc = f => {
    const sym = fnSym(f);
    suspendMemo = new Map();
    coroTmps = Object.create(null);
    coroTmpN = 0;
    coroLocals = Object.create(null);
    for (const p of f.params) coroLocals[p.name] = true;
    for (const name in f.locals) coroLocals[name] = true;
    collectCatchNames(f.body);
    const body = lowerStmts(f.body);

    const live = coroLive(body);
    const locals = [], frame = [];
    const seen = new Set();
    const add = (name, t) => {
      if (seen.has(name) || t === T.none) return;
      seen.add(name);
      locals.push([ sanitize(name), t ]);
      if (live == null || live.has(name)) frame.push([ sanitize(name), t ]);
    };
    for (const p of f.params) add(p.name, p.type);
    for (const name in f.locals) add(name, f.locals[name].type);
    for (const name in coroLocals) if (typeof coroLocals[name] === 'number') add(name, coroLocals[name]);
    for (const name in coroTmps) add(name, coroTmps[name]);

    const ctSize = t => t === T.jsval ? 16 : (t === T.f64 || t === T.i64 || t === T.u64) ? 8 : 4;
    frame.sort((a, b) => ctSize(b[1]) - ctSize(a[1]));
    const frameBytes = Math.max(8, (frame.reduce((n, [ , t ]) => n + ctSize(t), 0) + 7) & ~7);
    coroFrameBytes[f.index] = frameBytes;

    const frameT = `porf_frame_${sym}`;
    coro = { regions: [ { id: 0, cases: [] } ], path: [], points: 0 };
    coro.path.push(coro.regions[0]);
    emitBuf = [];
    emit(`typedef struct {${frame.map(([n, t]) => ` ${CT[t]} ${n};`).join('') || ' u64 _;'} } ${frameT};\n`);
    emit(`_Static_assert(sizeof(${frameT}) <= ${frameBytes}u, "coroutine frame layout");\n`);
    emit(`${NEVER_INLINE.has(f.name) ? 'PORF_NOINLINE ' : ''}${CT[f.retType]} ${sym}(porf_coro_call* porf_fr) {\n`);
    depth = 1;
    activeTryDepth = 0;
    loopStack.length = 0;
    usedLabels = new Set();
    for (const [n, t] of locals) emit(`  ${CT[t]} ${n}${t === T.jsval ? ' = JV_UNDEFINED' : ' = 0'};\n`);

    const { pre, args } = invokeArgs(f, { env: 'porf_fr->env', thisv: 'porf_fr->thisv', newtv: 'porf_fr->newtv', callee: 'porf_fr->callee', argc: 'porf_fr->argc', argv: 'porf_coro_argv(porf_fr)',
      arg: j => `porf_unpack(porf_fr->argc > ${j} ? porf_coro_argv(porf_fr)[${j}] : JV_UNDEFINED_BITS)` });
    emit(`  if (porf_fr->resume == 0) {\n`);
    for (const x of pre) emit(`    ${x}\n`);
    f.params.forEach((p, i) => emit(`    ${sanitize(p.name)} = ${args[i]};\n`));
    emit(`  } else {\n`);
    emit(`    const ${frameT}* porf_frs = (const ${frameT}*)porf_coro_frame(porf_fr);\n`);
    for (const [n] of frame) emit(`    ${n} = porf_frs->${n};\n`);
    emit(`    switch (porf_fr->resume) {\x000\x00default: porf_unreachable("bad coroutine resume point");}\n`);
    emit(`  }\n`);

    renderStmts(body);

    emit(`  ${zeroReturn(f.retType)}\n`);
    emit(`_porf_save:;\n`);
    emit(`  ${frameT}* porf_frs = (${frameT}*)porf_coro_frame(porf_fr);\n`);
    for (const [n] of frame) emit(`  porf_frs->${n} = ${n};\n`);
    emit(`  porf_coro_touch(porf_fr);\n`);
    emit(`  ${zeroReturn(f.retType)}\n`);
    emit(`}\n\n`);

    const text = emitBuf.join('');
    const regions = coro.regions;
    emitBuf = coro = null;
    emit(text.replace(/\x00(\d+)\x00/g, (_, id) => regions[id].cases.join(' ') + ' '));
    suspendMemo = coroTmps = coroLocals = null;
  };

  const renderFunc = f => {
    cur = partsOf(unitOf(f));
    if (needsCoro(f)) return renderCoroFunc(f);
    const ret = CT[f.retType];
    const params = f.params.map(p => `${CT[p.type]} ${sanitize(p.name)}`).join(', ');
    emit(`${f.ast?._module ? 'PORF_ONCE ' : NEVER_INLINE.has(f.name) ? 'PORF_NOINLINE ' : ALWAYS_INLINE.has(f.name) ? '__attribute__((always_inline)) ' : ''}PORF_CC ${ret} ${fnSym(f)}(${params || 'void'}) {\n`);
    depth = 1;
    activeTryDepth = 0;
    loopStack.length = 0;
    usedLabels = new Set();
    const paramNames = new Set(f.params.map(p => p.name));
    for (const name in f.locals) {
      if (paramNames.has(name)) continue;
      const t = f.locals[name].type;
      emit(`  ${CT[t]} ${sanitize(name)}${t === T.jsval ? ' = JV_UNDEFINED' : ' = 0'};\n`);
    }
    renderStmts(f.body);
    emit(`}\n\n`);
  };

  for (const f of linkFuncs) renderFunc(f);

  // runtime prelude: porf.h + porf_runtime.c in split mode
  const runtimeRefs = [];
  const prelude = [];
  const toStr = funcs.find(x => x && x.name === '__ecma262_ToString' && x.body);
  if (toStr) runtimeRefs.push(toStr);
  const iterClose = funcs.find(x => x && x.name === '__Porffor_iterator_close' && x.body);
  if (iterClose) runtimeRefs.push(iterClose);
  if (promiseResolveFunc) runtimeRefs.push(promiseResolveFunc);
  const fatal = funcs.find(x => x && x.name === '__Porffor_fatal' && x.body);
  if (fatal) runtimeRefs.push(fatal);
  prelude.push(RUNTIME_HEAD(prefs, toStr ? fnSym(toStr) : null, iterClose ? fnSym(iterClose) : null, bigints, fatal ? fnSym(fatal) : null));
  if (usesCoro || usesSyncAsync) prelude.push(PROMISE_DIRECT_RUNTIME());
  if (usesCoro) prelude.push(CORO_RUNTIME());

  // link unit head: static data image, globals, gc roots, per-function tables
  const link = [];
  if (data.length > 0 || fnNameSegs.length > 0) {
    // static data is constant bytes at fixed offsets: one contiguous image (holes stay
    // zero) init'd by a single memcpy, emitted as string literals (~1 char per ascii byte)
    const imageBase = 16;
    const image = new Uint8Array(imageEnd - imageBase);
    const writeBytes = (off, bytes) => {
      off -= imageBase;
      for (let k = 0; k < bytes.length; k++) image[off + k] = bytes[k];
    };
    const writeU32 = (off, v) => writeBytes(off, [ v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff ]);
    const writeU64 = (off, bits) => {
      off -= imageBase;
      for (let k = 0; k < 8; k++) image[off + k] = Number((bits >> BigInt(k * 8)) & 0xFFn);
    };

    for (let i = 0; i < linkFuncs.length; i++) writeU32(fnrecBase + i * 8, i);
    for (const { off, bytes } of fnNameSegs) writeBytes(off, bytes);
    for (let i = 0; i < data.length; i++) {
      if (zeroed[i]) continue;
      const seg = data[i];
      const off = dataOffsets[i];
      if (seg.staticArray) {
        const items = seg.staticArray;
        writeU32(off, items.length);
        writeU32(off + 4, off + 16);
        writeU32(off + 8, items.length);
        for (let j = 0; j < items.length; j++) {
          const it = items[j];
          const dst = off + 16 + j * 8;
          if (it.num !== undefined) {
            if (it.num === 0 && 1 / it.num === Infinity) writeU64(dst, JV_ZERO_BITS);
              else writeBytes(dst, ieee754_binary64(it.num));
          } else if (it.str !== undefined) {
            writeU64(dst, jvConstBits(TYPES.bytestring, dataOffsets[it.str]));
          } else {
            writeU64(dst, jvConstBits(it.jvType, it.payload));
          }
        }
        continue;
      }
      writeBytes(off, seg);
    }

    // the arena starts zeroed: long zero runs (inline cache slots) are left out of the image
    const runs = [];
    for (let i = 0; i < image.length;) {
      while (i < image.length && image[i] === 0) i++;
      if (i === image.length) break;
      let end = i, zeros = 0;
      for (; end < image.length && zeros < 256; end++) zeros = image[end] === 0 ? zeros + 1 : 0;
      runs.push([ i, end - zeros ]);
      i = end;
    }
    let blobLen = runs.reduce((acc, [ start, end ]) => acc + end - start, 0);
    let blob = new Uint8Array(blobLen);
    for (let i = 0, at = 0; i < runs.length; i++) {
      blob.set(image.subarray(runs[i][0], runs[i][1]), at);
      at += runs[i][1] - runs[i][0];
    }
    const runsTable = `static const u32 porf_data_runs[] = { ${runs.map(([ start, end ]) => `${imageBase + start}u, ${end - start}u`).join(', ')} };\n`;
    const scatter = `  for (u32 i = 0; i < ${runs.length * 2}u; i += 2) {\n    memcpy(MEM + porf_data_runs[i], src, porf_data_runs[i + 1]);\n    src += porf_data_runs[i + 1];\n  }\n`;
    let init = runsTable + `static void porf_data_init(void) {\n  const u8* src = porf_data;\n${scatter}}\n\n`;
    // big images (embedded files) keep their non-zero 16KB pages, mapped from the binary so unwritten ones stay shared
    let align = '';
    const P = 16384, full = Math.floor(imageEnd / P), pageRuns = [];
    if (image.length >= 65536) {
      for (let pg = 1; pg < full; pg++) {
        if (image.subarray(pg * P - imageBase, (pg + 1) * P - imageBase).every(b => b === 0)) continue;
        if (pageRuns.length > 0 && pageRuns.at(-1)[0] + pageRuns.at(-1)[1] === pg) pageRuns.at(-1)[1]++;
          else pageRuns.push([ pg, 1 ]);
      }
    }
    const pages = pageRuns.reduce((acc, [ , n ]) => acc + n, 0);
    if (!prefs.compressData && pages > 0 && pages * P <= blobLen * 1.25) {
      const tail = imageEnd - full * P;
      blob = new Uint8Array((1 + pages) * P + tail);
      blob.set(image.subarray(0, P - imageBase), imageBase);
      let next = 1;
      for (const run of pageRuns) {
        blob.set(image.subarray(run[0] * P - imageBase, (run[0] + run[1]) * P - imageBase), next * P);
        run.push(next);
        next += run[1];
      }
      blob.set(image.subarray(full * P - imageBase), next * P);
      blobLen = blob.length;
      align = ' __attribute__((aligned(16384)))';
      init = DATA_MAP + `static const u32 porf_data_pages[] = { ${pageRuns.map(([ pg, n, b ]) => `${pg * P}u, ${b * P}u, ${n * P}u`).join(', ')} };\n` +
        `static void porf_data_init(void) {\n  memcpy(MEM + ${imageBase}, porf_data + ${imageBase}, ${P - imageBase}u);\n  memcpy(MEM + ${full * P}u, porf_data + ${next * P}u, ${tail}u);\n` +
        `  off_t off;\n  const int fd = porf_data_file(&off);\n  for (u32 i = 0; i < ${pageRuns.length * 3}u; i += 3) {\n` +
        `    const u32 mem = porf_data_pages[i], at = porf_data_pages[i + 1], len = porf_data_pages[i + 2];\n` +
        `    if (fd < 0 || mmap(MEM + mem, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_FIXED, fd, off + at) == MAP_FAILED) memcpy(MEM + mem, porf_data + at, len);\n` +
        `  }\n  if (fd >= 0) close(fd);\n}\n\n`;
    } else if (prefs.compressData && blobLen > 0) {
      // the runs compress, then decode aside and spread out, never touching the zeros between them
      const compressed = lz4Compress(blob);
      if (compressed.len < blobLen) {
        init = LZ4_DECODE + runsTable + `static void porf_data_init(void) {\n  u8* const runs = mmap(NULL, ${blobLen}u, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);\n  porf_lz4_decode(porf_data, ${compressed.len}u, runs);\n  const u8* src = runs;\n${scatter}  munmap(runs, ${blobLen}u);\n}\n\n`;
        blob = compressed.out;
        blobLen = compressed.len;
      }
    }

    // printable ascii stays literal (except " \ ?, dodging trigraphs), the rest fixed-width
    // octal so a following digit can't extend the escape
    const esc = [];
    for (let b = 0; b < 256; b++) {
      esc.push(b >= 0x20 && b <= 0x7e && b !== 0x22 && b !== 0x3f && b !== 0x5c ?
        String.fromCharCode(b) : '\\' + b.toString(8).padStart(3, '0'));
    }

    const lines = [];
    let parts = [], len = 0;
    for (let i = 0; i < blobLen; i++) {
      const e = esc[blob[i]];
      parts.push(e);
      len += e.length;
      if (len >= 4000) {
        lines.push('"' + parts.join('') + '"');
        parts = [];
        len = 0;
      }
    }
    if (parts.length > 0 || lines.length === 0) lines.push('"' + parts.join('') + '"');

    link.push(`static const u8 porf_data[]${align} =\n${lines.join('\n')};\n${init}`);
  } else {
    link.push('static void porf_data_init(void) {}\n\n');
  }

  const proto = f => `${needsCoro(f) ? '' : 'PORF_CC '}${CT[f.retType]} ${fnSym(f)}(${needsCoro(f) ? 'porf_coro_call*' : f.params.map(p => CT[p.type]).join(', ') || 'void'});\n`;
  const guard = f => {
    if (!guardOf(f)) return '';
    const names = f.params.map(p => sanitize(p.name));
    emitBuf = [];
    depth = 1;
    activeTryDepth = 0;
    renderStmt(guardOf(f));
    const test = emitBuf.join('');
    emitBuf = null;
    return `static inline __attribute__((always_inline)) PORF_CC ${CT[f.retType]} ${fnSym(f)}_g(${f.params.map((p, i) => `${CT[p.type]} ${names[i]}`).join(', ') || 'void'}) {\n${test}  ${f.retType === T.none ? '' : 'return '}${fnSym(f)}(${names.join(', ')});\n}\n`;
  };
  const linkProtos = [
    `${st}jsval porf_call_dynamic(jsval fn, jsval thisv, jsval newtv, i32 argc, jsbits* argv);\n`,
    `${st}jsval porf_call_dynamic_arr(jsval fn, jsval thisv, jsval newtv, jsval arr);\n`
  ];
  if (usesDynReg) for (let n = 0; n <= DYN_REGS; n++) linkProtos.push(`${split ? '' : 'static inline '}PORF_CC jsval porf_call${n}(${dynCallParams(n)});\n`);
  if (usesSyncAsync) linkProtos.push(`${st}jsval porf_async_call_sync(u32 idx, jsval callee, u32 env, jsval thisv, jsval newtv, i32 argc, jsbits* argv);\n`);
  if (usesCoro) {
    // coroutine entry points called from user code / builtins above their definitions
    linkProtos.push(`${st}jsval porf_coro_start(u8 flags, u32 idx, jsval callee, u32 env, jsval thisv, jsval newtv, i32 argc, jsbits* argv);\n`);
    linkProtos.push(`${st}i32 __Porffor_coroutine_resume(jsval gen, jsval value, i32 mode);\n`);
    linkProtos.push(`${st}jsval __Porffor_coroutine_value(jsval gen);\n`);
    linkProtos.push(`${st}i32 __Porffor_coroutine_raw(jsval gen);\n`);
    linkProtos.push(`${st}i32 __Porffor_coroutine_awaiting(jsval gen);\n`);
    linkProtos.push(`${st}void __Porffor_coroutine_setRaw(i32 raw);\n`);
    linkProtos.push(`${st}jsval __Porffor_coroutine_callee(jsval gen);\n`);
  }
  if (!split) {
    for (const f of linkFuncs) link.push(proto(f));
    for (const x of linkProtos) link.push(x);
  }

  // module globals (top-level JS bindings)
  // sproutboat P6: app-module globals last, so the shared prefix of the declaration and root lists is app-independent
  { const isApp = g => [ ...appModuleIds ].some(id => g.name.includes('#m' + id) || g.name.includes('_' + id + '_') || g.name.endsWith('_' + id)); globals = [ ...globals.filter(g => !isApp(g)), ...globals.filter(isApp) ]; }
  for (const g of globals) link.push(`${st}${CT[g.type]} ${sanitize(g.name)}${g.type === T.jsval ? ` = {0.0, ${TYPES.undefined}}` : ''};\n`);
  if (!split) for (const f of linkFuncs) link.push(guard(f));
  link.push('\n');
  if (gcEnabled) {
    const markGlobalRootLines = [];
    const markGlobalRawLines = [];
    const markUnderlyingLines = [], compactUnderlyingLines = [];
    for (const g of globals) {
      const name = sanitize(g.name);
      if (g.type === T.jsval) markGlobalRootLines.push(`  porf_gc_mark_js(${name}.val, ${name}.type);`);
      else if (g.type === T.ptr || (g.type === T.i32 && /(?:underlyingStore|underlyingBuckets|shapeTable|shapeHash|icMega|__Porffor_regex_cache)$/.test(g.name))) {
        if (/underlyingStore$/.test(g.name)) {
          const buckets = sanitize(g.name.replace(/underlyingStore$/, 'underlyingBuckets'));
          const bucketsCap = sanitize(g.name.replace(/underlyingStore$/, 'underlyingBucketsCap'));
          markUnderlyingLines.push(`  changed |= porf_gc_mark_underlying_store((i32)${name});`);
          compactUnderlyingLines.push(`  if (porf_gc_compact_underlying_store((i32)${name})) { ${buckets} = 0; ${bucketsCap} = 0; }`);
        }
        else if (/shapeTable$/.test(g.name)) markGlobalRawLines.push(`  porf_gc_mark_shapes((i32)${name}, (i32)${sanitize(g.name.replace(/shapeTable$/, 'shapeCount'))});`);
        else if (/__Porffor_regex_cache$/.test(g.name)) markGlobalRawLines.push(`  porf_gc_mark_regex_cache((i32)${name});`);
        else if (/getptr_/.test(g.name)) {
          const builtinName = g.name.slice(g.name.lastIndexOf('getptr_') + 'getptr_'.length);
          markGlobalRootLines.push(`  if (${name} != 0) porf_gc_mark_js((f64)${name}, ${funcByName.has(builtinName) ? TYPES.function : TYPES.object});`);
        }
        else markGlobalRawLines.push(`  porf_gc_mark_raw((i32)${name});`);
      }
    }
    link.push(`${st}void porf_gc_mark_global_roots(void) {\n${markGlobalRootLines.join('\n') || '  (void)0;'}\n}\n\n`);
    link.push(`${st}void porf_gc_mark_global_raw_roots(void) {\n${markGlobalRawLines.join('\n') || '  (void)0;'}\n}\n\n`);
    link.push(`${st}int porf_gc_mark_underlying_stores(void) {\n  int changed = 0;\n${markUnderlyingLines.join('\n')}\n  return changed;\n}\n\n`);
    link.push(`${st}void porf_gc_compact_underlying_stores(void) {\n${compactUnderlyingLines.join('\n') || '  (void)0;'}\n}\n\n`);
    link.push(usesCoro
      ? `${st}void porf_gc_mark_coro_roots(void) {\n  for (porf_coro_call* c = porf_coro_cur; c; c = c->parent) {\n    if (c->heap) porf_gc_mark_coro(c->heap);\n      else porf_coro_gc_scan(c);\n  }\n}\n\n${st}void porf_gc_mark_coro(u32 body) {\n  if (body != 0 && porf_gc_mark_body((i32)body)) porf_coro_gc_scan((porf_coro_call*)(MEM + body));\n}\n\n${st}void porf_gc_scan_coro(i32 body) {\n  porf_coro_gc_scan((porf_coro_call*)(MEM + body));\n}\n\n`
      : `${st}void porf_gc_mark_coro_roots(void) {}\n${st}void porf_gc_mark_coro(u32 body) { (void)body; }\n${st}void porf_gc_scan_coro(i32 body) { (void)body; }\n\n`);
  }

  // per-function metadata tables, emitted before bodies so __Porffor_funcLut_* can read them.
  // porf_fnflags: bits 0-2 coroutine dispatch (masked off in porf_call_dynamic), bit 3 callable,
  // bit 4 constructor, funcLut.flags recovers legacy callable|constr<<1 (| sloppy<<3) via flags >> 3
  link.push(`${st}const u8 porf_fnflags[] = { ${linkFuncs.map(fnFlags).join(', ') || '0'} };\n`);
  if (usesSyncAsync) link.push(`${st}const u8 porf_fnneeds_coro[] = { ${linkFuncs.map(f => needsCoro(f) ? 1 : 0).join(', ') || '0'} };\n`);
  link.push(`${st}const u16 porf_fnlen[] = { ${linkFuncs.map(f => f.jsLength ?? 0).join(', ') || '0'} };\n`);
  link.push(`${st}const u32 porf_fnname[] = { ${fnNameOff.join(', ') || '0'} };\n`);
  link.push(`const u32 porf_static_end = ${staticEnd}u;\n`);
  if (split) {
    link.push(`const u32 porf_fnrecs = ${fnrecBase}u;\n`);
    for (const u of unitOrder) link.push(`const u32 porf_fnbase_${sanitize(u)} = ${fnBase[u]}u;\nconst u32 porf_dbase_${sanitize(u)} = ${dbase[u]}u;\nconst u32 porf_zbase_${sanitize(u)} = ${zbase[u]}u;\n`);
  }
  link.push('\n');

  cur = partsOf('main');
  for (const f of linkFuncs) cur.protos[f.index] = f;

  const returnBoxed = (f, call) =>
    f.retType === T.none ? `${call}; return JV_UNDEFINED;` :
    f.retType === T.f64 ? `return porf_box_num(${call});` :
    f.retType === T.jsval ? `return ${call};` :
    `return porf_box_num((f64)${call});`;

  // adapt a uniform dynamic-call ABI to f's signature
  const dynInvokeCall = (f, v, sym = fnSym(f)) => {
    const { pre, args } = invokeArgs(f, v);
    const ret = returnBoxed(f, `${sym}(${args.join(', ')})`);
    return pre.length ? `{ ${pre.join(' ')} ${ret} }` : ret;
  };

  if (usesDynReg) {
    const regsVoid = dynRegs().map((_, j) => `(void)a${j};`).join(' ');
    emit(`${st}PORF_CC jsval porf_thk_slow(${dynThunkParams}) {
  jsbits argv[${DYN_REGS}] = { ${dynRegs().map((_, j) => `porf_pack(a${j})`).join(', ')} };
  return porf_call_dynamic(porf_box((f64)(u32)ra, ${TYPES.function}), thisv, JV_UNDEFINED, (i32)(ra >> 32), argv);
}
${st}PORF_CC jsval porf_thk_bad(${dynThunkParams}) {
  (void)ra; (void)thisv; ${regsVoid}
  porf_unreachable("uncompiled function");
  return JV_UNDEFINED;
}
`);
    const table = [];
    for (let i = 0; i < linkFuncs.length; i++) {
      const f = linkFuncs[i];
      if (!dynRegThunk(f)) {
        table.push(f.indirect || needsCoro(f) || isSyncAsync(f) ? 'porf_thk_slow' : 'porf_thk_bad');
        continue;
      }
      const body = dynInvokeCall(f, {
        env: '(*(u32*)(MEM + (u32)ra + 4))',
        thisv: 'thisv',
        callee: `porf_box((f64)(u32)ra, ${TYPES.function})`,
        newtv: 'JV_UNDEFINED',
        arg: j => j < DYN_REGS ? `a${j}` : 'JV_UNDEFINED'
      });
      emit(`${st}PORF_CC jsval porf_thk_${i}(${dynThunkParams}) { (void)ra; (void)thisv; ${regsVoid} ${body} }\n`);
      table.push(`porf_thk_${i}`);
    }
    emit(`${st}PORF_CC jsval (*const porf_thk[${linkFuncs.length || 1}])(${dynThunkParams}) = { ${table.join(', ') || 'porf_thk_bad'} };\n\n`);

    for (let n = 0; n <= DYN_REGS; n++) {
      const regs = Array.from({ length: DYN_REGS }, (_, j) => j < n ? `a${j}` : 'JV_UNDEFINED');
      emit(`${split ? '' : 'static inline '}PORF_CC jsval porf_call${n}(${dynCallParams(n)}) {
  if (porf_jv_type(fn) != ${TYPES.function}) {
    ${proxyCall ? `if (porf_jv_type(fn) == ${TYPES.proxy}) {
      jsbits argv[${n || 1}] = { ${n ? regs.slice(0, n).map(x => `porf_pack(${x})`).join(', ') : '0'} };
      return porf_call_dynamic(fn, thisv, JV_UNDEFINED, ${n}, argv);
    }` : ''}
    porf_throw_new(${TYPES.typeerror}, 0);
  }
  const u32 rec = (u32)fn.val;
  const u32 idx = *(u32*)(MEM + rec);
  if (idx >= ${linkFuncs.length}u) porf_unreachable("bad function index");
  return porf_thk[idx]((u64)rec | ((u64)${n} << 32), thisv, ${regs.join(', ')});
}
`);
    }
  }

  // fn values are records [fnIdx u32][env u32], funcs a thunk fully serves fall through to it
  // one case per signature, each func is called through porf_invoke_fn, slot 0 has no case
  const invokeShapes = new Map(), invokeSlot = [], invokeFn = [ '0' ], invokeShape = [ 0 ];
  for (let i = 0; i < linkFuncs.length; i++) {
    const f = linkFuncs[i];
    invokeSlot.push(0);
    if (needsCoro(f) || (!f.indirect && !isSyncAsync(f))) continue;
    if (usesDynReg && dynRegThunk(f) && !hasParam(f, '#newtarget') && f.params.filter(p => p.name[0] !== '#').length <= DYN_REGS) continue;
    const call = dynInvokeCall(f, {
      env: 'env', thisv: 'thisv', callee: 'callee', newtv: 'newtv', argc: 'argc', argv: 'argv',
      arg: j => `porf_unpack(argc > ${j} ? argv[${j}] : JV_UNDEFINED_BITS)`
    }, `((PORF_CC ${CT[f.retType]} (*)(${f.params.map(p => CT[p.type]).join(', ') || 'void'}))fn)`);
    if (!invokeShapes.has(call)) invokeShapes.set(call, invokeShapes.size + 1);
    invokeSlot[i] = invokeFn.length;
    invokeFn.push(`(void*)${fnSym(f)}`);
    invokeShape.push(invokeShapes.get(call));
  }
  emit(`${st}const ${invokeFn.length > 65535 ? 'u32' : 'u16'} porf_invoke_slot[] = { ${invokeSlot.join(', ') || '0'} };\n`);
  emit(`${st}void* const porf_invoke_fn[] = { ${invokeFn.join(', ')} };\n`);
  emit(`${st}const u16 porf_invoke_shape[] = { ${invokeShape.join(', ')} };\n`);
  emit(`${st}jsval porf_invoke(u32 idx, jsval callee, u32 env, jsval thisv, jsval newtv, i32 argc, jsbits* argv) {\n`);
    emit('  (void)callee; (void)env; (void)thisv; (void)newtv; (void)argc; (void)argv;\n');
    emit('  const u32 slot = porf_invoke_slot[idx];\n');
    emit('  void* const fn = porf_invoke_fn[slot];\n');
    emit('  switch (porf_invoke_shape[slot]) {\n');
    for (const [ call, shape ] of invokeShapes) emit(`    case ${shape}: ${call}\n`);
    emit('  }\n');
    if (usesDynReg) emit(`  return porf_thk[idx]((u64)(u32)callee.val | ((u64)(u32)argc << 32), thisv, ${dynRegs().map((_, j) => `argc > ${j} ? porf_unpack(argv[${j}]) : JV_UNDEFINED`).join(', ')});\n}\n`);
      else emit('  porf_unreachable("uncompiled function");\n  return JV_UNDEFINED;\n}\n');

    if (usesCoro) {
      emit(`${st}jsval porf_coro_dispatch(porf_coro_call* call) {\n  switch (call->idx) {\n`);
      for (let i = 0; i < linkFuncs.length; i++) {
        const f = linkFuncs[i];
        if (needsCoro(f)) emit(`    case ${i}: ${returnBoxed(f, `${fnSym(f)}(call)`)}\n`);
      }
      emit('  }\n  porf_unreachable("uncompiled coroutine");\n  return JV_UNDEFINED;\n}\n');
      emit(`${st}u32 porf_coro_frame_bytes(u32 idx) {\n  switch (idx) {\n`);
      for (let i = 0; i < linkFuncs.length; i++) {
        const f = linkFuncs[i];
        if (needsCoro(f)) emit(`    case ${i}: return ${coroFrameBytes[f.index]}u;\n`);
      }
      emit('  }\n  return 0;\n}\n');
    }

    if (usesCoro || usesSyncAsync) {
      emit(`
${st}jsval porf_promise_settled(jsval value, i32 state) {
  const u32 p = porf_alloc(PORF_PROMISE_SIZE, ${TYPES.promise});
  *(jsbits*)(MEM + p + PORF_PROMISE_RESULT) = porf_pack(value);
  *(u32*)(MEM + p + PORF_PROMISE_FULFILL_HEAD) = 0;
  *(u32*)(MEM + p + PORF_PROMISE_FULFILL_TAIL) = 0;
  *(u32*)(MEM + p + PORF_PROMISE_REJECT_HEAD) = 0;
  *(u32*)(MEM + p + PORF_PROMISE_REJECT_TAIL) = 0;
  *(jsbits*)(MEM + p + PORF_PROMISE_PAYLOAD) = JV_UNDEFINED_BITS;
  *(u8*)(MEM + p + PORF_PROMISE_STATE) = (u8)state;
  *(u8*)(MEM + p + PORF_PROMISE_FLAGS) = 0;
  *(u8*)(MEM + p + PORF_PROMISE_HANDLED) = 0;
  return porf_box((f64)p, ${TYPES.promise});
}

`);
    }

    if (usesSyncAsync) {
      emit(`
${st}jsval porf_async_call_sync(u32 idx, jsval callee, u32 env, jsval thisv, jsval newtv, i32 argc, jsbits* argv) {
  const i32 try_idx = porf_try_depth++;
  if (_setjmp(porf_try_ensure()[try_idx]) == 0) {
    const jsval result = porf_invoke(idx, callee, env, thisv, newtv, argc, argv);
    porf_try_depth = try_idx;
    const jsval out_promise = porf_promise_settled(JV_UNDEFINED, 0);
    ${settleAsyncResult('result', 'out_promise')}
    return out_promise;
  }

  porf_try_depth = try_idx;
  const jsval out_promise = porf_promise_settled(JV_UNDEFINED, 0);
  ${rejectAsyncResult('porf_exception', 'out_promise')}
  return out_promise;
}
`);
    }

	    if (usesCoro) {
	      emit(`
	static u32 porf_arr_new_typed(i32 len, i32 cap, i32 type) {
	  if (cap < len) cap = len;
	  if (cap < 4) cap = 4;
	  const u32 a = porf_alloc(16 + ((u32)cap << 3), type);
	  PORF_ARR_LEN(a) = len; PORF_ARR_ENT(a) = a + 16; PORF_ARR_CAP(a) = cap; PORF_ARR_UNDERLYING(a) = 0;
	  memset(MEM + PORF_ARR_ENT(a), 0, (size_t)cap << 3);
	  return a;
	}

static void porf_promise_run_coro_reaction_coro(u32 reaction) {
  porf_coro_call* call = (porf_coro_call*)(MEM + (u32)*(u64*)(MEM + reaction + PORF_REACTION_HANDLER));
  const jsval out_promise = porf_unpack(*(jsbits*)(MEM + reaction + PORF_REACTION_OUT_PROMISE));
  const jsval value = porf_unpack(*(jsbits*)(MEM + reaction + PORF_REACTION_VALUE));
  const i32 is_throw = (i32)*(u32*)(MEM + reaction + PORF_REACTION_PAYLOAD);

  const i32 try_idx = porf_try_depth++;
  if (_setjmp(porf_try_ensure()[try_idx]) == 0) {
    const i32 done = porf_coro_call_step(call, value, is_throw);
    porf_try_depth = try_idx;
    if (done) {
      const jsval result = call->result;
      ${settleAsyncResult('result', 'out_promise')}
      return;
    }

    porf_promise_attach_coro(call->channel, call, out_promise);
    return;
  }

  porf_try_depth = try_idx;
  porf_coro_abort(call);
  ${rejectAsyncResult('porf_exception', 'out_promise')}
}

static porf_coro_call* porf_coro_unbox(jsval gen) {
  const i32 type = porf_jv_type(gen);
  if (type != ${TYPES.__porffor_generator} && type != ${TYPES.__porffor_asyncgenerator}) {
    porf_throw_new(${TYPES.typeerror}, 0);
  }
  return (porf_coro_call*)(MEM + (u32)gen.val);
}

// TS-facing coroutine mechanism (generator.ts + for-of build the iterator protocol and
// the { value, done } result on top of these). mode: 0 = next, 1 = throw the value at the
// suspend point, 2 = return (force completion with the value). returns 1 once done.
${st}i32 __Porffor_coroutine_resume(jsval gen, jsval value, i32 mode) {
  porf_coro_call* call = porf_coro_unbox(gen);
  if (mode == 2 && call->state == 2) {
    call->result = value;
    porf_coro_touch(call);
    value = PORF_CORO_RETURN;
    mode = 1;
  }
  if (call->state == 1) porf_throw_new(${TYPES.typeerror}, 0);
  if (mode != 0 ? call->state != 2 : call->state == 3) {
    porf_coro_finish(call);
    call->result = mode == 2 ? value : JV_UNDEFINED;
    porf_coro_touch(call);
    if (mode == 1) porf_throw(value);
    return 1;
  }

  // an exception escaping the body finishes it, re-raise to the caller
  const i32 try_idx = porf_try_depth++;
  if (_setjmp(porf_try_ensure()[try_idx]) == 0) {
    const i32 done = porf_coro_call_step(call, value, mode == 1);
    porf_try_depth = try_idx;
    return done;
  }

  porf_try_depth = try_idx;
  porf_coro_abort(call);
  if (porf_jv_eq(porf_exception, PORF_CORO_RETURN)) return 1;
  porf_throw(porf_exception);
}

// the value the coroutine just produced: its final return value once done, otherwise the
// most recently yielded value
${st}jsval __Porffor_coroutine_value(jsval gen) {
  porf_coro_call* call = porf_coro_unbox(gen);
  return call->state == 3 ? call->result : call->channel;
}

${st}i32 __Porffor_coroutine_raw(jsval gen) {
  return porf_coro_unbox(gen)->raw;
}

${st}i32 __Porffor_coroutine_awaiting(jsval gen) {
  return porf_coro_unbox(gen)->awaiting;
}

${st}void __Porffor_coroutine_setRaw(i32 raw) {
  porf_coro_cur->raw = raw;
}

${st}jsval __Porffor_coroutine_callee(jsval gen) {
  return porf_coro_unbox(gen)->callee;
}

${st}jsval porf_coro_start(u8 flags, u32 idx, jsval callee, u32 env, jsval thisv, jsval newtv, i32 argc, jsbits* argv) {
  porf_promise_run_coro_reaction_impl = porf_promise_run_coro_reaction_coro;
  const u32 frame = porf_coro_frame_bytes(idx);
  const u8 kind = flags & 7u;

  if (kind == ${FN_GENERATOR} || kind == ${FN_ASYNC_GENERATOR}) {
    const u32 type = kind == ${FN_GENERATOR} ? ${TYPES.__porffor_generator}u : ${TYPES.__porffor_asyncgenerator}u;
    porf_coro_call* call = porf_coro_alloc(type, frame, argc);
    porf_coro_init(call, call->heap, frame, idx, callee, env, thisv, newtv, argc, argv);
    if (flags & ${FN_CORO_INIT}u) {
      const i32 try_idx = porf_try_depth++;
      if (_setjmp(porf_try_ensure()[try_idx]) == 0) {
        (void)porf_coro_call_step(call, JV_UNDEFINED, 0);
        porf_try_depth = try_idx;
      } else {
        porf_try_depth = try_idx;
        porf_coro_abort(call);
        porf_throw(porf_exception);
      }
    }
    return porf_box((f64)call->heap, type);
  }

  // record on the C stack until it first suspends
  const u32 bytes = PORF_CORO_BYTES(frame, argc);
  porf_coro_call* call = bytes <= 1024u ? (porf_coro_call*)__builtin_alloca(bytes) : porf_coro_alloc(PORF_GC_KIND_CORO, frame, argc);
  porf_coro_init(call, bytes <= 1024u ? 0 : call->heap, frame, idx, callee, env, thisv, newtv, argc, argv);
  const jsval out_promise = porf_promise_pending();
  const i32 try_idx = porf_try_depth++;
  if (_setjmp(porf_try_ensure()[try_idx]) == 0) {
    const i32 done = porf_coro_call_step(call, JV_UNDEFINED, 0);
    porf_try_depth = try_idx;
    if (done) {
      jsval result = call->result;
      ${settleAsyncResult('result', 'out_promise')}
    } else {
      porf_coro_call* heap = porf_coro_promote(call);
      porf_promise_attach_coro(heap->channel, heap, out_promise);
    }
    return out_promise;
  }

  porf_try_depth = try_idx;
  porf_coro_abort(call);
  ${rejectAsyncResult('porf_exception', 'out_promise')}
  return out_promise;
}

	`);
    }
    emit(`${st}jsval porf_call_dynamic(jsval fn, jsval thisv, jsval newtv, i32 argc, jsbits* argv) {
  if (porf_jv_type(fn) != ${TYPES.function}) {
    ${proxyCall ? `// __Porffor_proxy_call(proxy, this, newTarget, ...args)
    if (porf_jv_type(fn) == ${TYPES.proxy}) {
      jsbits nargv[argc + 3];
      nargv[0] = porf_pack(fn); nargv[1] = porf_pack(thisv); nargv[2] = porf_pack(newtv);
      if (argc > 0) memcpy(nargv + 3, argv, (size_t)argc * sizeof(jsbits));
      return porf_invoke(${linkIdx[proxyCall.index]}u, JV_UNDEFINED, 0, JV_UNDEFINED, JV_UNDEFINED, argc + 3, nargv);
    }` : ''}
    porf_throw_new(${TYPES.typeerror}, 0);
  }
  const u32 rec = (u32)fn.val;
  const u32 idx = *(u32*)(MEM + rec);
  const u32 env = *(u32*)(MEM + rec + 4);
  if (idx >= ${linkFuncs.length}u) porf_unreachable("bad function index");
  const u8 flags = porf_fnflags[idx] & (7u | ${FN_CORO_INIT}u);
  const u8 kind = flags & 7u;
  if (!porf_jv_eq(newtv, JV_UNDEFINED) && kind != 0) porf_throw_new(${TYPES.typeerror}, 0);
  ${usesCoro || usesSyncAsync ? `if (kind != 0) {
    ${usesSyncAsync ? `if (kind == ${FN_ASYNC}u && !porf_fnneeds_coro[idx]) return porf_async_call_sync(idx, fn, env, thisv, newtv, argc, argv);` : ''}
    ${usesCoro ? 'return porf_coro_start(flags, idx, fn, env, thisv, newtv, argc, argv);' : 'porf_unreachable("bad coroutine dispatch");'}
  }` : ''}
  return porf_invoke(idx, fn, env, thisv, newtv, argc, argv);
}
// spread calls use array iteration semantics: holes become present undefined values.
${st}jsval porf_call_dynamic_arr(jsval fn, jsval thisv, jsval newtv, jsval arr) {
  const u32 a = (u32)arr.val;
  const i32 argc = PORF_ARR_LEN(a);
  jsbits* argv = (jsbits*)(MEM + PORF_ARR_ENT(a));
  for (i32 i = 0; i < argc; i++) {
    if (argv[i] == 0) {
      jsbits* dense = argc > 0 ? (jsbits*)malloc((size_t)argc * sizeof(jsbits)) : NULL;
      for (i32 j = 0; j < argc; j++) dense[j] = argv[j] == 0 ? JV_UNDEFINED_BITS : argv[j];
      const jsval out = porf_call_dynamic(fn, thisv, newtv, argc, dense);
      free(dense);
      return out;
    }
  }
  return porf_call_dynamic(fn, thisv, newtv, argc, argv);
}\n`);

  if (entry) {
    // units read the arena base as a constant: nothing using it shares a function with its init
    emit(`PORF_NOINLINE static void porf_start(void) {\n  porf_data_init();\n  ${fnSym(funcByName.get(entry))}();\n}\n` +
      `int main(int argc, char** argv) {\n  porf_init(argc, argv);\n  ${gcEnabled ? 'volatile int porf_stack_anchor = 0;\n  porf_c_stack_top = (void*)&porf_stack_anchor;\n  ' : ''}porf_start();\n  return 0;\n}\n`);
  }

  if (usesMath) prelude.splice(1, 0, '#include <math.h>\n');
  // raw c may call the link prototypes
  const rawHead = prefs.rawHead ? prefs.rawHead + '\n' : '';

  const globalTypes = Object.create(null);
  for (const g of globals) globalTypes[g.name] = g.type;
  const unitText = (u, parts) => {
    const text = [];
    if (split) {
      text.push('#define PORF_SET_ONCE const\n#include "porf.h"\n');
      // rendered first: their tests add to what the unit references
      const protos = parts.protos.filter(Boolean).sort((a, b) => linkIdx[a.index] - linkIdx[b.index]);
      cur = parts;
      const tests = protos.map(guard);
      for (const x of Object.keys(parts.fnbases).sort()) text.push(`extern const u32 porf_fnbase_${sanitize(x)};\n`);
      for (const x of Object.keys(parts.dbases).sort()) text.push(`extern const u32 porf_dbase_${sanitize(x)};\n`);
      for (const x of Object.keys(parts.zbases).sort()) text.push(`extern const u32 porf_zbase_${sanitize(x)};\n`);
      for (const x of Object.keys(parts.globals).sort()) text.push(`extern ${CT[globalTypes[x]]} ${sanitize(x)};\n`);
      for (const f of protos) text.push(proto(f));
      for (const x of tests) text.push(x);
      text.push('\n');
      if (u === 'main') text.push(link.join(''));
    }
    return text.concat(parts.chunks, parts.out).join('');
  };

  if (!split) {
    const text = prelude.concat(link, rawHead);
    for (const u of unitOrder) if (unitParts[u]) text.push(unitText(u, unitParts[u]));
    return text.join('');
  }

  const rt = splitRuntime(prelude.join('') + rawHead);
  const header = rt.header +
    `extern const u8 porf_fnflags[];\n${usesSyncAsync ? 'extern const u8 porf_fnneeds_coro[];\n' : ''}extern const u16 porf_fnlen[];\nextern const u32 porf_fnname[];\nextern const u32 porf_fnrecs;\n` +
    linkProtos.join('');
  const unitName = u => {
    const name = units?.find(x => x.id === u)?.name;
    return name ? name.replace(/^[/]/, '').replace(/[^\w.-]/g, '_') + '.' + u + '.c' : `porf_${sanitize(u)}.c`;
  };
  const files = [
    { name: 'porf.h', c: header },
    { name: 'porf_runtime.c', c: '#include "porf.h"\n' + runtimeRefs.map(proto).join('') + rt.impl }
  ];
  for (const u of unitOrder) if (unitParts[u]) files.push({ name: unitName(u), c: unitText(u, unitParts[u]) });
  return { files };
};

// split runtime C into header declarations and implementation
const splitRuntime = text => {
  const header = [], impl = [];
  const n = text.length;
  let i = 0;
  while (i < n) {
    while (i < n && (text[i] === ' ' || text[i] === '\t' || text[i] === '\n')) i++;
    if (i >= n) break;
    const start = i;

    if (text[i] === '#') {
      let end = text.indexOf('\n', i);
      if (end === -1) end = n;
      while (text[end - 1] === '\\') end = text.indexOf('\n', end + 1);
      header.push(text.slice(start, end));
      impl.push(text.slice(start, end));
      i = end;
      continue;
    }
    if (text.startsWith('//', i)) {
      const end = text.indexOf('\n', i);
      header.push(text.slice(start, end));
      i = end;
      continue;
    }

    let depth = 0, braceAt = -1, eqAt = -1, parenAt = -1;
    for (; i < n; i++) {
      const c = text[i];
      if (c === '"' || c === "'") {
        for (i++; text[i] !== c; i++) if (text[i] === '\\') i++;
        continue;
      }
      if (c === '/' && text[i + 1] === '/') { i = text.indexOf('\n', i); continue; }
      if (c === '/' && text[i + 1] === '*') { i = text.indexOf('*/', i) + 1; continue; }
      if (depth === 0 && c === '\n' && text[i + 1] === '#') break;
      if (depth === 0 && braceAt === -1) {
        if (c === '=' && eqAt === -1 && text[i + 1] !== '=') eqAt = i;
        if (c === '(' && eqAt === -1 && parenAt === -1) parenAt = i;
      }
      if (c === '{') { if (braceAt === -1) braceAt = i; depth++; }
      else if (c === '}') {
        depth--;
        // a type or initializer runs on to its `;`, a function body ends here
        if (depth === 0 && eqAt === -1 && !/^(?:(?:static|const)\s+)*(?:typedef|struct|union|enum)\b/.test(text.slice(start, braceAt))) { i++; break; }
      }
      else if (c === ';' && depth === 0) { i++; break; }
    }
    const chunk = text.slice(start, i);
    const spec = chunk.slice(0, Math.min(...[ parenAt, eqAt, braceAt, i ].filter(x => x !== -1)) - start);
    const isType = /^(?:typedef|struct|union|enum)\b/.test(chunk);
    const isFunc = !isType && parenAt !== -1 && braceAt !== -1 && eqAt === -1;
    const isProto = !isType && parenAt !== -1 && braceAt === -1 && eqAt === -1 && !/\(\*\w+\)/.test(chunk);
    const unstatic = str => str.replace(/\bstatic\s+/, '');

    // const tables without a size stay per unit, sizeof needs their initializer
    if (isType || /^extern\b/.test(chunk) || (!isFunc && /^static\s+const\b/.test(chunk) && /\[\]\s*$/.test(chunk.slice(0, eqAt - start)))) header.push(chunk);
    else if (isFunc && /\binline\b/.test(spec)) {
      // c99 inline: one shared copy instead of one per unit
      header.push(unstatic(chunk));
      impl.push('extern ' + unstatic(chunk.slice(0, braceAt - start)).trim() + ';');
    } else if (isFunc) {
      header.push(unstatic(chunk.slice(0, braceAt - start)).trim() + ';');
      impl.push(unstatic(chunk));
    } else if (isProto) header.push(unstatic(chunk));
    else {
      header.push('extern ' + unstatic(eqAt === -1 ? chunk.slice(0, -1) : chunk.slice(0, eqAt - start)).trim() + ';');
      impl.push(unstatic(chunk));
    }
  }
  return { header: header.join('\n') + '\n', impl: impl.join('\n\n') + '\n' };
};

const PORF_BUMP_ALLOC = () => {
  const st = 'static ';
  const sti = 'static inline ';
  return `// fixed-address reserve; commit-on-demand; NEVER moves. 32-bit offsets.
static u32 porf_heap_base = 0;
static u32 porf_heap_cur = 0;
static u32 porf_heap_committed = 0;

static void porf_commit(u32 end) {
  if (end <= porf_heap_committed) return;
  u32 want = (end + (1u << 20)) & ~((1u << 20) - 1);
  if (!PORF_CAN_DECOMMIT || mprotect(MEM, want, PROT_READ | PROT_WRITE) != 0) {
    fprintf(stderr, "porffor: out of memory (commit %u)\\n", want);
    exit(1);
  }
  porf_heap_committed = want;
}

static void porf_arena_init(void) {
  void* got = mmap(PORF_ARENA_HINT, PORF_ARENA_RESERVE, PORF_MMAP_RESERVE_PROT,
    MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (got == MAP_FAILED) {
    fprintf(stderr, "porffor: failed to reserve arena\\n");
    exit(1);
  }
  porf_mem = (u8*)got;
#ifdef MADV_NOHUGEPAGE
  // transparent huge pages would make every touched 4K of the arena (and the gc's tables) resident 2M
  (void)madvise(got, PORF_ARENA_RESERVE, MADV_NOHUGEPAGE);
#endif
  porf_heap_base = (porf_static_end + 4095u) & ~4095u;
  porf_heap_cur = porf_heap_base + 8;
  porf_heap_committed = PORF_CAN_DECOMMIT ? 0u : (u32)PORF_ARENA_RESERVE;
  porf_commit(porf_heap_base + 65536u);
}

${st}u32 porf_alloc_slow(u32 bytes);
${sti}u32 porf_alloc(u32 bytes, u32 typeId) {
  const u32 size = (bytes + 7u) & ~7u;
  const u32 p = porf_heap_cur;
  const u32 next = p + size;
  (void)typeId;
  if (next <= porf_heap_committed) {
    porf_heap_cur = next;
    return p;
  }
  return porf_alloc_slow(size);
}
${st}u32 porf_alloc_slow(u32 size) {
  porf_commit(porf_heap_cur + size);
  const u32 p = porf_heap_cur;
  porf_heap_cur = p + size;
  return p;
}

${st}void porf_gc_barrier_impl(u32 p, i32 type) { (void)p; (void)type; }
${sti}void porf_gc_barrier_slot(u32 owner, u32 block, u32 slot) { (void)owner; (void)block; (void)slot; }
${sti}void porf_gc_entries_moved(u32 from, u32 to) { (void)from; (void)to; }
${sti}int porf_gc_type_can_reference(i32 type) { (void)type; return 0; }
${st}i64 porf_gc_idle_due(void) { return -1; }
${st}void porf_gc_idle(void) {}
${st}void porf_gc_quiet(void) {}
${st}void porf_gc_seal_heap(void) {}
${st}void porf_gc_set_limit(u64 bytes) { (void)bytes; }
static inline u32 porf_gc_barrier_ptr_u32(u32 p) { return p; }
static inline u32 porf_gc_barrier_ptr_i32(i32 p) { return (u32)p; }
static inline u32 porf_gc_barrier_ptr_jsval(jsval v) { return (u32)v.val; }
#define porf_gc_barrier(p, type) porf_gc_barrier_impl(_Generic((p), jsval: porf_gc_barrier_ptr_jsval, i32: porf_gc_barrier_ptr_i32, default: porf_gc_barrier_ptr_u32)(p), (type))
#define porf_gc_card(p) ((void)(p))
static void* porf_c_stack_top = NULL;
${st}i32 porf_gc_native_root_add(f64 value, i32 type) { (void)value; (void)type; return -1; }
${st}void porf_gc_native_root_remove(i32 slot) { (void)slot; }
${st}void porf_gc_collect(int minor) { (void)minor; }

`;
};

const PORF_GC_ALLOC = () => {
  const st = 'static ';
  const sti = 'static inline ';

  // size is implicit from the page so objects need no headers
  const classes = [];
  for (let s = 16; s <= 256; s += 16) classes.push(s);
  for (let s = 288; s <= 512; s += 32) classes.push(s);
  for (let s = 576; s <= 1024; s += 64) classes.push(s);
  for (let s = 1152; s <= 2048; s += 128) classes.push(s);
  for (let s = 2304; s <= 4096; s += 256) classes.push(s);
  for (let s = 4608; s <= 8192; s += 512) classes.push(s);
  const slotMasks = [], slotMaskAt = [];
  for (const c of classes) {
    const stride = c / 16;
    slotMaskAt.push(slotMasks.length);
    if (stride > 64) continue;
    for (let phase = 0; phase < stride; phase++) {
      let mask = 0n;
      for (let b = 0; b < 64; b++) if ((b + phase) % stride === 0) mask |= 1n << BigInt(b);
      slotMasks.push(`0x${mask.toString(16)}ull`);
    }
  }
  const lut = [];
  let ci = 0;
  for (let g = 0; g <= 1024; g++) {
    while (classes[ci] < g * 8) ci++;
    lut.push(ci);
  }
  // use multi-page chunks when they reduce tail waste
  const chunkPages = classes.map(c => {
    let best = 1, bw = (8192 - Math.floor(8192 / c) * c) / 8192;
    for (let n = 2; n <= 6; n++) {
      const waste = (n * 8192 - Math.floor(n * 8192 / c) * c) / (n * 8192);
      if (waste < bw - 0.005) { bw = waste; best = n; }
    }
    return best;
  });

  return `static u32 porf_heap_base = 0;
static u32 porf_heap_top = 0;
static u64 porf_heap_committed = 0;

#define PORF_GC_SPAGE 8192u
#define PORF_GC_SPAGE_MASK 8191u
#define PORF_GC_SPAGE_SHIFT 13
#define PORF_GC_NPAGES (1u << 19)
#define PORF_GC_NCLASSES ${classes.length}
#define PORF_GC_MAX_SMALL 8192u
// from 1MB, doubles while collections come fast and halves once they slow (porf_gc_cycle)
static u32 porf_gc_nursery_bytes = 1048576u;

static const u16 porf_gc_cls_size[PORF_GC_NCLASSES] = { ${classes.join(', ')} };
static const u8 porf_gc_cls_pages[PORF_GC_NCLASSES] = { ${chunkPages.join(', ')} };
static const u16 porf_gc_cls_slots[PORF_GC_NCLASSES] = { ${classes.map((c, i) => Math.floor(chunkPages[i] * 8192 / c)).join(', ')} };
static const u8 porf_gc_cls_lut[1025] = { ${lut.join(',')} };
// slot start bits of a 64 granule word, per class with a slot every <= 64 granules and per word phase
static const u64 porf_gc_slot_masks[] = { ${slotMasks.join(', ')} };
static const u16 porf_gc_slot_mask_at[PORF_GC_NCLASSES] = { ${slotMaskAt.join(', ')} };

// kind bytes: 0 conservative, 1..195 type IDs, 245+ internal
#define PORF_GC_KIND_WEAK 246u
#define PORF_GC_KIND_CORO 247u
#define PORF_GC_KIND_OBJECT_VALUES 245u
#define PORF_GC_KIND_OBJECT_ENTRIES 249u
#define PORF_GC_KIND_ARRAY_ENTRIES 250u
#define PORF_GC_KIND_FUNCTION 251u
#define PORF_GC_KIND_UNDERLYING_STORE 252u
#define PORF_GC_KIND_REGEX_CACHE 253u
#define PORF_GC_KIND_LEAF 254u

#define PORF_GC_PK_SMALL 1u
#define PORF_GC_PK_SPAN 2u
#define PORF_GC_PK_TAIL 3u

#define PORF_GC_PF_TOUCHED 1u
#define PORF_GC_PF_PARTIAL 4u
#define PORF_GC_PF_TAIL 8u
#define PORF_GC_PF_SEALED 16u

struct porf_gc_page {
  u16 cls;
  u8 flags;
  u8 cidx;
  u16 cursor;
  u16 pad;
  u32 aux; // span page count, tail head index or next partial chunk plus 1
};

static u8* porf_gc_kinds = NULL;
// interleave metadata planes so each granule shares a cache line
static u64* porf_gc_meta = NULL;
#define PORF_GC_B_ALLOC 0u
#define PORF_GC_B_MARK 1u
#define PORF_GC_B_YOUNG 2u
#define porf_gc_widx(g) ((((size_t)(g) >> 9) << 5) | ((size_t)(((g) >> 6) & 7u) << 2))
static u8* porf_gc_cards = NULL;
static u8* porf_gc_page_kind = NULL;
static struct porf_gc_page* porf_gc_pages = NULL;
static u64 porf_gc_free_pages[PORF_GC_NPAGES / 64];
static u32 porf_gc_free_page_cursor = 0;
static u32 porf_gc_free_page_count = 0;

#define porf_gc_gran(p) ((u32)(p) >> 4)
#define porf_gc_bit(plane, g) ((porf_gc_meta[porf_gc_widx(g) + (plane)] >> ((g) & 63u)) & 1ull)
#define porf_gc_bit_set(plane, g) (porf_gc_meta[porf_gc_widx(g) + (plane)] |= 1ull << ((g) & 63u))
#define porf_gc_bit_clear(plane, g) (porf_gc_meta[porf_gc_widx(g) + (plane)] &= ~(1ull << ((g) & 63u)))

struct porf_gc_window { u32 cur, end, lo; };
static struct porf_gc_window porf_gc_active[PORF_GC_NCLASSES];
static u32 porf_gc_partial[PORF_GC_NCLASSES];
// the fork template's heap top and live bytes at the seal (0: no template)
static u32 porf_gc_template_top = 0;
static u64 porf_gc_template_live = 0;

static u64 porf_gc_last_live_bytes = 0;
static u64 porf_gc_live_bytes = 0;
static i64 porf_gc_window_bytes = 0;
static i64 porf_gc_span_bytes = 0;
static i64 porf_gc_claimed_since_full = 0;
static i64 porf_gc_promoted_since_full = 0;
static u64 porf_gc_young_survived = 0;
static int porf_gc_minor_mode = 0;
static int porf_gc_scan_young_seen = 0;

static u32* porf_gc_touched = NULL;
static i32 porf_gc_touched_len = 0;
static i32 porf_gc_touched_cap = 0;

static u32* porf_gc_weakmaps = NULL;
static i32 porf_gc_weakmaps_len = 0;
static i32 porf_gc_weakmaps_cap = 0;

struct porf_gc_mark_item { u32 body; i32 type; };
static struct porf_gc_mark_item* porf_gc_mark_queue = NULL;
static i32 porf_gc_mark_queue_len = 0;
static i32 porf_gc_mark_queue_cap = 0;

struct porf_gc_boxed_mark { f64 value; i32 type; };
static struct porf_gc_boxed_mark* porf_gc_boxed_marks = NULL;
static i32 porf_gc_boxed_marks_len = 0;
static i32 porf_gc_boxed_marks_cap = 0;

static u64* porf_gc_static_marks = NULL;
static i32 porf_gc_static_marks_len = 0;
static i32 porf_gc_static_marks_cap = 0;

${st}void porf_gc_collect(int minor);
static void porf_gc_mark_js(f64 value, i32 type);
static void porf_gc_mark_js_now(f64 value, i32 type);
static void porf_gc_mark_raw(i32 body);
static int porf_gc_mark_underlying_store(i32 body);
static int porf_gc_compact_underlying_store(i32 body);
static u32 porf_gc_underlying_old = 0;
static void porf_gc_mark_regex_cache(i32 cache);
static void porf_gc_mark_coro(u32 body);
static void porf_gc_scan_coro(i32 body);
static void porf_gc_cons_scan_range(const u64* lo, const u64* hi);
static void porf_gc_mark_global_roots(void);
static void porf_gc_mark_global_raw_roots(void);
static int porf_gc_mark_underlying_stores(void);
static void porf_gc_compact_underlying_stores(void);
static void porf_gc_mark_coro_roots(void);
static void porf_gc_scan_kind_block(i32 body);
static void porf_gc_mark_weak_array(i32 arr);
static void porf_gc_scan_body(i32 body, i32 type);
static void porf_gc_scan_object_entries_range(i32 entries, u32 from, u32 to);
static void porf_gc_scan_object_values_range(i32 values, u32 from, u32 to);
static u32 porf_gc_values_slots(u32 bytes);
static u32 porf_gc_span_alloc(u32 bytes, u32 typeId);

static inline u32 porf_gc_align(u32 size) { return (size + 7u) & ~7u; }

static inline u8 porf_gc_kind_for_type(u32 typeId) {
  if (typeId == 0u) return (u8)PORF_GC_KIND_LEAF;
  return typeId <= 195u ? (u8)typeId : 0u;
}

static void porf_commit(u64 end) {
  if (end <= porf_heap_committed) return;
  const u64 want = (end + (1ull << 20)) & ~((1ull << 20) - 1ull);
  if (want > PORF_ARENA_RESERVE) {
    fprintf(stderr, "porffor: out of memory (commit %llu)\\n", (unsigned long long)want);
    exit(1);
  }
  if (PORF_CAN_DECOMMIT && mprotect(MEM + porf_heap_committed, (size_t)(want - porf_heap_committed), PROT_READ | PROT_WRITE) != 0) {
    fprintf(stderr, "porffor: out of memory (commit %llu)\\n", (unsigned long long)want);
    exit(1);
  }
  porf_heap_committed = want;
}

// the heap skips offsets aliasing the low halves of the executable's addresses, false conservative roots
static u32 porf_gc_alias_lo = 0, porf_gc_alias_hi = 0;
static void porf_gc_alias_init(void) {
#if defined(__APPLE__) && !defined(__TINYC__)
  const struct mach_header_64* h = (const struct mach_header_64*)_dyld_get_image_header(0);
  const u64 slide = (u64)_dyld_get_image_vmaddr_slide(0);
  u64 lo = ~0ull, hi = 0;
  const struct load_command* lc = (const struct load_command*)(h + 1);
  for (u32 i = 0; i < h->ncmds; i++, lc = (const struct load_command*)((const u8*)lc + lc->cmdsize)) {
    if (lc->cmd != LC_SEGMENT_64) continue;
    const struct segment_command_64* seg = (const struct segment_command_64*)lc;
    if (seg->initprot == 0) continue;
    if (seg->vmaddr + slide < lo) lo = seg->vmaddr + slide;
    if (seg->vmaddr + slide + seg->vmsize > hi) hi = seg->vmaddr + slide + seg->vmsize;
  }
#elif defined(__linux__) && !defined(__TINYC__)
  extern char __executable_start[], _end[];
  const u64 lo = (u64)(uintptr_t)__executable_start, hi = (u64)(uintptr_t)_end;
#else
  const u64 lo = 0, hi = 0;
#endif
  if (hi <= lo || (lo >> 32) != ((hi - 1u) >> 32)) return;
  porf_gc_alias_lo = (u32)lo & ~PORF_GC_SPAGE_MASK;
  porf_gc_alias_hi = (u32)((((hi - 1u) & 0xFFFFFFFFull) | PORF_GC_SPAGE_MASK) + 1u);
}

static void porf_arena_init(void) {
  void* got = mmap(PORF_ARENA_HINT, PORF_ARENA_RESERVE, PORF_MMAP_RESERVE_PROT,
    MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  if (got == MAP_FAILED) {
    fprintf(stderr, "porffor: failed to reserve arena\\n");
    exit(1);
  }
  porf_mem = (u8*)got;
#ifdef MADV_NOHUGEPAGE
  // transparent huge pages would make every touched 4K of the arena (and the gc's tables) resident 2M
  (void)madvise(got, PORF_ARENA_RESERVE, MADV_NOHUGEPAGE);
#endif
  porf_heap_base = (porf_static_end + PORF_GC_SPAGE_MASK) & ~PORF_GC_SPAGE_MASK;
  porf_heap_top = porf_heap_base;
  porf_gc_alias_init();
  porf_heap_committed = PORF_CAN_DECOMMIT ? 0ull : (u64)PORF_ARENA_RESERVE;
  porf_commit(porf_heap_base + 65536u);

  const size_t kinds_bytes = (size_t)(PORF_ARENA_RESERVE >> 4);
  const size_t bits_bytes = (size_t)(PORF_ARENA_RESERVE >> 4 >> 3);
  const size_t cards_bytes = (size_t)(PORF_ARENA_RESERVE >> 9);
  const size_t pk_bytes = (size_t)PORF_GC_NPAGES;
  const size_t pm_bytes = (size_t)PORF_GC_NPAGES * sizeof(struct porf_gc_page);
  const size_t side_bytes = kinds_bytes + bits_bytes * 4 + cards_bytes + pk_bytes + pm_bytes;
  u8* side = (u8*)mmap(NULL, side_bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
  if (side == MAP_FAILED) {
    fprintf(stderr, "porffor: failed to reserve gc metadata\\n");
    exit(1);
  }
#ifdef MADV_NOHUGEPAGE
  (void)madvise(side, side_bytes, MADV_NOHUGEPAGE);
#endif
  porf_gc_kinds = side; side += kinds_bytes;
  porf_gc_meta = (u64*)side; side += bits_bytes * 4;
  porf_gc_cards = side; side += cards_bytes;
  porf_gc_page_kind = side; side += pk_bytes;
  porf_gc_pages = (struct porf_gc_page*)side;
}

static inline int porf_gc_in_heap(i32 body) {
  return body > 0 && (u32)body >= porf_heap_base && (u32)body < porf_heap_top;
}
static inline int porf_gc_in_static(i32 body) {
  return body > 0 && (u32)body < porf_heap_base;
}
static inline int porf_gc_static_range(i32 ptr, u64 bytes) {
  return ptr > 0 && (u64)(u32)ptr + bytes <= (u64)porf_heap_base;
}

// allocation bits are only set on object bases
static inline int porf_gc_is_block_start(i32 body) {
  return body > 0 && porf_gc_bit(PORF_GC_B_ALLOC, porf_gc_gran(body)) != 0u;
}
static inline int porf_gc_is_young(i32 body) {
  return porf_gc_bit(PORF_GC_B_YOUNG, porf_gc_gran(body)) != 0u;
}
static inline u32 porf_gc_block_size(i32 body) {
  const u32 pg = (u32)body >> PORF_GC_SPAGE_SHIFT;
  const u8 k = porf_gc_page_kind[pg];
  if (k == PORF_GC_PK_SMALL) return porf_gc_pages[pg].cls;
  if (k == PORF_GC_PK_SPAN) return porf_gc_pages[pg].aux << PORF_GC_SPAGE_SHIFT;
  return 0;
}
static inline u32 porf_gc_kind(i32 body) {
  if (!porf_gc_is_block_start(body)) return 0;
  return porf_gc_kinds[porf_gc_gran(body)];
}
// accept freshly bumped objects before allocation bits are published
static inline u32 porf_gc_chunk_start(u32 pg) {
  const u32 head = (porf_gc_pages[pg].flags & PORF_GC_PF_TAIL) != 0u ? porf_gc_pages[pg].aux : pg;
  return head << PORF_GC_SPAGE_SHIFT;
}

static inline void porf_gc_set_kind(i32 body, u32 kind) {
  if (porf_heap_base == 0 || body <= 0) return;
  const u32 pg = (u32)body >> PORF_GC_SPAGE_SHIFT;
  const u8 k = porf_gc_page_kind[pg];
  if (k == PORF_GC_PK_SMALL) {
    if (((u32)body - porf_gc_chunk_start(pg)) % porf_gc_pages[pg].cls != 0u) return;
  } else if (k == PORF_GC_PK_SPAN) {
    if (((u32)body & PORF_GC_SPAGE_MASK) != 0u) return;
  } else return;
  if (porf_gc_kinds[porf_gc_gran(body)] != (u8)kind) porf_gc_kinds[porf_gc_gran(body)] = (u8)kind;
}

static inline void porf_gc_set_marked_type(i32 body, i32 type) {
  if (porf_gc_bit(PORF_GC_B_MARK, porf_gc_gran(body)) == 0u) porf_gc_bit_set(PORF_GC_B_MARK, porf_gc_gran(body));
  if (porf_gc_kinds[porf_gc_gran(body)] != (u8)type) porf_gc_kinds[porf_gc_gran(body)] = (u8)type;
}
static inline int porf_gc_has_marked_type(i32 body, i32 type) {
  if (!porf_gc_is_block_start(body)) return 0;
  const u32 g = porf_gc_gran(body);
  return porf_gc_bit(PORF_GC_B_MARK, g) != 0u && porf_gc_kinds[g] == (u8)type;
}

static void porf_gc_touch_list(u32 pg) {
  if ((porf_gc_pages[pg].flags & PORF_GC_PF_TOUCHED) != 0u) return;
  porf_gc_pages[pg].flags |= PORF_GC_PF_TOUCHED;
  if (porf_gc_touched_len == porf_gc_touched_cap) {
    const i32 nc = porf_gc_touched_cap == 0 ? 1024 : porf_gc_touched_cap * 2;
    u32* grown = realloc(porf_gc_touched, (size_t)nc * sizeof(u32));
    if (!grown) abort();
    porf_gc_touched = grown;
    porf_gc_touched_cap = nc;
  }
  porf_gc_touched[porf_gc_touched_len++] = pg;
}

static inline void porf_gc_free_page_release(u32 pg) {
  porf_gc_page_kind[pg] = 0;
  porf_gc_free_pages[pg >> 6] |= 1ull << (pg & 63u);
  porf_gc_free_page_count++;
  if (pg < porf_gc_free_page_cursor) porf_gc_free_page_cursor = pg;
}

static u32 porf_gc_free_page_pop(void) {
  if (porf_gc_free_page_count == 0) return 0;
  u32 w = porf_gc_free_page_cursor >> 6;
  const u32 words = porf_heap_top >> PORF_GC_SPAGE_SHIFT >> 6;
  while (w <= words) {
    const u64 word = porf_gc_free_pages[w];
    if (word != 0) {
      const u32 pg = (w << 6) + (u32)__builtin_ctzll(word);
      porf_gc_free_pages[w] &= word - 1;
      porf_gc_free_page_count--;
      porf_gc_free_page_cursor = pg + 1;
      return pg;
    }
    w++;
  }
  porf_gc_free_page_count = 0;
  return 0;
}

static u64 porf_gc_settled_live(void);
static i64 porf_gc_survival;
static int porf_gc_full_due(i64 additional_claimed) {
  const u64 live_limit = porf_gc_last_live_bytes > 268435456ull ? porf_gc_last_live_bytes : 268435456ull;
  // settled, so what a full gc keeps alive of in-flight work does not raise the limit for the next one
  // what little survives a nursery mostly dies soon after, so a full gc pays off sooner
  u64 promoted_limit = porf_gc_settled_live() * (porf_gc_survival > 25 ? 2u : 1u);
  if (promoted_limit > 536870912ull) promoted_limit = 536870912ull;
  const i64 claimed = porf_gc_claimed_since_full + additional_claimed;
  return claimed > (i64)live_limit || porf_gc_promoted_since_full > (i64)promoted_limit ||
    (porf_heap_top > 1610612736u && claimed > 67108864ll);
}

static u32 porf_gc_run_cursor = 0;

// exact-size cache for common same-size churn
#define PORF_GC_RUN_CACHE_MAX 16u
static u32 porf_gc_run_cache[PORF_GC_RUN_CACHE_MAX + 1][8];
static u8 porf_gc_run_cache_len[PORF_GC_RUN_CACHE_MAX + 1];

static void porf_gc_release_run(u32 lo, u32 npg) {
  for (u32 k = 0; k < npg; k++) porf_gc_page_kind[lo + k] = 0;
  if (npg >= 2u && npg <= PORF_GC_RUN_CACHE_MAX && porf_gc_run_cache_len[npg] < 8u) {
    porf_gc_run_cache[npg][porf_gc_run_cache_len[npg]++] = lo;
    return;
  }
  for (u32 k = 0; k < npg; k++) porf_gc_free_page_release(lo + k);
}

static void porf_gc_run_cache_drain(void) {
  for (u32 n = 2; n <= PORF_GC_RUN_CACHE_MAX; n++) {
    while (porf_gc_run_cache_len[n] > 0) {
      const u32 lo = porf_gc_run_cache[n][--porf_gc_run_cache_len[n]];
      for (u32 k = 0; k < n; k++) porf_gc_free_page_release(lo + k);
    }
  }
}

static u32 porf_gc_pool_run(u32 npg) {
  if (npg == 1u) return porf_gc_free_page_pop();
  if (npg <= PORF_GC_RUN_CACHE_MAX && porf_gc_run_cache_len[npg] > 0)
    return porf_gc_run_cache[npg][--porf_gc_run_cache_len[npg]];
  if (porf_gc_free_page_count < npg) return 0;
  u32 lo = 0;
  const u32 base = porf_heap_base >> PORF_GC_SPAGE_SHIFT;
  const u32 top = porf_heap_top >> PORF_GC_SPAGE_SHIFT;
  u32 resume = porf_gc_run_cursor;
  if (resume < base || resume >= top) resume = base;
  for (int pass = 0; pass < 2 && lo == 0; pass++) {
    const u32 from = pass == 0 ? resume : base;
    const u32 until = pass == 0 ? top : resume;
    u32 run = 0, start = 0;
    for (u32 pg = from; pg < until; pg++) {
      if (run == 0 && (pg & 63u) == 0u && porf_gc_free_pages[pg >> 6] == 0ull) {
        pg += 63u;
        continue;
      }
      if ((porf_gc_free_pages[pg >> 6] & (1ull << (pg & 63u))) != 0u) {
        if (run == 0) start = pg;
        if (++run == npg) { lo = start; break; }
      } else run = 0;
    }
  }
  if (lo != 0) {
    for (u32 k = 0; k < npg; k++) {
      const u32 pg = lo + k;
      porf_gc_free_pages[pg >> 6] &= ~(1ull << (pg & 63u));
      porf_gc_free_page_count--;
    }
    porf_gc_run_cursor = lo + npg;
  }
  return lo;
}

static u32 porf_gc_claim_pages(u32 npg) {
  u32 lo = porf_gc_pool_run(npg);
  if (lo == 0) {
    if (porf_gc_full_due((i64)npg * (i64)PORF_GC_SPAGE)) {
      porf_gc_collect(0);
      lo = porf_gc_pool_run(npg);
    }
    if (lo == 0) {
      if ((u64)porf_heap_top + (u64)npg * PORF_GC_SPAGE >= PORF_ARENA_RESERVE) {
        porf_gc_collect(0);
        lo = porf_gc_pool_run(npg);
        if (lo == 0 && (u64)porf_heap_top + (u64)npg * PORF_GC_SPAGE >= PORF_ARENA_RESERVE) return 0;
      }
      if (lo == 0) {
        if (porf_heap_top < porf_gc_alias_hi && porf_heap_top + npg * PORF_GC_SPAGE > porf_gc_alias_lo) porf_heap_top = porf_gc_alias_hi;
        porf_commit((u64)porf_heap_top + (u64)npg * PORF_GC_SPAGE);
        lo = porf_heap_top >> PORF_GC_SPAGE_SHIFT;
        porf_heap_top += npg * PORF_GC_SPAGE;
      }
    }
  }
  porf_gc_claimed_since_full += (i64)npg * (i64)PORF_GC_SPAGE;
  return lo;
}

// the first slot from i whose alloc bit is want, a 64 granule word at a time when slots are that dense
static u32 porf_gc_find_slot(u32 base_addr, i32 ci, u32 i, u32 slots, u32 want) {
  const u32 cls = porf_gc_cls_size[ci], stride = cls >> 4;
  if (stride > 64u) {
    while (i < slots && (u32)porf_gc_bit(PORF_GC_B_ALLOC, porf_gc_gran(base_addr + i * cls)) != want) i++;
    return i;
  }
  const u64* masks = porf_gc_slot_masks + porf_gc_slot_mask_at[ci];
  const u32 g0 = porf_gc_gran(base_addr), end = slots * stride;
  for (u32 rel = i * stride; rel < end; rel = (rel & ~63u) + 64u) {
    const u32 word_rel = rel & ~63u;
    const u64 alloc = porf_gc_meta[porf_gc_widx(g0 + word_rel) + PORF_GC_B_ALLOC];
    const u64 hits = (want ? alloc : ~alloc) & masks[word_rel % stride] & (~0ull << (rel & 63u));
    if (hits != 0ull) {
      const u32 slot = (word_rel + (u32)__builtin_ctzll(hits)) / stride;
      return slot < slots ? slot : slots;
    }
  }
  return slots;
}

static int porf_gc_install_run(i32 ci, u32 pg) {
  if ((porf_gc_pages[pg].flags & PORF_GC_PF_SEALED) != 0u) return 0;
  struct porf_gc_window* w = &porf_gc_active[ci];
  struct porf_gc_page* m = &porf_gc_pages[pg];
  const u32 cls = porf_gc_cls_size[ci];
  const u32 slots = porf_gc_cls_slots[ci];
  const u32 base_addr = pg << PORF_GC_SPAGE_SHIFT;
  const u32 i = porf_gc_find_slot(base_addr, ci, m->cursor, slots, 0);
  if (i >= slots) { m->cursor = (u16)slots; return 0; }
  const u32 j = porf_gc_find_slot(base_addr, ci, i + 1, slots, 1);
  m->cursor = (u16)j;
  w->lo = w->cur = base_addr + i * cls;
  w->end = base_addr + j * cls;
  porf_gc_touch_list(pg);
  return 1;
}

static void porf_gc_publish_window(i32 ci) {
  struct porf_gc_window* w = &porf_gc_active[ci];
  const u32 cls = porf_gc_cls_size[ci], stride = cls >> 4;
  if (stride > 64u) {
    for (u32 b = w->lo; b < w->cur; b += cls) {
      const u32 g = porf_gc_gran(b);
      porf_gc_bit_set(PORF_GC_B_ALLOC, g);
      porf_gc_bit_set(PORF_GC_B_YOUNG, g);
    }
  } else if (w->cur > w->lo) {
    // a 64 granule word of slot starts at a time
    const u64* masks = porf_gc_slot_masks + porf_gc_slot_mask_at[ci];
    const u32 g0 = porf_gc_gran(porf_gc_chunk_start(w->lo >> PORF_GC_SPAGE_SHIFT));
    const u32 hi = porf_gc_gran(w->cur);
    for (u32 g = porf_gc_gran(w->lo); g < hi; g = (g & ~63u) + 64u) {
      const u32 base = g & ~63u;
      u64 bits = masks[(base - g0) % stride] & (~0ull << (g & 63u));
      if (hi - base < 64u) bits &= (1ull << (hi - base)) - 1ull;
      u64* word = porf_gc_meta + porf_gc_widx(g);
      word[PORF_GC_B_ALLOC] |= bits;
      word[PORF_GC_B_YOUNG] |= bits;
    }
  }
  // the nursery counts what was handed out, not the runs installed for it
  porf_gc_window_bytes += (i64)(w->cur - w->lo);
  w->lo = w->cur;
}

static int porf_gc_refill_window(i32 ci) {
  struct porf_gc_window* w = &porf_gc_active[ci];
  if (w->end != 0) {
    const u32 pg = porf_gc_chunk_start((w->end - 1u) >> PORF_GC_SPAGE_SHIFT) >> PORF_GC_SPAGE_SHIFT;
    porf_gc_publish_window(ci);
    w->cur = w->end = w->lo = 0;
    if (porf_gc_install_run(ci, pg)) return 1;
  }
  while (porf_gc_partial[ci] != 0) {
    const u32 pg = porf_gc_partial[ci] - 1u;
    struct porf_gc_page* m = &porf_gc_pages[pg];
    porf_gc_partial[ci] = m->aux;
    m->aux = 0;
    if (porf_gc_page_kind[pg] != PORF_GC_PK_SMALL || m->cidx != (u8)ci ||
      (m->flags & PORF_GC_PF_PARTIAL) == 0u) continue;
    m->flags &= (u8)~PORF_GC_PF_PARTIAL;
    if (porf_gc_install_run(ci, pg)) return 1;
  }
  const u32 npg = porf_gc_cls_pages[ci];
  const u32 pg = porf_gc_claim_pages(npg);
  if (pg == 0) return 0;
  struct porf_gc_page* m = &porf_gc_pages[pg];
  m->cls = porf_gc_cls_size[ci];
  m->flags = 0;
  m->cidx = (u8)ci;
  m->cursor = (u16)porf_gc_cls_slots[ci];
  m->aux = 0;
  porf_gc_page_kind[pg] = PORF_GC_PK_SMALL;
  for (u32 k = 1; k < npg; k++) {
    struct porf_gc_page* tm = &porf_gc_pages[pg + k];
    tm->cls = porf_gc_cls_size[ci];
    tm->flags = PORF_GC_PF_TAIL;
    tm->cidx = (u8)ci;
    tm->cursor = 0;
    tm->aux = pg;
    porf_gc_page_kind[pg + k] = PORF_GC_PK_SMALL;
  }
  w->lo = w->cur = pg << PORF_GC_SPAGE_SHIFT;
  w->end = (pg << PORF_GC_SPAGE_SHIFT) + (u32)porf_gc_cls_slots[ci] * porf_gc_cls_size[ci];
  porf_gc_touch_list(pg);
  return 1;
}

${st}u32 porf_alloc_slow(u32 bytes, u32 typeId);
${sti}u32 porf_alloc_window(u32 ci, u32 typeId) {
  struct porf_gc_window* w = &porf_gc_active[ci];
  const u32 cur = w->cur;
  if (cur < w->end) {
    w->cur = cur + porf_gc_cls_size[ci];
    porf_gc_kinds[cur >> 4] = porf_gc_kind_for_type(typeId);
    if (typeId == 0u) memset(MEM + cur, 0, porf_gc_cls_size[ci]);
    return cur;
  }
  return porf_alloc_slow(porf_gc_cls_size[ci], typeId);
}
${st}PORF_NOINLINE u32 porf_alloc_cls(u32 ci, u32 typeId) { return porf_alloc_window(ci, typeId); }
${sti}u32 porf_alloc(u32 bytes, u32 typeId) {
  if (bytes > PORF_GC_MAX_SMALL) return porf_alloc_slow(bytes, typeId);
  const u32 ci = porf_gc_cls_lut[(bytes + 7u) >> 3];
  // a constant size calls its class's allocator instead of inlining it at every site
  return __builtin_constant_p(bytes) ? porf_alloc_cls(ci, typeId) : porf_alloc_window(ci, typeId);
}

static void porf_gc_cycle(i64 allocated);
static i64 porf_gc_budget(void);

${st}u32 porf_alloc_slow(u32 bytes, u32 typeId) {
  if (porf_heap_base == 0) {
    porf_arena_init();
    return porf_alloc_slow(bytes, typeId);
  }
  const i64 allocated = porf_gc_window_bytes + porf_gc_span_bytes;
  if (allocated >= porf_gc_budget()) {
    porf_gc_span_bytes = 0;
    porf_gc_cycle(allocated);
  }
  if (bytes > PORF_GC_MAX_SMALL) return porf_gc_span_alloc(bytes, typeId);
  const u32 ci = porf_gc_cls_lut[(bytes + 7u) >> 3];
  if (porf_gc_refill_window((i32)ci)) return porf_alloc(bytes, typeId);
  fprintf(stderr, "porffor: out of memory (gc heap limit; req=%u live=%lluMB heap_top=%u)\\n",
    bytes, (unsigned long long)(porf_gc_live_bytes / 1048576ull), porf_heap_top);
  abort();
}

static u32 porf_gc_span_alloc(u32 bytes, u32 typeId) {
  const u32 npg = (bytes + PORF_GC_SPAGE_MASK) >> PORF_GC_SPAGE_SHIFT;
  const u32 lo = porf_gc_claim_pages(npg);
  if (lo == 0) {
    fprintf(stderr, "porffor: out of memory (span %u pages; heap_top=%u)\\n", npg, porf_heap_top);
    abort();
  }
  porf_gc_span_bytes += (i64)npg * (i64)PORF_GC_SPAGE;
  porf_gc_page_kind[lo] = PORF_GC_PK_SPAN;
  porf_gc_pages[lo].cls = 0;
  porf_gc_pages[lo].flags = 0;
  porf_gc_pages[lo].cursor = 0;
  porf_gc_pages[lo].aux = npg;
  for (u32 k = 1; k < npg; k++) {
    porf_gc_page_kind[lo + k] = PORF_GC_PK_TAIL;
    porf_gc_pages[lo + k].aux = lo;
  }
  const u32 body = lo << PORF_GC_SPAGE_SHIFT;
  const u32 g = porf_gc_gran(body);
  porf_gc_bit_set(PORF_GC_B_ALLOC, g);
  porf_gc_bit_set(PORF_GC_B_YOUNG, g);
  porf_gc_bit_clear(PORF_GC_B_MARK, g);
  porf_gc_kinds[g] = porf_gc_kind_for_type(typeId);
  if (typeId == 0u) memset(MEM + body, 0, (size_t)npg * PORF_GC_SPAGE);
  porf_gc_touch_list(lo);
  return body;
}

${st}void porf_gc_barrier_reclassify(u32 p, i32 type) {
  const u32 pg = p >> PORF_GC_SPAGE_SHIFT;
  const u8 k = porf_gc_page_kind[pg];
  if (k == PORF_GC_PK_SMALL) {
    if ((p - porf_gc_chunk_start(pg)) % porf_gc_pages[pg].cls != 0u) return;
  } else if (k == PORF_GC_PK_SPAN) {
    if ((p & PORF_GC_SPAGE_MASK) != 0u) return;
  } else return;
  if (porf_gc_kinds[p >> 4] != (u8)type) porf_gc_kinds[p >> 4] = (u8)type;
}
// only old blocks need cards, young ones (and window blocks, with no alloc bit) are traced in full
static inline int porf_gc_old_block(u32 p) {
  if (p < porf_heap_base) return 1;
  const u32 g = porf_gc_gran(p);
  const u64* w = porf_gc_meta + porf_gc_widx(g);
  return ((w[PORF_GC_B_ALLOC] & ~w[PORF_GC_B_YOUNG]) >> (g & 63u)) & 1ull;
}
${sti}void porf_gc_barrier_impl(u32 p, i32 type) {
  if (porf_heap_base == 0 || p == 0) return;
  if (porf_gc_old_block(p)) porf_gc_cards[p >> 9] = 1;
  if (type <= 0) return;
  if (type > 195 && type < 248) return;
  if (porf_gc_kinds[p >> 4] == (u8)type || porf_gc_kinds[p >> 4] == PORF_GC_KIND_WEAK) return;
  porf_gc_barrier_reclassify(p, type);
}
// entries that aren't their own heap block (static, views) are scanned through their owner
${sti}void porf_gc_barrier_slot(u32 owner, u32 block, u32 slot) {
  if (porf_heap_base == 0) return;
  if (block < porf_heap_base || !porf_gc_is_block_start((i32)block)) porf_gc_barrier_impl(owner, ${TYPES.array});
    else if (porf_gc_old_block(block)) porf_gc_cards[slot >> 9] = 1;
}
// a new entries block is scanned per card from the start, the old one is garbage that may point at freed blocks
${sti}void porf_gc_entries_moved(u32 from, u32 to) {
  if (porf_heap_base == 0) return;
  porf_gc_set_kind((i32)to, PORF_GC_KIND_ARRAY_ENTRIES);
  if (from >= porf_heap_base) porf_gc_set_kind((i32)from, PORF_GC_KIND_LEAF);
}
static inline u32 porf_gc_barrier_ptr_u32(u32 p) { return p; }
static inline u32 porf_gc_barrier_ptr_i32(i32 p) { return (u32)p; }
static inline u32 porf_gc_barrier_ptr_jsval(jsval v) { return (u32)v.val; }
#define porf_gc_ptr(p) _Generic((p), jsval: porf_gc_barrier_ptr_jsval, i32: porf_gc_barrier_ptr_i32, default: porf_gc_barrier_ptr_u32)(p)
#define porf_gc_barrier(p, type) porf_gc_barrier_impl(porf_gc_ptr(p), (type))
// stores into containers allocated with their type only need the card marked
static inline void porf_gc_card_impl(u32 p) { if (porf_heap_base != 0 && porf_gc_old_block(p)) porf_gc_cards[p >> 9] = 1; }
#define porf_gc_card(p) porf_gc_card_impl(porf_gc_ptr(p))

static void* porf_c_stack_top = NULL;

${sti}int porf_gc_type_can_reference(i32 type) {
  switch (type) {
    case ${TYPES.undefined}:
    case ${TYPES.number}:
    case ${TYPES.boolean}:
    case ${TYPES.numberobject}:
    case ${TYPES.booleanobject}:
      return 0;
  }
  return 1;
}

static inline i32 porf_gc_value_body(f64 value, i32 type) {
  if (type == ${TYPES.bigint}) {
    if (value < 2251799813685248.0) return 0;
    value -= 2251799813685248.0;
  }
  return (i32)value;
}

static int porf_gc_object_shape_valid(i32 body) {
  if (!porf_gc_is_block_start(body)) return 0;
  const u32 block_size = porf_gc_block_size(body);
  if (block_size < 16u) return 0;
  const u32 size = *(u16*)(MEM + body);
  const u32 capacity = *(u16*)(MEM + body + 2);
  if (size > capacity) return 0;
  const i32 entries = *(u32*)(MEM + body + 12);
  if (entries == 0) return size == 0;
  // shaped objects keep values (see __Porffor_object_valuesBytes), dictionaries entries
  const u64 entry_bytes = *(u16*)(MEM + body + 6) == 0 ? (u64)capacity * 20ull : capacity <= 8u ? 8ull + (u64)capacity * 8ull : (u64)capacity * 9ull;
  if (entries == body + 16) return 16ull + entry_bytes <= (u64)block_size;
  if (porf_gc_in_static(entries)) return porf_gc_static_range(entries, entry_bytes);
  if (!porf_gc_is_block_start(entries)) return 0;
  return entry_bytes <= (u64)porf_gc_block_size(entries);
}

static int porf_gc_static_object_shape_valid(i32 body) {
  if (!porf_gc_static_range(body, 16ull)) return 0;
  const u32 size = *(u16*)(MEM + body);
  const u32 capacity = *(u16*)(MEM + body + 2);
  if (size > capacity) return 0;
  const i32 entries = *(u32*)(MEM + body + 12);
  if (entries == 0) return size == 0;
  // shaped objects keep values (see __Porffor_object_valuesBytes), dictionaries entries
  const u64 entry_bytes = *(u16*)(MEM + body + 6) == 0 ? (u64)capacity * 20ull : capacity <= 8u ? 8ull + (u64)capacity * 8ull : (u64)capacity * 9ull;
  if (entries == body + 16) return porf_gc_static_range(body, 16ull + entry_bytes);
  if (porf_gc_in_static(entries)) return porf_gc_static_range(entries, entry_bytes);
  if (!porf_gc_is_block_start(entries)) return 0;
  return entry_bytes <= (u64)porf_gc_block_size(entries);
}

static int porf_gc_array_like_shape_valid(i32 body) {
  if (!porf_gc_is_block_start(body)) return 0;
  const u32 block_size = porf_gc_block_size(body);
  if (block_size < 16u) return 0;
  u32 len = *(u32*)(MEM + body);
  const i32 entries = *(u32*)(MEM + body + 4);
  const u32 capacity = *(u32*)(MEM + body + 8);
  if (len > capacity) len = capacity;
  const u64 bytes = (u64)len * 8ull;
  if (entries == body + 16) return 16ull + bytes <= (u64)block_size;
  if (porf_gc_in_static(entries)) return porf_gc_static_range(entries, bytes);
  if (!porf_gc_is_block_start(entries)) return 0;
  return bytes <= (u64)porf_gc_block_size(entries);
}

static int porf_gc_static_array_like_shape_valid(i32 body) {
  if (!porf_gc_static_range(body, 16ull)) return 0;
  u32 len = *(u32*)(MEM + body);
  const i32 entries = *(u32*)(MEM + body + 4);
  const u32 capacity = *(u32*)(MEM + body + 8);
  if (len > capacity) len = capacity;
  const u64 bytes = (u64)len * 8ull;
  if (entries == body + 16) return porf_gc_static_range(body, 16ull + bytes);
  if (porf_gc_in_static(entries)) return porf_gc_static_range(entries, bytes);
  if (!porf_gc_is_block_start(entries)) return 0;
  return bytes <= (u64)porf_gc_block_size(entries);
}

static void porf_gc_enqueue_mark(i32 body, i32 type) {
  if (porf_gc_mark_queue_len == porf_gc_mark_queue_cap) {
    const i32 new_cap = porf_gc_mark_queue_cap == 0 ? 4096 : porf_gc_mark_queue_cap * 2;
    struct porf_gc_mark_item* grown = realloc(porf_gc_mark_queue, (size_t)new_cap * sizeof(*grown));
    if (!grown) abort();
    porf_gc_mark_queue = grown;
    porf_gc_mark_queue_cap = new_cap;
  }
  porf_gc_mark_queue[porf_gc_mark_queue_len++] = (struct porf_gc_mark_item){ (u32)body, type };
}

static int porf_gc_mark_body(i32 body) {
  if (body <= 0) return 0;
  const u32 g = porf_gc_gran(body);
  if (porf_gc_bit(PORF_GC_B_ALLOC, g) == 0u) return 0;
  if (porf_gc_minor_mode) {
    if (porf_gc_bit(PORF_GC_B_YOUNG, g) == 0u) return 0;
    porf_gc_scan_young_seen = 1;
  }
  if (porf_gc_bit(PORF_GC_B_MARK, g) != 0u) return 0;
  porf_gc_bit_set(PORF_GC_B_MARK, g);
  return 1;
}

static void porf_gc_mark_raw(i32 body) {
  if (body <= 0) return;
  const u32 g = porf_gc_gran(body);
  if (porf_gc_bit(PORF_GC_B_ALLOC, g) == 0u) return;
  if (porf_gc_minor_mode && porf_gc_bit(PORF_GC_B_YOUNG, g) == 0u) return;
  if (porf_gc_bit(PORF_GC_B_MARK, g) == 0u) porf_gc_bit_set(PORF_GC_B_MARK, g);
}

static void porf_gc_mark_boxed_primitive(f64 value, i32 type) {
  for (i32 i = 0; i < porf_gc_boxed_marks_len; i++)
    if (porf_gc_boxed_marks[i].type == type && porf_gc_boxed_marks[i].value == value) return;
  if (porf_gc_boxed_marks_len == porf_gc_boxed_marks_cap) {
    const i32 new_cap = porf_gc_boxed_marks_cap == 0 ? 64 : porf_gc_boxed_marks_cap * 2;
    struct porf_gc_boxed_mark* grown = realloc(porf_gc_boxed_marks, (size_t)new_cap * sizeof(*grown));
    if (!grown) abort();
    porf_gc_boxed_marks = grown;
    porf_gc_boxed_marks_cap = new_cap;
  }
  porf_gc_boxed_marks[porf_gc_boxed_marks_len++] = (struct porf_gc_boxed_mark){ value, type };
}
static int porf_gc_is_marked_boxed_primitive(f64 value, i32 type) {
  for (i32 i = 0; i < porf_gc_boxed_marks_len; i++)
    if (porf_gc_boxed_marks[i].type == type && porf_gc_boxed_marks[i].value == value) return 1;
  return 0;
}

static inline u64 porf_gc_static_mark_key(i32 body, i32 type) {
  return ((u64)(u32)body << 8) | (u64)(u32)(type & 0xff) | (1ull << 63);
}
static inline u64 porf_gc_static_mark_hash(u64 key) {
  key ^= key >> 33;
  key *= 0xff51afd7ed558ccdull;
  key ^= key >> 33;
  return key;
}
static int porf_gc_static_is_marked(i32 body, i32 type) {
  if (porf_gc_static_marks_cap == 0) return 0;
  const u64 key = porf_gc_static_mark_key(body, type);
  const u32 mask = (u32)porf_gc_static_marks_cap - 1u;
  u32 pos = (u32)porf_gc_static_mark_hash(key) & mask;
  while (porf_gc_static_marks[pos] != 0) {
    if (porf_gc_static_marks[pos] == key) return 1;
    pos = (pos + 1u) & mask;
  }
  return 0;
}
static void porf_gc_static_marks_grow(void) {
  const i32 old_cap = porf_gc_static_marks_cap;
  u64* old = porf_gc_static_marks;
  const i32 new_cap = old_cap == 0 ? 1024 : old_cap * 2;
  u64* grown = calloc((size_t)new_cap, sizeof(u64));
  if (!grown) abort();
  porf_gc_static_marks = grown;
  porf_gc_static_marks_cap = new_cap;
  if (old != NULL) {
    const u32 mask = (u32)new_cap - 1u;
    for (i32 i = 0; i < old_cap; i++) {
      const u64 key = old[i];
      if (key == 0) continue;
      u32 pos = (u32)porf_gc_static_mark_hash(key) & mask;
      while (porf_gc_static_marks[pos] != 0) pos = (pos + 1u) & mask;
      porf_gc_static_marks[pos] = key;
    }
    free(old);
  }
}
static int porf_gc_mark_static(i32 body, i32 type) {
  if (porf_gc_static_is_marked(body, type)) return 0;
  if (porf_gc_static_marks_len * 2 >= porf_gc_static_marks_cap) porf_gc_static_marks_grow();
  const u64 key = porf_gc_static_mark_key(body, type);
  const u32 mask = (u32)porf_gc_static_marks_cap - 1u;
  u32 pos = (u32)porf_gc_static_mark_hash(key) & mask;
  while (porf_gc_static_marks[pos] != 0) pos = (pos + 1u) & mask;
  porf_gc_static_marks[pos] = key;
  porf_gc_static_marks_len++;
  return 1;
}

static int porf_gc_is_marked_js(f64 value, i32 type) {
  switch (type) {
    case ${TYPES.undefined}:
    case ${TYPES.number}:
    case ${TYPES.boolean}:
      return 1;
    case ${TYPES.numberobject}:
    case ${TYPES.booleanobject}:
      return porf_gc_is_marked_boxed_primitive(value, type);
  }
  const i32 body = porf_gc_value_body(value, type);
  if (body == 0) return 1;
  if (porf_gc_in_static(body)) return porf_gc_static_is_marked(body, type);
  const u32 g = porf_gc_gran(body);
  if (porf_gc_bit(PORF_GC_B_ALLOC, g) == 0u) return 0;
  if (porf_gc_minor_mode && porf_gc_bit(PORF_GC_B_YOUNG, g) == 0u) return 1;
  return porf_gc_bit(PORF_GC_B_MARK, g) != 0u;
}

struct porf_gc_native_root {
  f64 value;
  i32 type;
};
static struct porf_gc_native_root* porf_gc_native_roots = NULL;
static i32 porf_gc_native_roots_len = 0;
static i32 porf_gc_native_roots_cap = 0;
static i32* porf_gc_native_root_free_slots = NULL;
static i32 porf_gc_native_root_free_slots_len = 0;
static i32* porf_gc_native_root_active = NULL;
static i32* porf_gc_native_root_active_pos = NULL;
static i32 porf_gc_native_root_active_len = 0;
i32 porf_gc_native_root_add(f64 value, i32 type) {
  if (porf_gc_native_root_free_slots_len == 0 && porf_gc_native_roots_len == porf_gc_native_roots_cap) {
    i32 new_cap = porf_gc_native_roots_cap == 0 ? 64 : porf_gc_native_roots_cap * 2;
    struct porf_gc_native_root* grown = realloc(porf_gc_native_roots, (size_t)new_cap * sizeof(*grown));
    i32* grown_free_slots = realloc(porf_gc_native_root_free_slots, (size_t)new_cap * sizeof(*grown_free_slots));
    i32* grown_active = realloc(porf_gc_native_root_active, (size_t)new_cap * sizeof(*grown_active));
    i32* grown_active_pos = realloc(porf_gc_native_root_active_pos, (size_t)new_cap * sizeof(*grown_active_pos));
    if (!grown || !grown_free_slots || !grown_active || !grown_active_pos) abort();
    for (i32 i = porf_gc_native_roots_cap; i < new_cap; i++) {
      grown[i].type = ${TYPES.undefined};
      grown_active_pos[i] = -1;
    }
    porf_gc_native_roots = grown;
    porf_gc_native_root_free_slots = grown_free_slots;
    porf_gc_native_root_active = grown_active;
    porf_gc_native_root_active_pos = grown_active_pos;
    porf_gc_native_roots_cap = new_cap;
  }
  i32 slot;
  if (porf_gc_native_root_free_slots_len > 0) slot = porf_gc_native_root_free_slots[--porf_gc_native_root_free_slots_len];
    else slot = porf_gc_native_roots_len++;
  porf_gc_native_roots[slot].value = value;
  porf_gc_native_roots[slot].type = type;
  porf_gc_native_root_active_pos[slot] = porf_gc_native_root_active_len;
  porf_gc_native_root_active[porf_gc_native_root_active_len++] = slot;
  return slot;
}

void porf_gc_native_root_remove(i32 slot) {
  if (slot < 0 || slot >= porf_gc_native_roots_len) return;
  if (porf_gc_native_roots[slot].type == ${TYPES.undefined}) return;
  porf_gc_native_roots[slot].value = 0;
  porf_gc_native_roots[slot].type = ${TYPES.undefined};
  porf_gc_native_root_free_slots[porf_gc_native_root_free_slots_len++] = slot;
  const i32 pos = porf_gc_native_root_active_pos[slot];
  const i32 last_slot = porf_gc_native_root_active[--porf_gc_native_root_active_len];
  if (pos != porf_gc_native_root_active_len) {
    porf_gc_native_root_active[pos] = last_slot;
    porf_gc_native_root_active_pos[last_slot] = pos;
  }
  porf_gc_native_root_active_pos[slot] = -1;
}

static void porf_gc_mark_native_roots(void) {
  for (i32 i = 0; i < porf_gc_native_root_active_len; i++) {
    const i32 slot = porf_gc_native_root_active[i];
    porf_gc_mark_js(porf_gc_native_roots[slot].value, porf_gc_native_roots[slot].type);
  }
}

static void porf_gc_mark_array_entries(i32 entries, u32 len) {
  for (u32 i = 0; i < len; i++) {
    const jsbits b = *(jsbits*)(MEM + entries + ((u64)i << 3));
    if (b == 0) continue;
    const jsval v = porf_unpack(b);
    if (porf_gc_type_can_reference(v.type)) porf_gc_mark_js(v.val, v.type);
  }
}

static void porf_gc_mark_array_like(i32 body) {
  u32 len = *(u32*)(MEM + body);
  i32 entries = *(u32*)(MEM + body + 4);
  const u32 capacity = *(u32*)(MEM + body + 8);
  if (len > capacity) len = capacity;
  if (entries == body + 16) {
    if (porf_gc_is_block_start(body)) {
      const u32 block_size = porf_gc_block_size(body);
      const u32 max_len = block_size >= 16u ? (block_size - 16u) / 8u : 0u;
      if (len > max_len) len = max_len;
    } else if (!porf_gc_static_range(body, 16ull + (u64)len * 8ull)) return;
    porf_gc_mark_array_entries(entries, len);
    return;
  }
  if (porf_gc_is_block_start(entries)) {
    const u32 max_len = porf_gc_block_size(entries) / 8u;
    if (len > max_len) len = max_len;
    porf_gc_mark_body(entries);
    porf_gc_set_kind(entries, PORF_GC_KIND_ARRAY_ENTRIES);
    porf_gc_mark_array_entries(entries, len);
    return;
  }
  if (porf_gc_in_static(entries)) {
    if (!porf_gc_static_range(entries, (u64)len * 8ull)) return;
    porf_gc_mark_array_entries(entries, len);
  }
}

static void porf_gc_mark_jsbits(jsbits bits) {
  const jsval v = porf_unpack(bits);
  if (porf_gc_type_can_reference(v.type)) porf_gc_mark_js(v.val, v.type);
}

static void porf_gc_mark_promise_reaction(u32 raw);

static void porf_gc_mark_promise_reaction_chain(u32 raw) {
  while (raw != 0) {
    const u32 next = *(u32*)(MEM + raw + PORF_REACTION_NEXT);
    porf_gc_mark_promise_reaction(raw);
    raw = next;
  }
}

static void porf_gc_scan_promise_reaction(u32 raw) {
  const u8 kind = *(u8*)(MEM + raw + PORF_REACTION_KIND);
  if (kind == 11) porf_gc_mark_coro((u32)*(u64*)(MEM + raw + PORF_REACTION_HANDLER));
    else porf_gc_mark_jsbits(*(jsbits*)(MEM + raw + PORF_REACTION_HANDLER));
  porf_gc_mark_jsbits(*(jsbits*)(MEM + raw + PORF_REACTION_OUT_PROMISE));
  porf_gc_mark_jsbits(*(jsbits*)(MEM + raw + PORF_REACTION_VALUE));
  porf_gc_mark_jsbits(*(jsbits*)(MEM + raw + PORF_REACTION_CONTEXT));
}

static void porf_gc_mark_promise_reaction(u32 raw) {
  if (raw == 0 || !porf_gc_is_block_start((i32)raw)) return;
  if (!porf_gc_mark_body((i32)raw) && porf_gc_kind((i32)raw) == PORF_GC_KIND_PROMISE_REACTION) return;
  porf_gc_set_kind((i32)raw, PORF_GC_KIND_PROMISE_REACTION);
  porf_gc_scan_promise_reaction(raw);
}

static void porf_gc_mark_promise_jobs(void) {
  porf_gc_mark_jsbits(porf_async_context);
  for (u32 i = 0; i < porf_promise_job_len; i++) {
    porf_gc_mark_promise_reaction(porf_promise_job_queue[(porf_promise_job_head + i) & (porf_promise_job_cap - 1u)]);
  }
}

static void porf_gc_mark_promise_body(i32 body) {
  porf_gc_mark_jsbits(*(jsbits*)(MEM + body + PORF_PROMISE_RESULT));
  porf_gc_mark_promise_reaction_chain(*(u32*)(MEM + body + PORF_PROMISE_FULFILL_HEAD));
  porf_gc_mark_promise_reaction_chain(*(u32*)(MEM + body + PORF_PROMISE_REJECT_HEAD));
  porf_gc_mark_jsbits(*(jsbits*)(MEM + body + PORF_PROMISE_PAYLOAD));
}

static int porf_gc_has_marked_array_like_type(i32 body) {
  return porf_gc_has_marked_type(body, ${TYPES.array});
}
static int porf_gc_has_marked_type_simple(i32 body, i32 type) {
  return porf_gc_has_marked_type(body, type);
}

static int porf_gc_should_rescan_marked_body(i32 body, i32 type) {
  switch (type) {
    case ${TYPES.object}:
      return !porf_gc_has_marked_type(body, type) && porf_gc_object_shape_valid(body);
    case ${TYPES.array}:
      return !porf_gc_has_marked_array_like_type(body) && porf_gc_array_like_shape_valid(body);
    case ${TYPES.promise}:
      return !porf_gc_has_marked_type_simple(body, type);
    case ${TYPES.__porffor_closureenv}:
    case ${TYPES.function}:
    case ${TYPES.map}:
    case ${TYPES.set}:
    case ${TYPES.weakmap}:
    case ${TYPES.weakset}:
    case ${TYPES.__porffor_generator}:
    case ${TYPES.__porffor_asyncgenerator}:
    case ${TYPES.symbol}:
    case ${TYPES.weakref}:
    case ${TYPES.error}:
    case ${TYPES.aggregateerror}:
    case ${TYPES.typeerror}:
    case ${TYPES.referenceerror}:
    case ${TYPES.syntaxerror}:
    case ${TYPES.rangeerror}:
    case ${TYPES.evalerror}:
    case ${TYPES.urierror}:
    case ${TYPES.suppressederror}:
    case ${TYPES.disposablestack}:
    case ${TYPES.asyncdisposablestack}:
    case ${TYPES.finalizationregistry}:
    case ${TYPES.regexp}:
    case ${TYPES.dataview}:
    case ${TYPES.uint8clampedarray}:
    case ${TYPES.uint8array}:
    case ${TYPES.int8array}:
    case ${TYPES.uint16array}:
    case ${TYPES.int16array}:
    case ${TYPES.uint32array}:
    case ${TYPES.int32array}:
    case ${TYPES.float32array}:
    case ${TYPES.float64array}:
    case ${TYPES.bigint64array}:
    case ${TYPES.biguint64array}:
      return !porf_gc_has_marked_type(body, type);
  }
  return 0;
}

static void porf_gc_scan_body(i32 body, i32 type) {
  switch (type) {
    case ${TYPES.__porffor_closureenv}: {
      const u32 parent = *(u32*)(MEM + body);
      if (parent != 0) porf_gc_mark_js((f64)parent, ${TYPES.__porffor_closureenv});
      const u32 count = *(u32*)(MEM + body + 4);
      for (u32 i = 0; i < count; i++) {
        const u32 slot = body + 8u + i * 16u;
        const u8 tag = *(u8*)(MEM + slot + 8);
        if (porf_gc_type_can_reference(tag)) porf_gc_mark_js(*(f64*)(MEM + slot), tag);
      }
      break;
    }
    case ${TYPES.object}: {
      const i32 proto = *(u32*)(MEM + body + 8);
      const i32 proto_type = *(u8*)(MEM + body + 5);
      if (proto != 0 || proto_type != ${TYPES.undefined}) porf_gc_mark_js((f64)proto, proto_type);
      u32 size = *(u16*)(MEM + body);
      const i32 entries = *(u32*)(MEM + body + 12);
      const int shaped = *(u16*)(MEM + body + 6) != 0;
      if (entries != 0 && entries != body + 16) {
        porf_gc_mark_body(entries);
        porf_gc_set_kind(entries, shaped ? PORF_GC_KIND_OBJECT_VALUES : PORF_GC_KIND_OBJECT_ENTRIES);
        if (porf_gc_is_block_start(entries)) {
          const u32 max_size = shaped ? porf_gc_values_slots(porf_gc_block_size(entries)) : porf_gc_block_size(entries) / 20u;
          if (size > max_size) size = max_size;
        }
      }
      if (shaped) porf_gc_scan_object_values_range(entries, 0, size);
        else porf_gc_scan_object_entries_range(entries, 0, size);
      break;
    }
    case ${TYPES.array}:
      porf_gc_mark_array_like(body);
      break;
    case ${TYPES.__porffor_rope}: {
      const u32 buf = *(u32*)(MEM + body + 4), flat = *(u32*)(MEM + body + 8);
      porf_gc_mark_body(buf);
      if (flat != 0) porf_gc_mark_js((f64)flat, *(u32*)(MEM + buf + 8) ? ${TYPES.string} : ${TYPES.bytestring});
      break;
    }
    case ${TYPES.promise}:
      porf_gc_mark_promise_body(body);
      break;
    case ${TYPES.__porffor_generator}:
    case ${TYPES.__porffor_asyncgenerator}:
      porf_gc_scan_coro(body);
      break;
    case ${TYPES.function}: {
      const i32 env = *(u32*)(MEM + body + 4);
      if (env != 0) porf_gc_mark_js((f64)env, ${TYPES.__porffor_closureenv});
      break;
    }
    case ${TYPES.map}:
    case ${TYPES.set}:
    case ${TYPES.weakset}: {
      const i32 keys = *(u32*)(MEM + body);
      const i32 vals = *(u32*)(MEM + body + 4);
      const i32 buckets = *(u32*)(MEM + body + 8);
      if (keys != 0) porf_gc_mark_js((f64)keys, ${TYPES.array});
      if (vals != 0) porf_gc_mark_js((f64)vals, ${TYPES.array});
      if (buckets != 0) porf_gc_mark_body(buckets);
      break;
    }
    case ${TYPES.weakmap}: {
      for (i32 i = 0; i < porf_gc_weakmaps_len; i++) if (porf_gc_weakmaps[i] == (u32)body) goto weakmap_seen;
      if (porf_gc_weakmaps_len == porf_gc_weakmaps_cap) {
        const i32 new_cap = porf_gc_weakmaps_cap == 0 ? 64 : porf_gc_weakmaps_cap * 2;
        u32* grown = realloc(porf_gc_weakmaps, (size_t)new_cap * sizeof(*grown));
        if (!grown) abort();
        porf_gc_weakmaps = grown;
        porf_gc_weakmaps_cap = new_cap;
      }
      porf_gc_weakmaps[porf_gc_weakmaps_len++] = (u32)body;
weakmap_seen:
      {
        const i32 keys = *(u32*)(MEM + body);
        const i32 vals = *(u32*)(MEM + body + 4);
        const i32 buckets = *(u32*)(MEM + body + 8);
        porf_gc_mark_weak_array(keys);
        porf_gc_mark_weak_array(vals);
        if (buckets != 0) porf_gc_mark_body(buckets);
      }
      break;
    }
    case ${TYPES.symbol}:
    case ${TYPES.weakref}: {
      const jsval v = porf_unpack(*(jsbits*)(MEM + body));
      porf_gc_mark_js(v.val, v.type);
      break;
    }
    case ${TYPES.error}:
    case ${TYPES.aggregateerror}:
    case ${TYPES.typeerror}:
    case ${TYPES.referenceerror}:
    case ${TYPES.syntaxerror}:
    case ${TYPES.rangeerror}:
    case ${TYPES.evalerror}:
    case ${TYPES.urierror}:
    case ${TYPES.suppressederror}:
    case ${TYPES.disposablestack}:
    case ${TYPES.asyncdisposablestack}:
    case ${TYPES.finalizationregistry}: {
      const jsval v = porf_unpack(*(jsbits*)(MEM + body));
      porf_gc_mark_js(v.val, v.type);
      break;
    }
    case ${TYPES.regexp}: {
      porf_gc_mark_js((f64)(*(u32*)(MEM + body)), ${TYPES.bytestring});
      const i32 re_blob = *(u32*)(MEM + body + 12);
      if (re_blob != 0) porf_gc_mark_body(re_blob);
      const i32 re_names = *(u32*)(MEM + body + 16);
      if (re_names != 0) porf_gc_mark_js((f64)re_names, ${TYPES.array});
      break;
    }
    case ${TYPES.dataview}: {
      const i32 ptr = *(u32*)(MEM + body + 4);
      const i32 byte_offset = *(u32*)(MEM + body + 8);
      const i32 buffer = ptr - byte_offset - 4;
      if (ptr != 0) porf_gc_mark_body(buffer);
      break;
    }
    case ${TYPES.uint8clampedarray}:
    case ${TYPES.uint8array}:
    case ${TYPES.int8array}:
    case ${TYPES.uint16array}:
    case ${TYPES.int16array}:
    case ${TYPES.uint32array}:
    case ${TYPES.int32array}:
    case ${TYPES.float32array}:
    case ${TYPES.float64array}:
    case ${TYPES.bigint64array}:
    case ${TYPES.biguint64array}: {
      const i32 ptr = *(u32*)(MEM + body + 4);
      if (ptr != 0) porf_gc_mark_body(ptr - *(u32*)(MEM + body + 8) - 4);
      break;
    }
  }
}

static void porf_gc_mark_js_now(f64 value, i32 type) {
  // proxies ([ target, handler ]) and builtin iterators are arrays
  if (type == ${TYPES.proxy}${ITERATOR_TYPES.map(x => ` || type == ${x}`).join('')}) type = ${TYPES.array};
  switch (type) {
    case ${TYPES.undefined}:
    case ${TYPES.number}:
    case ${TYPES.boolean}:
      return;
    case ${TYPES.numberobject}:
    case ${TYPES.booleanobject}:
      porf_gc_mark_boxed_primitive(value, type);
      return;
  }
  const i32 body = porf_gc_value_body(value, type);
  if (body == 0) return;
  // static strings hold no references and are never freed
  if ((u32)body < porf_heap_base && (type == ${TYPES.bytestring} || type == ${TYPES.string})) return;
  if (porf_gc_is_block_start(body)) {
    if (porf_gc_template_top != 0 && (u32)body < porf_gc_template_top && (porf_gc_pages[(u32)body >> PORF_GC_SPAGE_SHIFT].flags & PORF_GC_PF_SEALED) != 0u) return;
    // skip header reads for old or already-marked blocks
    const u32 g = porf_gc_gran(body);
    if (porf_gc_minor_mode && porf_gc_bit(PORF_GC_B_YOUNG, g) == 0u) return;
    if (porf_gc_bit(PORF_GC_B_MARK, g) != 0u && porf_gc_kinds[g] == (u8)type) {
      porf_gc_scan_young_seen |= porf_gc_minor_mode;
      return;
    }
    if (type == ${TYPES.object} && !porf_gc_object_shape_valid(body)) return;
    if (!porf_gc_mark_body(body)) {
      if (porf_gc_should_rescan_marked_body(body, type)) {
        porf_gc_set_marked_type(body, type);
        porf_gc_enqueue_mark(body, type);
      }
      return;
    }
    porf_gc_set_marked_type(body, type);
    porf_gc_enqueue_mark(body, type);
    return;
  }
  if (!porf_gc_in_static(body)) return;
  switch (type) {
    case ${TYPES.object}:
      if (!porf_gc_static_object_shape_valid(body)) return;
      break;
    case ${TYPES.array}:
      if (!porf_gc_static_array_like_shape_valid(body)) return;
      break;
    case ${TYPES.promise}:
      return;
    case ${TYPES.__porffor_generator}:
    case ${TYPES.__porffor_asyncgenerator}:
      return;
    case ${TYPES.string}:
    case ${TYPES.bytestring}:
    case ${TYPES.function}:
    case ${TYPES.bigint}:
    case ${TYPES.symbol}:
    case ${TYPES.regexp}:
    case ${TYPES.date}:
    case ${TYPES.map}:
    case ${TYPES.set}:
    case ${TYPES.weakmap}:
    case ${TYPES.weakset}:
    case ${TYPES.weakref}:
    case ${TYPES.error}:
    case ${TYPES.aggregateerror}:
    case ${TYPES.typeerror}:
    case ${TYPES.referenceerror}:
    case ${TYPES.syntaxerror}:
    case ${TYPES.rangeerror}:
    case ${TYPES.evalerror}:
    case ${TYPES.urierror}:
    case ${TYPES.suppressederror}:
    case ${TYPES.disposablestack}:
    case ${TYPES.asyncdisposablestack}:
    case ${TYPES.finalizationregistry}:
      break;
    default:
      return;
  }
  if (!porf_gc_mark_static(body, type)) return;
  porf_gc_enqueue_mark(body, type);
}

// once the heap outgrows the caches, edges wait in a ring while their mark bits, kind and header are prefetched
#define PORF_GC_RING 16u
#ifdef __TINYC__
#define porf_gc_prefetch(p) ((void)(p))
#else
#define porf_gc_prefetch(p) __builtin_prefetch(p)
#endif
struct porf_gc_ring_item { f64 value; i32 type; };
static struct porf_gc_ring_item porf_gc_ring[PORF_GC_RING];
static u32 porf_gc_ring_head = 0, porf_gc_ring_len = 0;
static int porf_gc_prefetching = 0;
static void porf_gc_mark_js(f64 value, i32 type) {
  if (!porf_gc_prefetching) {
    porf_gc_mark_js_now(value, type);
    return;
  }
  const i32 body = (i32)value;
  if (body > 0 && (u32)body >= porf_heap_base && (u32)body < porf_heap_top) {
    const u32 g = porf_gc_gran(body);
    porf_gc_prefetch(porf_gc_meta + porf_gc_widx(g));
    porf_gc_prefetch(porf_gc_kinds + g);
    porf_gc_prefetch(MEM + body);
  }
  if (porf_gc_ring_len == PORF_GC_RING) {
    const struct porf_gc_ring_item item = porf_gc_ring[porf_gc_ring_head];
    porf_gc_ring[porf_gc_ring_head] = (struct porf_gc_ring_item){ value, type };
    porf_gc_ring_head = (porf_gc_ring_head + 1u) & (PORF_GC_RING - 1u);
    porf_gc_mark_js_now(item.value, item.type);
    return;
  }
  porf_gc_ring[(porf_gc_ring_head + porf_gc_ring_len++) & (PORF_GC_RING - 1u)] = (struct porf_gc_ring_item){ value, type };
}
static void porf_gc_drain_mark_queue(void) {
  for (;;) {
    if (porf_gc_mark_queue_len > 0) {
      const struct porf_gc_mark_item item = porf_gc_mark_queue[--porf_gc_mark_queue_len];
      porf_gc_scan_body((i32)item.body, item.type);
    } else if (porf_gc_ring_len > 0) {
      const struct porf_gc_ring_item item = porf_gc_ring[porf_gc_ring_head];
      porf_gc_ring_head = (porf_gc_ring_head + 1u) & (PORF_GC_RING - 1u);
      porf_gc_ring_len--;
      porf_gc_mark_js_now(item.value, item.type);
    } else break;
  }
}

static void porf_gc_scan_object_entries_range(i32 entries, u32 from, u32 to) {
  for (u32 i = from; i < to; i++) {
    const i32 entry = entries + (i32)(i * 20u);
    const i32 key_type = *(u8*)(MEM + entry + 18);
    const u32 key = *(u32*)(MEM + entry + 4);
    if (key >= porf_heap_base && porf_gc_type_can_reference(key_type)) porf_gc_mark_js((f64)key, key_type);
    const u8 flags = *(u8*)(MEM + entry + 16);
    if ((flags & 1u) != 0u) {
      const u32 get = *(u32*)(MEM + entry + 8);
      const u32 set = *(u32*)(MEM + entry + 12);
      if (get != 0) porf_gc_mark_js((f64)get, ${TYPES.function});
      if (set != 0) porf_gc_mark_js((f64)set, ${TYPES.function});
    } else {
      const i32 value_type = *(u8*)(MEM + entry + 17);
      if (porf_gc_type_can_reference(value_type)) porf_gc_mark_js(porf_load_un_f64(MEM + entry + 8), value_type);
    }
  }
}

// slots of a values block: groups of 8 types then 8 values, a single partial group under 72 bytes
static u32 porf_gc_values_slots(u32 bytes) {
  if (bytes < 72u) return bytes < 8u ? 0u : (bytes - 8u) / 8u;
  return (bytes / 72u) * 8u;
}

static void porf_gc_scan_object_values_range(i32 values, u32 from, u32 to) {
  for (u32 i = from; i < to; i++) {
    const u32 group = (i >> 3) << 3;
    const u8 type = *(u8*)(MEM + values + i + group * 8u);
    const i32 value = values + 8 + (i32)(i * 8u + group);
    if (type == 255u) {
      const u32 get = *(u32*)(MEM + value);
      const u32 set = *(u32*)(MEM + value + 4);
      if (get != 0) porf_gc_mark_js((f64)get, ${TYPES.function});
      if (set != 0) porf_gc_mark_js((f64)set, ${TYPES.function});
    } else if (porf_gc_type_can_reference(type)) porf_gc_mark_js(*(f64*)(MEM + value), type);
  }
}

static void porf_gc_scan_object_values(i32 values) {
  if (!porf_gc_is_block_start(values)) return;
  porf_gc_scan_object_values_range(values, 0, porf_gc_values_slots(porf_gc_block_size(values)));
}

// shapes live forever: their tables, descriptors, key indexes and keys
static void porf_gc_mark_shapes(i32 table, i32 count) {
  if (table == 0) return;
  porf_gc_mark_raw(table);
  for (i32 i = 4; i < count; i++) {
    const i32 node = table + i * 24;
    porf_gc_mark_raw(*(u32*)(MEM + node + 8));
    porf_gc_mark_raw(*(u32*)(MEM + node + 12));
    const u32 key = *(u32*)(MEM + node + 16);
    const u8 key_type = *(u8*)(MEM + node + 21);
    if (key >= porf_heap_base && porf_gc_type_can_reference(key_type)) porf_gc_mark_js((f64)key, key_type);
  }
}

static void porf_gc_scan_object_entries(i32 entries) {
  if (!porf_gc_is_block_start(entries)) return;
  porf_gc_scan_object_entries_range(entries, 0, porf_gc_block_size(entries) / 20u);
}

// minors skip the promoted prefix (entries are in creation order), returns whether anything new was marked
static int porf_gc_mark_underlying_store(i32 body) {
  if (!porf_gc_is_block_start(body)) return 0;
  porf_gc_mark_body(body);
  porf_gc_set_kind(body, PORF_GC_KIND_UNDERLYING_STORE);

  const u32 len = *(u32*)(MEM + body);
  u32 start = 0;
  if (porf_gc_minor_mode) {
    u32 p = porf_gc_underlying_old <= len ? porf_gc_underlying_old : 0u;
    while (p < len) {
      const i32 underlying = *(u32*)(MEM + body + 8 + (i32)(p * 16u) + 8);
      if (underlying <= 0 || porf_gc_bit(PORF_GC_B_YOUNG, porf_gc_gran(underlying)) != 0u) break;
      p++;
    }
    porf_gc_underlying_old = p;
    start = p;
  }
  int changed, any = 0;
  do {
    changed = 0;
    for (u32 i = start; i < len; i++) {
      const i32 base = body + 8 + (i32)(i * 16u);
      const jsval original = porf_unpack(*(jsbits*)(MEM + base));
      const i32 underlying = *(u32*)(MEM + base + 8);

      if (!porf_gc_in_static(porf_gc_value_body(original.val, original.type)) && !porf_gc_is_marked_js(original.val, original.type)) continue;
      if (underlying == 0) continue;

      const int marked_before = porf_gc_is_marked_js((f64)(u32)underlying, ${TYPES.object});
      porf_gc_mark_js_now((f64)(u32)underlying, ${TYPES.object});
      if (!marked_before && porf_gc_is_marked_js((f64)(u32)underlying, ${TYPES.object})) changed = 1;
    }

    if (changed) porf_gc_drain_mark_queue();
    any |= changed;
  } while (changed);
  return any;
}

// drops entries whose original died, returns whether any were removed
static int porf_gc_compact_underlying_store(i32 body) {
  if (!porf_gc_is_block_start(body)) return 1;
  const u32 len = *(u32*)(MEM + body);
  const u32 start = porf_gc_minor_mode ? porf_gc_underlying_old : 0u;
  u32 out = start;
  for (u32 i = start; i < len; i++) {
    const i32 base = body + 8 + (i32)(i * 16u);
    const jsval original = porf_unpack(*(jsbits*)(MEM + base));
    if (!porf_gc_in_static(porf_gc_value_body(original.val, original.type)) && !porf_gc_is_marked_js(original.val, original.type)) continue;

    if (out != i) {
      const i32 dst = body + 8 + (i32)(out * 16u);
      *(u64*)(MEM + dst) = *(u64*)(MEM + base);
      *(u32*)(MEM + dst + 8) = *(u32*)(MEM + base + 8);
      *(u32*)(MEM + dst + 12) = *(u32*)(MEM + base + 12);
    }

    out++;
  }

  *(u32*)(MEM + body) = out;
  // every survivor of a major collection is promoted by its sweep
  if (!porf_gc_minor_mode) porf_gc_underlying_old = out;
  return out != len;
}

static void porf_gc_scan_regex_cache(i32 cache) {
  while (cache != 0 && porf_gc_is_block_start(cache)) {
    porf_gc_mark_js((f64)(*(u32*)(MEM + cache + 4)), ${TYPES.bytestring});
    porf_gc_mark_js((f64)(*(u32*)(MEM + cache + 8)), ${TYPES.bytestring});
    const i32 cache_blob = *(u32*)(MEM + cache + 12);
    if (cache_blob != 0) porf_gc_mark_body(cache_blob);
    const i32 cache_names = *(u32*)(MEM + cache + 16);
    if (cache_names != 0) porf_gc_mark_js((f64)cache_names, ${TYPES.array});
    cache = *(u32*)(MEM + cache);
  }
}

static void porf_gc_mark_regex_cache(i32 cache) {
  for (i32 entry = cache; entry != 0 && porf_gc_is_block_start(entry); entry = *(u32*)(MEM + entry)) {
    porf_gc_mark_body(entry);
    porf_gc_set_kind(entry, PORF_GC_KIND_REGEX_CACHE);
  }
  // scanning walks the rest of the chain itself
  porf_gc_scan_regex_cache(cache);
}

static void porf_gc_scan_kind_block(i32 body) {
  if (!porf_gc_is_block_start(body)) return;
  const u32 kind = porf_gc_kind(body);
  switch (kind) {
    case PORF_GC_KIND_OBJECT_ENTRIES:
      porf_gc_scan_object_entries(body);
      break;
    case PORF_GC_KIND_OBJECT_VALUES:
      porf_gc_scan_object_values(body);
      break;
    case PORF_GC_KIND_ARRAY_ENTRIES:
      porf_gc_mark_array_entries(body, porf_gc_block_size(body) / 8u);
      break;
    case PORF_GC_KIND_FUNCTION: {
      const i32 env = *(u32*)(MEM + body + 4);
      if (env != 0) porf_gc_mark_js((f64)env, ${TYPES.__porffor_closureenv});
      break;
    }
    // weak, only porf_gc_mark_underlying_stores marks its entries: a stray reference must not keep every key alive
    case PORF_GC_KIND_UNDERLYING_STORE:
      break;
    case PORF_GC_KIND_REGEX_CACHE:
      porf_gc_scan_regex_cache(body);
      break;
    case PORF_GC_KIND_PROMISE_REACTION:
      porf_gc_scan_promise_reaction((u32)body);
      break;
    case PORF_GC_KIND_CORO:
      porf_gc_scan_coro(body);
      break;
    default:
      if (kind >= 1u && kind <= 195u) porf_gc_scan_body(body, (i32)kind);
      break;
  }
}

static u32 porf_gc_weakmap_hash(f64 key) {
  u32 hash = (u32)key;
  hash = hash >> 3;
  hash ^= hash >> 16;
  hash *= 0x7feb352d;
  hash ^= hash >> 15;
  return hash;
}

static void porf_gc_weakmap_insert_bucket(i32 buckets, u32 capacity, f64 key, u32 index) {
  if (buckets == 0 || capacity == 0) return;
  u32 slot = porf_gc_weakmap_hash(key) & (capacity - 1u);
  while (1) {
    const i32 bucket_ptr = buckets + (i32)(slot * 4u);
    if (*(u32*)(MEM + bucket_ptr) == 0u) {
      *(u32*)(MEM + bucket_ptr) = index + 1u;
      return;
    }
    slot = (slot + 1u) & (capacity - 1u);
  }
}

static i32 porf_gc_array_entries_shallow(i32 arr, u32* len_out) {
  if (arr == 0) { *len_out = 0; return 0; }
  u32 len = *(u32*)(MEM + arr);
  const i32 entries = *(u32*)(MEM + arr + 4);
  const u32 capacity = *(u32*)(MEM + arr + 8);
  if (len > capacity) len = capacity;
  if (entries != arr + 16) porf_gc_mark_body(entries);
  *len_out = len;
  return entries;
}

// a minor gc starts a weakmap at its first entry that may be young
static inline u32 porf_gc_weakmap_from(i32 body, u32 len) {
  const u32 from = porf_gc_minor_mode ? *(u32*)(MEM + body + 20) : 0u;
  return from < len ? from : len;
}

// a weakmap's key and value arrays are only traced by the weakmap, so card scans skip them
static void porf_gc_mark_weak_array(i32 arr) {
  if (arr == 0) return;
  porf_gc_mark_body(arr);
  porf_gc_set_kind(arr, PORF_GC_KIND_WEAK);
  const i32 entries = *(u32*)(MEM + arr + 4);
  if (entries != arr + 16) porf_gc_set_kind(entries, PORF_GC_KIND_WEAK);
}

static int porf_gc_mark_weakmap_values_once(void) {
  int changed = 0;
  for (i32 w = 0; w < porf_gc_weakmaps_len; w++) {
    const i32 body = (i32)porf_gc_weakmaps[w];
    if (!porf_gc_is_block_start(body)) continue;
    const i32 keys = *(u32*)(MEM + body);
    const i32 vals = *(u32*)(MEM + body + 4);
    u32 keys_len = 0, vals_len = 0;
    const i32 keys_entries = porf_gc_array_entries_shallow(keys, &keys_len);
    const i32 vals_entries = porf_gc_array_entries_shallow(vals, &vals_len);
    const u32 len = keys_len < vals_len ? keys_len : vals_len;
    for (u32 i = porf_gc_weakmap_from(body, len); i < len; i++) {
      const jsbits key_bits = *(jsbits*)(MEM + keys_entries + ((u64)i << 3));
      if (key_bits == 0xffffffffffffffffull) continue;
      const jsval key = porf_unpack(key_bits);
      if (!porf_gc_is_marked_js(key.val, key.type)) continue;
      const jsval val = porf_unpack(*(jsbits*)(MEM + vals_entries + ((u64)i << 3)));
      const int marked_before = porf_gc_is_marked_js(val.val, val.type);
      porf_gc_mark_js_now(val.val, val.type);
      if (!marked_before && porf_gc_is_marked_js(val.val, val.type)) changed = 1;
    }
  }
  return changed;
}

static int porf_gc_young_value(jsval v) {
  if (!porf_gc_type_can_reference(v.type)) return 0;
  const i32 body = porf_gc_value_body(v.val, v.type);
  return (u32)body >= porf_heap_base && porf_gc_is_block_start(body) && porf_gc_bit(PORF_GC_B_YOUNG, porf_gc_gran(body)) != 0u;
}
static void porf_gc_sweep_weakmaps(void) {
  for (i32 w = 0; w < porf_gc_weakmaps_len; w++) {
    const i32 body = (i32)porf_gc_weakmaps[w];
    if (!porf_gc_is_block_start(body)) continue;
    const i32 keys = *(u32*)(MEM + body);
    const i32 vals = *(u32*)(MEM + body + 4);
    const i32 buckets = *(u32*)(MEM + body + 8);
    const u32 capacity = *(u32*)(MEM + body + 12);
    u32 keys_len = 0, vals_len = 0;
    const i32 keys_entries = porf_gc_array_entries_shallow(keys, &keys_len);
    const i32 vals_entries = porf_gc_array_entries_shallow(vals, &vals_len);
    const u32 len = keys_len < vals_len ? keys_len : vals_len;
    // a minor gc only tombstones dead young keys: keys never move, and lookups skip a bucket whose key is a tombstone
    const int rebuild = !porf_gc_minor_mode && buckets != 0 && capacity != 0;
    if (rebuild) memset(MEM + buckets, 0, (size_t)capacity * 4u);
    for (u32 i = porf_gc_weakmap_from(body, len); i < len; i++) {
      const i32 key_ptr = keys_entries + (i32)((u64)i << 3);
      const jsbits key_bits = *(jsbits*)(MEM + key_ptr);
      if (key_bits == 0xffffffffffffffffull) continue;
      const jsval key = porf_unpack(key_bits);
      if (porf_gc_is_marked_js(key.val, key.type)) {
        if (rebuild) porf_gc_weakmap_insert_bucket(buckets, capacity, key.val, i);
        continue;
      }
      *(jsbits*)(MEM + key_ptr) = 0xffffffffffffffffull;
      *(jsbits*)(MEM + vals_entries + ((u64)i << 3)) = JV_UNDEFINED_BITS;
      *(u32*)(MEM + body + 16) += 1u;
    }
    // young keys and values are only seen through the weakmap, so the next minor gc revisits it from the first
    u32 first_young = len;
    if (porf_gc_minor_mode) for (u32 i = porf_gc_weakmap_from(body, len); i < len; i++) {
      const jsbits key_bits = *(jsbits*)(MEM + keys_entries + ((u64)i << 3));
      if (key_bits == 0xffffffffffffffffull) continue;
      if (porf_gc_young_value(porf_unpack(key_bits)) || porf_gc_young_value(porf_unpack(*(jsbits*)(MEM + vals_entries + ((u64)i << 3))))) {
        first_young = i;
        porf_gc_cards[(u32)body >> 9] = 1;
        break;
      }
    }
    *(u32*)(MEM + body + 20) = first_young;
  }
}

// weakmap values and underlying objects can each make the other reachable
static void porf_gc_process_weakmaps(void) {
  while (porf_gc_mark_weakmap_values_once() | porf_gc_mark_underlying_stores()) porf_gc_drain_mark_queue();
  porf_gc_sweep_weakmaps();
  porf_gc_compact_underlying_stores();
}

static void porf_gc_cons_candidate(u32 c);
static void porf_gc_cons_f64(f64 d) {
  if (d > 0.0 && d < 4294967296.0) {
    const i64 iv = (i64)d;
    if ((f64)iv == d) porf_gc_cons_candidate((u32)(u64)iv);
  }
  // heap bigints hold 2^51 + ptr
  if (d >= 2251799813685248.0 && d < 2251804108652544.0) porf_gc_cons_candidate((u32)(d - 2251799813685248.0));
}
static void porf_gc_cons_mark_block(i32 body) {
  if (!porf_gc_mark_body(body)) return;
  const u32 kind = porf_gc_kinds[porf_gc_gran(body)];
  if (kind != 0u) { porf_gc_scan_kind_block(body); return; }
  if (porf_gc_object_shape_valid(body)) { porf_gc_enqueue_mark(body, ${TYPES.object}); return; }
  if (porf_gc_array_like_shape_valid(body)) { porf_gc_enqueue_mark(body, ${TYPES.array}); return; }
  const u32 size = porf_gc_block_size(body);
  for (u32 off = 0; off + 4u <= size; off += 4u) porf_gc_cons_candidate(*(u32*)(MEM + body + off));
  for (u32 off = 0; off + 8u <= size; off += 8u) porf_gc_cons_f64(*(f64*)(MEM + body + off));
}
static void porf_gc_cons_candidate(u32 c) {
  if (c < porf_heap_base || c >= porf_heap_top) return;
  const u32 pg = c >> PORF_GC_SPAGE_SHIFT;
  const u8 k = porf_gc_page_kind[pg];
  u32 base;
  if (k == PORF_GC_PK_SMALL) {
    const u32 cls = porf_gc_pages[pg].cls;
    const u32 sa = porf_gc_chunk_start(pg);
    base = sa + ((c - sa) / cls) * cls;
  } else if (k == PORF_GC_PK_SPAN) {
    base = pg << PORF_GC_SPAGE_SHIFT;
  } else if (k == PORF_GC_PK_TAIL) {
    base = porf_gc_pages[pg].aux << PORF_GC_SPAGE_SHIFT;
  } else return;
  porf_gc_cons_mark_block((i32)base);
}
static void porf_gc_cons_scan_range(const u64* lo, const u64* hi) {
  for (const u64* w = lo; w < hi; w++) {
    const u64 v = *w;
    if (v == 0) continue;
    porf_gc_cons_candidate((u32)v);
    porf_gc_cons_candidate((u32)(v >> 32));
    f64 d;
    memcpy(&d, w, 8);
    porf_gc_cons_f64(d);
  }
}

static void porf_gc_mark_cons_roots(void) {
  jmp_buf regs;
  if (_setjmp(regs) == 0) {
    porf_gc_cons_scan_range((const u64*)&regs, (const u64*)((const char*)&regs + sizeof(regs)));
  }
  volatile u64 anchor = 0;
  const u64* lo = (const u64*)(((uintptr_t)&anchor + 7) & ~(uintptr_t)7);
  const u64* hi = (const u64*)porf_c_stack_top;
  if ((uintptr_t)lo < porf_gc_stack_lo) porf_gc_stack_lo = (uintptr_t)lo;
  if (lo < hi) porf_gc_cons_scan_range(lo, hi);
  if (porf_try_depth > 0) {
    porf_gc_cons_scan_range((const u64*)porf_try_data, (const u64*)(porf_try_data + porf_try_depth));
  }
  porf_gc_mark_promise_jobs();
  porf_gc_mark_coro_roots();
  porf_gc_drain_mark_queue();
}

// array entries take per-slot cards (porf_arr_set), object entries their owner's
static void porf_gc_scan_card_object(u32 base, u32 from, u32 to) {
  const u8 kind = porf_gc_kinds[porf_gc_gran(base)];
  if (kind == PORF_GC_KIND_ARRAY_ENTRIES) {
    const u32 bs = porf_gc_block_size((i32)base);
    u32 lo = from > base ? from : base;
    const u32 hi = base + bs < to ? base + bs : to;
    lo = base + (((lo - base) >> 3) << 3);
    if (hi > lo) porf_gc_mark_array_entries((i32)lo, (hi - lo) / 8u);
    return;
  }
  if (kind == PORF_GC_KIND_OBJECT_ENTRIES || kind == PORF_GC_KIND_OBJECT_VALUES || kind == PORF_GC_KIND_WEAK) return;
  porf_gc_scan_kind_block((i32)base);
}

static void porf_gc_scan_card(u32 card) {
  const u32 from = card << 9;
  const u32 to = from + 512u;
  const u32 pg = from >> PORF_GC_SPAGE_SHIFT;
  const u8 k = porf_gc_page_kind[pg];
  if (k == PORF_GC_PK_SMALL) {
    const u32 cls = porf_gc_pages[pg].cls;
    const u32 sa = porf_gc_chunk_start(pg);
    u32 base = sa + ((from - sa) / cls) * cls;
    for (; base < to; base += cls) {
      if (porf_gc_old_block(base)) porf_gc_scan_card_object(base, from, to);
    }
    return;
  }
  u32 head;
  if (k == PORF_GC_PK_SPAN) head = pg;
  else if (k == PORF_GC_PK_TAIL) head = porf_gc_pages[pg].aux;
  else return;
  const u32 base = head << PORF_GC_SPAGE_SHIFT;
  if (porf_gc_old_block(base)) porf_gc_scan_card_object(base, from, to);
}

static void porf_gc_scan_cards(void) {
  const u32 c_lo = porf_heap_base >> 9;
  const u32 c_hi = porf_heap_top >> 9;
  for (u32 cw = c_lo & ~7u; cw < c_hi; cw += 8u) {
    u64 w8;
    memcpy(&w8, porf_gc_cards + cw, 8);
    if (w8 == 0) continue;
    for (u32 j = 0; j < 8u; j++) {
      const u32 c = cw + j;
      if (c < c_lo || c >= c_hi || porf_gc_cards[c] == 0) continue;
      porf_gc_scan_young_seen = 0;
      porf_gc_scan_card(c);
      porf_gc_drain_mark_queue();
      porf_gc_cards[c] = c < (porf_gc_template_top >> 9) ? 1u : porf_gc_scan_young_seen;
    }
  }
}

static void porf_gc_partial_push(u32 pg) {
  struct porf_gc_page* m = &porf_gc_pages[pg];
  if ((m->flags & (PORF_GC_PF_PARTIAL | PORF_GC_PF_SEALED)) != 0u) return;
  m->flags |= PORF_GC_PF_PARTIAL;
  m->aux = porf_gc_partial[m->cidx];
  porf_gc_partial[m->cidx] = pg + 1u;
}

static void porf_gc_partial_remove(u32 pg) {
  struct porf_gc_page* m = &porf_gc_pages[pg];
  u32* link = &porf_gc_partial[m->cidx];
  while (*link != 0) {
    const u32 cur = *link - 1u;
    if (cur == pg) {
      *link = porf_gc_pages[cur].aux;
      m->aux = 0;
      m->flags &= (u8)~PORF_GC_PF_PARTIAL;
      return;
    }
    link = &porf_gc_pages[cur].aux;
  }
}

// a minor gc promotes everything that survives it, so promoted blocks only point at old ones and need no card
static void porf_gc_sweep_page_small(u32 pg, int minor, u64* young_bytes, u64* live_bytes) {
  struct porf_gc_page* m = &porf_gc_pages[pg];
  const u32 cls = m->cls;
  const u32 npg = porf_gc_cls_pages[m->cidx];
  u64* blk = porf_gc_meta + ((size_t)pg << 5);
  u32 live = 0;
  for (u32 w = 0; w < npg * 8u; w++) {
    u64* grp = blk + ((size_t)w << 2);
    const u64 mk = grp[1], y = grp[2];
    const u64 a = grp[0] & ~(minor ? y & ~mk : ~mk);
    *young_bytes += (u64)__builtin_popcountll(y & mk) * cls;
    grp[0] = a;
    grp[1] = 0;
    grp[2] = 0;
    live += (u32)__builtin_popcountll(a);
  }
  if (live == 0) {
    if ((m->flags & PORF_GC_PF_PARTIAL) != 0u) porf_gc_partial_remove(pg);
    m->flags = 0;
    m->cursor = 0;
    porf_gc_release_run(pg, npg);
    return;
  }
  *live_bytes += (u64)live * cls;
  m->cursor = 0;
  if (live < (u32)porf_gc_cls_slots[m->cidx]) porf_gc_partial_push(pg);
}

static void porf_gc_sweep_span(u32 pg, int minor, u64* young_bytes, u64* live_bytes) {
  struct porf_gc_page* m = &porf_gc_pages[pg];
  const u32 npg = m->aux;
  const u32 body = pg << PORF_GC_SPAGE_SHIFT;
  const u32 g = porf_gc_gran(body);
  const int young = porf_gc_bit(PORF_GC_B_YOUNG, g) != 0u;
  const int marked = porf_gc_bit(PORF_GC_B_MARK, g) != 0u;
  if (minor && !young) { *live_bytes += (u64)npg * PORF_GC_SPAGE; return; }
  porf_gc_bit_clear(PORF_GC_B_YOUNG, g);
  if (!marked) {
    porf_gc_bit_clear(PORF_GC_B_ALLOC, g);
    m->flags = 0;
    porf_gc_release_run(pg, npg);
    return;
  }
  porf_gc_bit_clear(PORF_GC_B_MARK, g);
  *live_bytes += (u64)npg * PORF_GC_SPAGE;
  if (young) *young_bytes += (u64)npg * PORF_GC_SPAGE;
}

// os pages can be larger than gc pages (16KB on arm64 macos), never touch a partial one
static void porf_gc_madv_dontneed(u8* lo, u8* hi) {
  lo = (u8*)(((uintptr_t)lo + 16383u) & ~(uintptr_t)16383u);
  hi = (u8*)((uintptr_t)hi & ~(uintptr_t)16383u);
  if (hi <= lo) return;
#if PORF_CAN_DECOMMIT && defined(__APPLE__)
  // macos keeps madvised pages resident until memory pressure, a fresh mapping drops them now
  (void)mmap(lo, (size_t)(hi - lo), PROT_READ | PROT_WRITE, MAP_FIXED | MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
#elif PORF_CAN_DECOMMIT && defined(MADV_DONTNEED)
  (void)madvise(lo, (size_t)(hi - lo), MADV_DONTNEED);
#elif PORF_CAN_DECOMMIT && defined(MADV_FREE)
  (void)madvise(lo, (size_t)(hi - lo), MADV_FREE);
#endif
}

static void porf_gc_discard_range(u32 start, u32 end) {
  porf_gc_madv_dontneed(MEM + start, MEM + end);
  // free pages' kinds go unread and their bits are already clear
  porf_gc_madv_dontneed(porf_gc_kinds + (start >> 4), porf_gc_kinds + (end >> 4));
  porf_gc_madv_dontneed((u8*)(porf_gc_meta + ((size_t)(start >> PORF_GC_SPAGE_SHIFT) << 5)), (u8*)(porf_gc_meta + ((size_t)(end >> PORF_GC_SPAGE_SHIFT) << 5)));
}

static void porf_gc_retreat_heap_top(void) {
  while (porf_heap_top > porf_heap_base) {
    const u32 pg = (porf_heap_top >> PORF_GC_SPAGE_SHIFT) - 1u;
    if ((porf_gc_free_pages[pg >> 6] & (1ull << (pg & 63u))) == 0u) break;
    porf_gc_free_pages[pg >> 6] &= ~(1ull << (pg & 63u));
    if (porf_gc_free_page_count > 0) porf_gc_free_page_count--;
    porf_heap_top -= PORF_GC_SPAGE;
  }
}

static void porf_gc_discard_free_runs(u32 min_run) {
  const u32 top = porf_heap_top >> PORF_GC_SPAGE_SHIFT;
  u32 run_start = 0, run_len = 0;
  for (u32 pg = porf_heap_base >> PORF_GC_SPAGE_SHIFT; pg < top; pg++) {
    if ((porf_gc_free_pages[pg >> 6] & (1ull << (pg & 63u))) != 0u) {
      if (run_len == 0) run_start = pg;
      run_len++;
    } else {
      if (run_len >= min_run) porf_gc_discard_range(run_start << PORF_GC_SPAGE_SHIFT, (run_start + run_len) << PORF_GC_SPAGE_SHIFT);
      run_len = 0;
    }
  }
  if (run_len >= min_run) porf_gc_discard_range(run_start << PORF_GC_SPAGE_SHIFT, (run_start + run_len) << PORF_GC_SPAGE_SHIFT);
}

static void porf_gc_maybe_trim_memory(void) {
  const u32 trim_granule = 1u << 20;
  const u32 keep_slack = 16u * 1024u * 1024u;

  u64 wanted64 = ((u64)porf_heap_top + keep_slack + trim_granule - 1ull) & ~((u64)trim_granule - 1ull);
  const u64 min_committed = ((u64)porf_heap_base + 65536ull + trim_granule - 1ull) & ~((u64)trim_granule - 1ull);
  if (wanted64 < min_committed) wanted64 = min_committed;
  if (wanted64 >= porf_heap_committed) return;

  const u32 wanted = (u32)wanted64;
  const u64 trim_bytes64 = porf_heap_committed - wanted64;
  if (trim_bytes64 > SIZE_MAX) return;
  const size_t trim_bytes = (size_t)trim_bytes64;
  if (trim_bytes < trim_granule) return;

  if (!PORF_CAN_DECOMMIT) return;
  // replacing the tail drops its pages but keeps the reservation
  if (mmap(MEM + wanted, trim_bytes, PROT_NONE, MAP_FIXED | MAP_PRIVATE | MAP_ANONYMOUS, -1, 0) == MAP_FAILED) return;
#ifdef MADV_NOHUGEPAGE
  (void)madvise(MEM + wanted, trim_bytes, MADV_NOHUGEPAGE);
#endif
  porf_heap_committed = wanted;
}

// a collection since the last idle one, and when the latest ran
static int porf_gc_busy = 0;
static i64 porf_gc_last_cycle_ms = 0;
static i64 porf_gc_now_ms(void) {
  struct timespec now;
  clock_gettime(CLOCK_MONOTONIC, &now);
  return (i64)now.tv_sec * 1000 + now.tv_nsec / 1000000;
}

// percent of what was allocated since the last gc that survived it
static i64 porf_gc_survival = 0;
// least live bytes after a full gc per 125ms slot over the last 8 slots: what stays, not in-flight work
static u64 porf_gc_live_history[8];
static i64 porf_gc_live_history_slot[8];
static i64 porf_gc_live_slot = 0;
static void porf_gc_record_live(u64 live) {
  const i64 slot = porf_gc_now_ms() / 125;
  if (slot != porf_gc_live_history_slot[slot & 7] || live < porf_gc_live_history[slot & 7]) porf_gc_live_history[slot & 7] = live;
  porf_gc_live_history_slot[slot & 7] = slot;
  porf_gc_live_slot = slot;
}
static u64 porf_gc_settled_live(void) {
  u64 least = porf_gc_last_live_bytes;
  for (u32 i = 0; i < 8u; i++) if (porf_gc_live_slot - porf_gc_live_history_slot[i] < 8 && porf_gc_live_history[i] < least) least = porf_gc_live_history[i];
  return least;
}

// while most allocations survive the budget is twice live
static u64 porf_gc_limit_bytes = 0;
${st}void porf_gc_set_limit(u64 bytes) { porf_gc_limit_bytes = bytes; }
static u64 porf_gc_limit_room(void) {
  if (porf_gc_limit_bytes == 0) return ~0ull;
  const u64 live = porf_gc_last_live_bytes + (porf_gc_promoted_since_full > 0 ? (u64)porf_gc_promoted_since_full : 0u);
  const u64 room = porf_gc_limit_bytes > live ? (porf_gc_limit_bytes - live) / 2u : 0u;
  return room > 1048576ull ? room : 1048576ull;
}
static i64 porf_gc_budget(void) {
  const i64 grown = (i64)porf_gc_last_live_bytes * 2;
  const i64 want = porf_gc_survival > 50 && grown > (i64)porf_gc_nursery_bytes ? grown : (i64)porf_gc_nursery_bytes;
  const u64 room = porf_gc_limit_room();
  return (u64)want > room ? (i64)room : want;
}

static void porf_gc_cycle(i64 allocated) {
  const i64 now = porf_gc_now_ms(), ms = now - porf_gc_last_cycle_ms;
  porf_gc_last_cycle_ms = now;
  porf_gc_busy = 1;
  // a small heap's nursery stays near eight times what is live: fewer gcs past that only cost memory
  const u64 near_live = porf_gc_last_live_bytes * 8u < 1048576ull ? 1048576ull : porf_gc_last_live_bytes * 8u;
  const u32 cap_free = porf_gc_last_live_bytes >= 8388608ull ? 33554432u : near_live < 8388608ull ? (u32)near_live : 8388608u;
  const u64 cap_room = porf_gc_limit_room();
  const u32 cap = cap_free > cap_room ? (u32)cap_room : cap_free;
  if (ms < 50 && porf_gc_nursery_bytes * 2u <= cap) porf_gc_nursery_bytes <<= 1;
    else if ((ms > 1000 || porf_gc_nursery_bytes > cap) && porf_gc_nursery_bytes > 1048576u) porf_gc_nursery_bytes >>= 1;
  // only full gcs while the heap is small or most allocations survive
  const int full = porf_gc_last_live_bytes < 8388608ull || porf_gc_survival > 50;
  porf_gc_collect(!full);
  porf_gc_survival = (i64)porf_gc_young_survived * 100 / (allocated > 0 ? allocated : 1);
  if (!full && porf_gc_full_due(0)) porf_gc_collect(0);
}

// ms until a second without collections makes an idle one due, -1 when there is nothing to collect
${st}i64 porf_gc_idle_due(void) {
  if (!porf_gc_busy) return -1;
  const i64 left = 1000 - (porf_gc_now_ms() - porf_gc_last_cycle_ms);
  return left > 0 ? left : 0;
}
// the loop found nothing to do for a while after allocating: collect everything and give the free pages back
${st}void porf_gc_idle(void) {
  if (!porf_gc_busy) return;
  porf_gc_busy = 0;
  porf_gc_nursery_bytes = 1048576u;
  porf_gc_collect(0);
  porf_gc_discard_free_runs(1u);
}
// sproutboat: collector hooks for the fork template
${st}void porf_gc_quiet(void) {
  porf_gc_busy = 0;
  porf_gc_nursery_bytes = 1048576u;
  porf_gc_collect(0);
  porf_gc_discard_free_runs(1u);
}
${st}void porf_gc_seal_heap(void) {
  if (porf_heap_base == 0) return;
  porf_gc_quiet();
  for (i32 ci = 0; ci < PORF_GC_NCLASSES; ci++) {
    struct porf_gc_window* w = &porf_gc_active[ci];
    if (w->end != 0) porf_gc_publish_window(ci);
    w->cur = w->end = w->lo = 0;
    while (porf_gc_partial[ci] != 0) {
      struct porf_gc_page* m = &porf_gc_pages[porf_gc_partial[ci] - 1u];
      porf_gc_partial[ci] = m->aux;
      m->aux = 0;
      m->flags &= (u8)~PORF_GC_PF_PARTIAL;
    }
  }
  // every page in use is sealed (tails too) and its live objects stay marked for the life of every worker
  const u32 top = porf_heap_top >> PORF_GC_SPAGE_SHIFT;
  for (u32 pg = porf_heap_base >> PORF_GC_SPAGE_SHIFT; pg < top; pg++) {
    const u8 k = porf_gc_page_kind[pg];
    if (k == 0u) continue;
    porf_gc_pages[pg].flags |= PORF_GC_PF_SEALED;
    if (k == PORF_GC_PK_SMALL) {
      if ((porf_gc_pages[pg].flags & PORF_GC_PF_TAIL) != 0u) continue;
      u64* blk = porf_gc_meta + ((size_t)pg << 5);
      const u32 npg = porf_gc_cls_pages[porf_gc_pages[pg].cidx];
      for (u32 w = 0; w < npg * 8u; w++) blk[((size_t)w << 2) + PORF_GC_B_MARK] = blk[((size_t)w << 2) + PORF_GC_B_ALLOC];
    } else if (k == PORF_GC_PK_SPAN) porf_gc_bit_set(PORF_GC_B_MARK, porf_gc_gran(pg << PORF_GC_SPAGE_SHIFT));
  }
  porf_gc_template_top = porf_heap_top;
  porf_gc_template_live = porf_gc_last_live_bytes;
}
// cards below the template top are sticky (never cleared): every collection scans them
static void porf_gc_scan_template_cards(void) {
  const u32 c_lo = porf_heap_base >> 9;
  const u32 c_hi = porf_gc_template_top >> 9;
  for (u32 cw = c_lo & ~7u; cw < c_hi; cw += 8u) {
    u64 w8;
    memcpy(&w8, porf_gc_cards + cw, 8);
    if (w8 == 0) continue;
    for (u32 j = 0; j < 8u; j++) {
      const u32 c = cw + j;
      if (c < c_lo || c >= c_hi || porf_gc_cards[c] == 0) continue;
      porf_gc_scan_card(c);
      porf_gc_drain_mark_queue();
    }
  }
}

static void porf_gc_clear_marks(u32 lo, u32 hi) {
  for (size_t w = (size_t)(lo >> 4 >> 6); w < (size_t)(((hi >> 4) + 63u) >> 6); w++)
    porf_gc_meta[(((w >> 3) << 5) | ((w & 7u) << 2)) + PORF_GC_B_MARK] = 0;
}

${st}void porf_gc_collect(int minor) {
  if (porf_heap_base == 0) return;
  memset(porf_str_builder_caps, 0, sizeof(porf_str_builder_caps));
  for (i32 ci = 0; ci < PORF_GC_NCLASSES; ci++) porf_gc_publish_window(ci);
  porf_gc_minor_mode = minor;
  porf_gc_prefetching = porf_heap_top - porf_heap_base > 33554432u;
  if (!minor) {
    porf_gc_claimed_since_full = 0;
    porf_gc_promoted_since_full = 0;
    // the skipped alias window holds no blocks, writing its marks would only dirty pages
    const u32 clear_lo = porf_gc_template_top != 0 && porf_gc_template_top < porf_heap_top ? porf_gc_template_top : porf_gc_template_top != 0 ? porf_heap_top : porf_heap_base;
    for (u32 pg = porf_heap_base >> PORF_GC_SPAGE_SHIFT; pg < (clear_lo >> PORF_GC_SPAGE_SHIFT); pg++)
      if (porf_gc_page_kind[pg] != 0u && (porf_gc_pages[pg].flags & PORF_GC_PF_SEALED) == 0u) porf_gc_clear_marks(pg << PORF_GC_SPAGE_SHIFT, (pg + 1u) << PORF_GC_SPAGE_SHIFT);
    if (porf_gc_alias_lo < porf_heap_top && porf_gc_alias_hi > clear_lo) {
      if (porf_gc_alias_lo > clear_lo) porf_gc_clear_marks(clear_lo, porf_gc_alias_lo);
      porf_gc_clear_marks(porf_gc_alias_hi, porf_heap_top);
    } else porf_gc_clear_marks(clear_lo, porf_heap_top);
  }
  porf_gc_static_marks_len = 0;
  if (porf_gc_static_marks != NULL) memset(porf_gc_static_marks, 0, (size_t)porf_gc_static_marks_cap * sizeof(*porf_gc_static_marks));
  porf_gc_mark_queue_len = 0;
  porf_gc_weakmaps_len = 0;
  porf_gc_boxed_marks_len = 0;
  porf_gc_mark_native_roots();
  porf_gc_mark_cons_roots();
  porf_gc_mark_js(porf_exception.val, porf_exception.type);
  porf_gc_mark_js(porf_iter_open.val, porf_iter_open.type);
  porf_gc_mark_global_roots();
  porf_gc_drain_mark_queue();
  if (minor) porf_gc_scan_cards();
  else if (porf_gc_template_top != 0) porf_gc_scan_template_cards();
  porf_gc_mark_global_raw_roots();
  porf_gc_drain_mark_queue();
  porf_gc_process_weakmaps();
  porf_gc_drain_mark_queue();

  u64 promoted = 0, live_bytes = 0;
  if (minor) {
    for (i32 i = 0; i < porf_gc_touched_len; i++) {
      const u32 pg = porf_gc_touched[i];
      const u8 k = porf_gc_page_kind[pg];
      if (k == PORF_GC_PK_SMALL) porf_gc_sweep_page_small(pg, 1, &promoted, &live_bytes);
      else if (k == PORF_GC_PK_SPAN) porf_gc_sweep_span(pg, 1, &promoted, &live_bytes);
      porf_gc_pages[pg].flags &= (u8)~PORF_GC_PF_TOUCHED;
    }
    porf_gc_touched_len = 0;
    porf_gc_promoted_since_full += (i64)promoted;
    porf_gc_retreat_heap_top();
    porf_gc_maybe_trim_memory();
  } else {
    for (i32 i = 0; i < porf_gc_touched_len; i++)
      porf_gc_pages[porf_gc_touched[i]].flags &= (u8)~PORF_GC_PF_TOUCHED;
    porf_gc_touched_len = 0;
    for (i32 ci = 0; ci < PORF_GC_NCLASSES; ci++) {
      u32 pg1 = porf_gc_partial[ci];
      while (pg1 != 0) {
        const u32 next = porf_gc_pages[pg1 - 1u].aux;
        porf_gc_pages[pg1 - 1u].flags &= (u8)~PORF_GC_PF_PARTIAL;
        pg1 = next;
      }
      porf_gc_partial[ci] = 0;
    }
    const u32 top = porf_heap_top >> PORF_GC_SPAGE_SHIFT;
    for (u32 pg = porf_heap_base >> PORF_GC_SPAGE_SHIFT; pg < top; pg++) {
      const u8 k = porf_gc_page_kind[pg];
      if ((porf_gc_pages[pg].flags & PORF_GC_PF_SEALED) != 0u) continue;
      if (k == PORF_GC_PK_SMALL) {
        if ((porf_gc_pages[pg].flags & PORF_GC_PF_TAIL) != 0u) continue;
        porf_gc_sweep_page_small(pg, 0, &promoted, &live_bytes);
      } else if (k == PORF_GC_PK_SPAN) porf_gc_sweep_span(pg, 0, &promoted, &live_bytes);
    }
    live_bytes += porf_gc_template_live;
    porf_gc_last_live_bytes = live_bytes;
    porf_gc_record_live(live_bytes);
    porf_gc_live_bytes = live_bytes;
    if (porf_gc_template_top < porf_heap_top) memset(porf_gc_cards + ((porf_gc_template_top > porf_heap_base ? porf_gc_template_top : porf_heap_base) >> 9), 0, (size_t)((porf_heap_top - (porf_gc_template_top > porf_heap_base ? porf_gc_template_top : porf_heap_base)) >> 9) + 1);
    porf_gc_run_cache_drain();
    porf_gc_retreat_heap_top();
    // free pages a busy program will reuse soon stay, more than that go back
    if ((u64)porf_gc_free_page_count * PORF_GC_SPAGE > porf_gc_last_live_bytes + 2ull * porf_gc_nursery_bytes + 16777216ull) porf_gc_discard_free_runs(32u);
    porf_gc_maybe_trim_memory();
  }
  porf_gc_young_survived = promoted;
  memset(porf_gc_active, 0, sizeof(porf_gc_active));
  porf_gc_window_bytes = 0;
  porf_gc_minor_mode = 0;
}
`;
};

// jsval encoding: f64 numbers are themselves, else 0xFFF8 (sign + quiet-NaN) << 48 |
// type:8 << 43 | payload:32. hardware qNaN is 0x7FF8 (sign clear) so never collides,
// sign-set NaNs from raw bytes are canonicalized at Float64Array/DataView reads (porf_canon)
const RUNTIME_HEAD = (prefs, toStr = null, iterClose = null, bigints = true, fatal = null) => {
  const st = 'static ';
  const sti = 'static inline ';
  return `// generated by porffor ${globalThis.version}
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <math.h>

#include <signal.h>
#include <unistd.h>
#include <sys/random.h>
#include <dirent.h>
#include <sys/mman.h>
#include <sys/stat.h>
#ifndef __wasi__
#include <sys/wait.h>
#endif
#include <time.h>
#if defined(__APPLE__) && !defined(__TINYC__)
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#endif

${prefs.repl ? `static int porf_repl_output_enabled = 1;
#define printf(...) (porf_repl_output_enabled ? fprintf(stdout, __VA_ARGS__) : 0)
` : ''}

typedef uint8_t u8;
typedef uint16_t u16;
typedef int32_t i32;
typedef uint32_t u32;
typedef int64_t i64;
typedef uint64_t u64;
typedef float f32;
typedef double f64;
// a full word of type: gcc handles a padded i32 half with partial register moves and merges
typedef struct jsval { f64 val; u64 type; } jsval;
typedef u64 jsbits;


// arena base: reserved once at init, NEVER moves. a fixed constant VA is
// not reliably free on macOS (per-process dyld/malloc randomization), and
// x86-64 has no [imm64+reg] addressing so a constant folds to a register
// materialization anyway - a once-set global compiles to the same code.
// 0x400000000 is used as a hint for deterministic debugging when free.
// split units see it const: its load then survives stores and calls
#ifndef PORF_SET_ONCE
#define PORF_SET_ONCE
#endif
${st}u8* PORF_SET_ONCE porf_mem;
#define MEM porf_mem
#define PORF_NOINLINE __attribute__((noinline))
// js functions take and return a jsval's number in a float register and its type in a general one
#if defined(__clang__) && defined(__aarch64__)
#define PORF_CC __attribute__((swiftcall))
#else
#define PORF_CC
#endif
// run-once code (module init, top level): optimize for size whatever -O the unit gets
#if defined(__clang__)
#define PORF_ONCE __attribute__((noinline, minsize))
#elif defined(__GNUC__)
#define PORF_ONCE __attribute__((noinline, optimize("Os")))
#else
#define PORF_ONCE
#endif
#define PORF_NORETURN __attribute__((cold, noinline, noreturn))
#ifndef MAP_NORESERVE
#define MAP_NORESERVE 0
#endif
#ifdef __wasi__
// wasi's malloc-backed mmap ignores fixed hints and cannot change protections
// or decommit, so use a small, fully committed arena
#define PORF_ARENA_HINT NULL
#define PORF_ARENA_RESERVE (1ull << 26)
#define PORF_MMAP_RESERVE_PROT (PROT_READ | PROT_WRITE)
#define PORF_CAN_DECOMMIT 0
#else
#define PORF_ARENA_HINT ((void*)0x400000000ull)
#define PORF_ARENA_RESERVE (1ull << 32)
#define PORF_MMAP_RESERVE_PROT PROT_NONE
#define PORF_CAN_DECOMMIT 1
#endif
extern const u32 porf_static_end;
#define PORF_GC_ENABLED ${prefs.gc === false ? 0 : 1}

#define JV_PATTERN 0xFFF8000000000000ull
#define JV_TYPE_MASK 0x07F8000000000000ull
#define JV_UNDEFINED_BITS (JV_PATTERN | ((u64)${TYPES.undefined} << 43))
#define JV_UNDEFINED ((jsval){0.0, ${TYPES.undefined}})
#define JV_ZERO_BITS (JV_PATTERN | ((u64)${TYPES.number} << 43))

#define PORF_PROMISE_RESULT 0
#define PORF_PROMISE_FULFILL_HEAD 8
#define PORF_PROMISE_FULFILL_TAIL 12
#define PORF_PROMISE_REJECT_HEAD 16
#define PORF_PROMISE_REJECT_TAIL 20
#define PORF_PROMISE_PAYLOAD 24
#define PORF_PROMISE_STATE 32
#define PORF_PROMISE_FLAGS 33
#define PORF_PROMISE_HANDLED 34
#define PORF_PROMISE_SIZE 40

#define PORF_REACTION_HANDLER 0
#define PORF_REACTION_OUT_PROMISE 8
#define PORF_REACTION_VALUE 16
#define PORF_REACTION_NEXT 24
#define PORF_REACTION_PAYLOAD 28
#define PORF_REACTION_KIND 32
#define PORF_REACTION_FLAGS 33
#define PORF_REACTION_CONTEXT 40
#define PORF_REACTION_CPU 48
#define PORF_REACTION_SIZE 56

#define PORF_GC_KIND_PROMISE_REACTION 248u

static inline f64 porf_bits_to_f64_bits(u64 b) { f64 d; memcpy(&d, &b, 8); return d; }
static inline u64 porf_f64_to_bits(f64 d) { u64 b; memcpy(&b, &d, 8); return b; }
static inline f64 porf_bits_to_f32(u32 b) { f32 f; memcpy(&f, &b, 4); return (f64)f; }
static inline u32 porf_f32_to_bits(f64 d) { f32 f = (f32)d; u32 b; memcpy(&b, &f, 4); return b; }
static inline f64 porf_jsval_to_f64(jsval v) { return v.val; }
#define porf_bits_to_f64(x) _Generic((x), jsval: porf_jsval_to_f64, default: porf_bits_to_f64_bits)(x)

static inline int porf_jv_is_num(jsval v) { return v.type == ${TYPES.number}; }
static inline i32 porf_jv_type(jsval v) { return v.type; }
static inline f64 porf_jv_val(jsval v) { return v.val; }
static inline u32 porf_jv_ptr(jsval v) { return (u32)v.val; }
static inline jsval porf_box_num(f64 d) { return (jsval){d, ${TYPES.number}}; }
static inline jsval porf_box(f64 payload, i32 type) {
  return type == ${TYPES.number} ? porf_box_num(payload) : (jsval){payload, type};
}
static jsbits porf_pack_bigint(f64 d);
static inline jsbits porf_pack(jsval v) {
  if (v.type == ${TYPES.number}) {
    const jsbits b = porf_f64_to_bits(v.val);
    // negative quiet NaNs collide with the boxed encoding: canonicalize
    return (b & JV_PATTERN) == JV_PATTERN ? 0x7FF8000000000000ull : b;
  }
  if (v.type == ${TYPES.bigint} && !(v.val >= 0.0 && v.val < 4294967296.0)) return porf_pack_bigint(v.val);
  return JV_PATTERN | ((u64)(v.type & 0xFF) << 43) | (u64)(u32)v.val;
}
${sti}jsbits porf_arr_pack(jsval v) {
  const jsbits b = porf_pack(v);
  return b == 0 ? JV_ZERO_BITS : b;
}
static inline jsval porf_unpack(jsbits b) {
  if ((b & JV_PATTERN) != JV_PATTERN) return porf_box_num(porf_bits_to_f64(b));
  if (b & (1ull << 42)) return (jsval){(f64)(u32)b + 2251799813685248.0, ${TYPES.bigint}};
  return (jsval){(f64)(u32)b, (i32)((b >> 43) & 0xFF)};
}
static inline f64 porf_canon(f64 d) { return d == d ? d : porf_bits_to_f64(0x7FF8000000000000ull); }

static u32* porf_promise_job_queue = NULL;
// async context (AsyncLocalStorage) a promise job runs with, captured when its reaction is made
static jsbits porf_async_context = JV_UNDEFINED_BITS;
// sproutboat: per-request cpu
#define PORF_CPU_SLOTS 256
static u32 porf_cpu_cur = 0;
static double porf_cpu_last_ns = 0;
static double porf_cpu_acc[PORF_CPU_SLOTS];
static u16 porf_cpu_gen[PORF_CPU_SLOTS];
static u8 porf_cpu_used[PORF_CPU_SLOTS];
static u16 porf_cpu_next_gen = 0;
static u32 porf_cpu_next_slot = 0;
static inline double porf_cpu_now_ns(void) { struct timespec ts; clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts); return (double)ts.tv_sec * 1e9 + (double)ts.tv_nsec; }
static inline int porf_cpu_live(u32 id) { const u32 i = id & 255u; return id != 0 && porf_cpu_used[i] && porf_cpu_gen[i] == (u16)(id >> 8); }
static void porf_cpu_switch(u32 next) {
  if (next == porf_cpu_cur) return;
  const double t = porf_cpu_now_ns();
  if (porf_cpu_live(porf_cpu_cur)) porf_cpu_acc[porf_cpu_cur & 255u] += t - porf_cpu_last_ns;
  porf_cpu_last_ns = t;
  porf_cpu_cur = next;
}
static u32 porf_cpu_begin(void) {
  for (u32 k = 0; k < PORF_CPU_SLOTS; k++) {
    const u32 i = (porf_cpu_next_slot + k) & 255u;
    if (porf_cpu_used[i]) continue;
    porf_cpu_next_slot = i + 1u;
    if (++porf_cpu_next_gen == 0) porf_cpu_next_gen = 1;
    porf_cpu_used[i] = 1; porf_cpu_gen[i] = porf_cpu_next_gen; porf_cpu_acc[i] = 0;
    const u32 id = i | ((u32)porf_cpu_next_gen << 8);
    porf_cpu_switch(id);
    return id;
  }
  return 0;
}
static double porf_cpu_read_ms(u32 id) {
  if (!porf_cpu_live(id)) return -1.0;
  if (porf_cpu_cur == id) { const double t = porf_cpu_now_ns(); porf_cpu_acc[id & 255u] += t - porf_cpu_last_ns; porf_cpu_last_ns = t; }
  return porf_cpu_acc[id & 255u] / 1e6;
}
static void porf_cpu_end(u32 id) {
  if (!porf_cpu_live(id)) return;
  if (porf_cpu_cur == id) porf_cpu_switch(0);
  porf_cpu_used[id & 255u] = 0;
}
static inline u32 porf_cpu_current(void) { return porf_cpu_cur; }
// bloom filter of key hashes some accessor property was defined for
static u32 porf_accessor_keys[64];
static u32 porf_promise_job_head = 0;
static u32 porf_promise_job_len = 0;
static u32 porf_promise_job_cap = 0;

static void (*porf_promise_run_coro_reaction_impl)(u32) = NULL;

static void porf_promise_enqueue_job(u32 reaction) {
  if (reaction == 0) return;
  if (porf_promise_job_len == porf_promise_job_cap) {
    const u32 old_cap = porf_promise_job_cap;
    const u32 new_cap = old_cap == 0 ? 64u : old_cap * 2u;
    u32* next = (u32*)malloc((size_t)new_cap * sizeof(u32));
    if (!next) abort();
    for (u32 i = 0; i < porf_promise_job_len; i++) {
      next[i] = porf_promise_job_queue[(porf_promise_job_head + i) & (old_cap - 1u)];
    }
    free(porf_promise_job_queue);
    porf_promise_job_queue = next;
    porf_promise_job_cap = new_cap;
    porf_promise_job_head = 0;
  }
  porf_promise_job_queue[(porf_promise_job_head + porf_promise_job_len) & (porf_promise_job_cap - 1u)] = reaction;
  porf_promise_job_len++;
}

static u32 porf_promise_dequeue_job(void) {
  if (porf_promise_job_len == 0) { porf_cpu_switch(0); return 0; }
  const u32 reaction = porf_promise_job_queue[porf_promise_job_head];
  porf_cpu_switch(*(u32*)(MEM + reaction + PORF_REACTION_CPU));
  porf_promise_job_head = (porf_promise_job_head + 1u) & (porf_promise_job_cap - 1u);
  porf_promise_job_len--;
  if (porf_promise_job_len == 0) porf_promise_job_head = 0;
  return reaction;
}

static void porf_promise_run_coro_reaction(u32 reaction) {
  if (!porf_promise_run_coro_reaction_impl) abort();
  porf_promise_run_coro_reaction_impl(reaction);
}


static inline i32 porf_jv_eq(jsval a, jsval b) {
  if (a.type != b.type) return 0;
  if (a.type == ${TYPES.number}) return a.val == b.val;
  return (u32)a.val == (u32)b.val;
}

// truthiness: number path = one compare; boxed = payload check, strings load length
static inline i32 porf_truthy(jsval v) {
  if (v.type == ${TYPES.number}) return v.val == v.val && v.val != 0.0;
  if (v.type == ${TYPES.string} || v.type == ${TYPES.bytestring}) return *(u32*)(MEM + (u32)v.val) != 0u;
  // Boolean/Number objects hold their primitive inline but are always truthy
  return (u32)v.val != 0u || v.type == ${TYPES.booleanobject} || v.type == ${TYPES.numberobject};
}

static inline i32 porf_falsy(jsval v) {
  if (v.type == ${TYPES.number}) return v.val != v.val || v.val == 0.0;
  if (v.type == ${TYPES.string} || v.type == ${TYPES.bytestring}) return *(u32*)(MEM + (u32)v.val) == 0u;
  return (u32)v.val == 0u && v.type != ${TYPES.booleanobject} && v.type != ${TYPES.numberobject};
}

// new on an explicit return: an object stands, else the instance
${st}PORF_CC jsval porf_ctor_ret(jsval ret, jsval thisv) {
  const i32 t = ret.type;
  return t > ${TYPES.symbol} && ((u32)ret.val != 0 || t != ${TYPES.object}) && t != ${TYPES.string} && t != ${TYPES.bytestring} ? ret : thisv;
}

static inline i32 porf_nullish(jsval v) {
  return v.type == ${TYPES.undefined} || (v.type == ${TYPES.object} && (u32)v.val == 0u);
}

// saturating f64 -> int (JS semantics handled above; this is trunc_sat)
static inline i32 porf_sat_i32(f64 d) {
  if (d != d) return 0;
  if (d <= -2147483648.0) return -2147483648;
  if (d >= 2147483647.0) return 2147483647;
  return (i32)d;
}
static inline u32 porf_sat_u32(f64 d) {
  if (d != d || d <= 0.0) return 0;
  if (d >= 4294967295.0) return 4294967295u;
  return (u32)d;
}
static inline u32 porf_i32_to_u32(i32 x) { return x < 0 ? 0u : (u32)x; }
static inline i32 porf_u32_to_i32(u32 x) { return x > 2147483647u ? 2147483647 : (i32)x; }
// arm64 saturates so in one instruction, what the compiler can range stays in c to fold
#if defined(__aarch64__) && !defined(__TINYC__)
#define PORF_FOLDS(d) __builtin_constant_p((d) >= -2147483648.0 && (d) <= 4294967295.0)
static inline i32 porf_f64_to_i32(f64 d) {
  if (PORF_FOLDS(d)) return porf_sat_i32(d);
  i32 r;
  __asm__("fcvtzs %w0, %d1" : "=r"(r) : "w"(d));
  return r;
}
static inline u32 porf_f64_to_u32(f64 d) {
  if (PORF_FOLDS(d)) return porf_sat_u32(d);
  u32 r;
  __asm__("fcvtzu %w0, %d1" : "=r"(r) : "w"(d));
  return r;
}
#else
#define porf_f64_to_i32 porf_sat_i32
#define porf_f64_to_u32 porf_sat_u32
#endif
// js %: positive int32 operands take the integer remainder, the rest (and -0) fmod
static inline f64 porf_mod(f64 a, f64 b) {
  if (a > 0.0 && a <= 2147483647.0 && b >= 1.0 && b <= 2147483647.0) {
    const i32 ia = (i32)a, ib = (i32)b;
    if ((f64)ia == a && (f64)ib == b) return (f64)(ia % ib);
  }
  return fmod(a, b);
}

// ToUint32: in i64 range the cast truncates and wraps exactly
static inline u32 porf_to_uint32(f64 d) {
  if (d > -9223372036854775808.0 && d < 9223372036854775808.0) return (u32)(i64)d;
  if (d != d || d == INFINITY || d == -INFINITY) return 0;
  const f64 w = fmod(d, 4294967296.0);
  return (u32)(i64)(w < 0.0 ? w + 4294967296.0 : w);
}

static inline i32 porf_clz32(u32 x) { return x ? __builtin_clz(x) : 32; }
static inline i32 porf_ctz32(u32 x) { return x ? __builtin_ctz(x) : 32; }
static inline u32 porf_rotl32(u32 x, u32 k) { k &= 31u; return (x << k) | (x >> ((0u - k) & 31u)); }
static inline u32 porf_rotr32(u32 x, u32 k) { k &= 31u; return (x >> k) | (x << ((0u - k) & 31u)); }
static inline u64 porf_rotl64(u64 x, u64 k) { k &= 63ull; return (x << k) | (x >> ((0ull - k) & 63ull)); }
static inline u64 porf_rotr64(u64 x, u64 k) { k &= 63ull; return (x >> k) | (x << ((0ull - k) & 63ull)); }
static inline f64 porf_round(f64 d) { f64 r = floor(d); if (d - r >= 0.5) r += 1.0; return copysign(r, d); }
static inline f64 porf_nearest(f64 d) { f64 r = round(d); if (fabs(d - trunc(d)) == 0.5 && ((i64)r & 1)) r -= d < 0 ? -1.0 : 1.0; return r; }
static inline f64 porf_f64_min(f64 a, f64 b) { return a != a ? a : b != b ? b : a < b ? a : b; }
static inline f64 porf_f64_max(f64 a, f64 b) { return a != a ? a : b != b ? b : a > b ? a : b; }

static struct timespec porf_performance_start;
static f64 porf_performance_time_origin_value = 0.0;
static int porf_performance_started = 0;

static inline void porf_performance_init(void) {
  if (!porf_performance_started) {
    struct timespec real;
    clock_gettime(CLOCK_REALTIME, &real);
    clock_gettime(CLOCK_MONOTONIC, &porf_performance_start);
    porf_performance_time_origin_value = (f64)real.tv_sec * 1000.0 + (f64)real.tv_nsec / 1.0e6;
    porf_performance_started = 1;
  }
}

${sti}f64 porf_performance_now(void) {
  porf_performance_init();

  struct timespec now;
  clock_gettime(CLOCK_MONOTONIC, &now);

  i64 sec = (i64)now.tv_sec - (i64)porf_performance_start.tv_sec;
  i64 nsec = (i64)now.tv_nsec - (i64)porf_performance_start.tv_nsec;
  if (nsec < 0) {
    sec--;
    nsec += 1000000000ll;
  }
  return (f64)sec * 1000.0 + (f64)nsec / 1.0e6;
}

${sti}f64 porf_performance_time_origin(void) {
  porf_performance_init();
  return porf_performance_time_origin_value;
}

// unaligned access (DataView, object entry values): memcpy folds to plain loads on x86/arm
// tcc: plain derefs instead - it emits real memcpy calls, and it never optimizes on alignment UB
#ifdef __TINYC__
#define porf_load_un_u16(p) (*(const u16*)(p))
#define porf_load_un_u32(p) (*(const u32*)(p))
#define porf_load_un_u64(p) (*(const u64*)(p))
#define porf_load_un_f32(p) (*(const f32*)(p))
#define porf_load_un_f64(p) (*(const f64*)(p))
#define porf_store_un_u16(p, v) (*(u16*)(p) = (v))
#define porf_store_un_u32(p, v) (*(u32*)(p) = (v))
#define porf_store_un_u64(p, v) (*(u64*)(p) = (v))
#define porf_store_un_f32(p, v) (*(f32*)(p) = (v))
#define porf_store_un_f64(p, v) (*(f64*)(p) = (v))
#else
#define PORF_UN(ctype) \\
  static inline ctype porf_load_un_##ctype(const u8* p) { ctype v; memcpy(&v, p, sizeof v); return v; } \\
  static inline void porf_store_un_##ctype(u8* p, ctype v) { memcpy(p, &v, sizeof v); }
PORF_UN(u16) PORF_UN(u32) PORF_UN(u64) PORF_UN(f32) PORF_UN(f64)
#endif

// exceptions: setjmp-based, exception is a jsval
${st}jmp_buf* porf_try_data;
${st}i32 porf_try_cap = 0;
${st}i32 porf_try_depth = 0;
${st}jsval porf_exception = {0.0, ${TYPES.undefined}};

${st}void porf_try_grow(void) {
  while (porf_try_depth > porf_try_cap) porf_try_cap = porf_try_cap ? porf_try_cap << 1 : 8;
  porf_try_data = (jmp_buf*)realloc(porf_try_data, (size_t)porf_try_cap * sizeof(jmp_buf));
  if (!porf_try_data) abort();
}
${sti}jmp_buf* porf_try_ensure(void) {
  if (porf_try_depth > porf_try_cap) porf_try_grow();
  return porf_try_data;
}

// innermost open iterator record of the running coroutine
${st}jsval porf_iter_open = {0.0, ${TYPES.undefined}};
${st}i32 porf_iter_base = 0;
${iterClose ? `static void porf_iter_unwind(void);
` : ''}\
${toStr ? `PORF_CC jsval ${toStr}(jsval);
` : ''}\
${fatal ? `PORF_CC jsval ${fatal}(jsval);
` : ''}\
PORF_NORETURN ${st}void porf_throw(jsval v) {
  porf_exception = v;
${iterClose ? `  porf_iter_unwind();
` : ''}\
  if (porf_try_depth > 0) _longjmp(porf_try_data[porf_try_depth - 1], 1);
${fatal ? `  ${fatal}(v);
` : ''}\
${toStr ? `
  static i32 _uncaught_busy = 0;
  if (!_uncaught_busy) {
    _uncaught_busy = 1;
    const jsval _s = ${toStr}(v);
    const i32 _st = porf_jv_type(_s);
    const u32 _sp = (u32)_s.val;
    if (_st == ${TYPES.bytestring} && _sp) { fprintf(stderr, "Uncaught %.*s\\n", (int)*(u32*)(MEM + _sp), (const char*)(MEM + _sp + 4)); exit(1); }
    if (_st == ${TYPES.string} && _sp) {
      const u32 _sl = *(u32*)(MEM + _sp);
      fprintf(stderr, "Uncaught ");
      for (u32 _i = 0; _i < _sl; _i++) { const u16 _c = porf_load_un_u16(MEM + _sp + 4 + _i * 2); fputc(_c < 128 ? (int)_c : '?', stderr); }
      fputc('\\n', stderr);
      exit(1);
    }
  }
` : ''}\
  fprintf(stderr, "Uncaught exception\\n");
  exit(1);
}

// internal throws construct a standard error (message jsval at +0, like the error
// builtins) so a caught internal error behaves identically to a \`new X(msg)\` one
${sti}u32 porf_alloc(u32 bytes, u32 typeId);
PORF_NORETURN ${st}void porf_throw_new(i32 errType, u32 msgId) {
  const u32 p = porf_alloc(8, (u32)errType);
  *(jsbits*)(MEM + p) = JV_PATTERN | ((u64)${TYPES.bytestring} << 43) | msgId;
  porf_throw(porf_box((f64)p, errType));
}

PORF_NORETURN ${st}void porf_unreachable(const char* msg) {
  fprintf(stderr, "porffor: unreachable%s%s\\n", msg ? ": " : "", msg ? msg : "");
  abort();
}

// strings porf_str_append may extend in place until a read seals them, cap 0 is a free slot, every gc clears them
#define PORF_STR_BUILDERS 8
static u32 porf_str_builders[PORF_STR_BUILDERS];
static u32 porf_str_builder_caps[PORF_STR_BUILDERS];
static u32 porf_str_builder_last = 0;

// deepest stack a collection has scanned
static uintptr_t porf_gc_stack_lo = UINTPTR_MAX;

${prefs.gc === false ? PORF_BUMP_ALLOC() : PORF_GC_ALLOC()}

// zero the stack below before blocking, as deep as a gc has scanned, so stale words don't become false roots
${st}__attribute__((noinline)) void porf_scrub_stack(void) {
  const uintptr_t here = (uintptr_t)__builtin_frame_address(0);
  size_t depth = here > porf_gc_stack_lo ? here - porf_gc_stack_lo + 1024 : 0;
  if (depth < 16384) depth = 16384;
  if (depth > 262144) depth = 262144;
  u8* pad = __builtin_alloca(depth);
  memset(pad, 0, depth);
  __asm__ volatile("" : : "r"(pad) : "memory");
}

// event loop waits: an idle collection that comes due meanwhile runs then
${st}void porf_idle_sleep(f64 ms) {
  const i64 idle_in = porf_gc_idle_due();
  const f64 now = idle_in >= 0 && (f64)idle_in < ms ? (f64)idle_in : ms;
  struct timespec ts = { (time_t)(now / 1000), (long)((now - (f64)((i64)now / 1000) * 1000) * 1e6) };
  nanosleep(&ts, NULL);
  if (now == ms) return;
  porf_gc_idle();
  porf_idle_sleep(ms - now);
}

// array:      [len i32 @0][ent u32 @4][cap i32 @8]; entries = jsval[cap]
// object:     [count i32 @0][bcap i32 @4][ent u32 @8][buckets u32 @12]
//             entries = {key jsval, val jsval}[count] in insertion order
//             buckets = i32[bcap] entry indices, -1 empty (ordered hashmap)
// bytestring: [len u32 @0][bytes @4]
// function:   [fnIdx u32 @0][env u32 @4]; env = jsval slots
// array header padded to 16 so inline entries stay 8-aligned
#define PORF_ARR_LEN(a) (*(i32*)(MEM + (a)))
#define PORF_ARR_ENT(a) (*(u32*)(MEM + (a) + 4))
#define PORF_ARR_CAP(a) (*(i32*)(MEM + (a) + 8))
// cached underlying object (props beyond the elements), see __Porffor_object_underlyingPtr
#define PORF_ARR_UNDERLYING(a) (*(u32*)(MEM + (a) + 12))

${st}u32 porf_arr_new(i32 len, i32 cap) {
  if (cap < len) cap = len;
  if (cap < 4) cap = 4;
  const u32 a = porf_alloc(16 + ((u32)cap << 3), ${TYPES.array});
  PORF_ARR_LEN(a) = len; PORF_ARR_ENT(a) = a + 16; PORF_ARR_CAP(a) = cap; PORF_ARR_UNDERLYING(a) = 0;
  memset(MEM + PORF_ARR_ENT(a), 0, (size_t)cap << 3);
  return a;
}

// length can exceed capacity (a.length = n doesn't grow): slots past cap are holes
${sti}int porf_arr_has_own(u32 a, u32 i) {
  if (i >= (u32)PORF_ARR_LEN(a) || i >= (u32)PORF_ARR_CAP(a)) return 0;
  return *(jsbits*)(MEM + PORF_ARR_ENT(a) + ((u64)i << 3)) != 0;
}

${sti}jsval porf_arr_get(u32 a, u32 i) {
  if (i >= (u32)PORF_ARR_LEN(a) || i >= (u32)PORF_ARR_CAP(a)) return JV_UNDEFINED;
  const jsbits b = *(jsbits*)(MEM + PORF_ARR_ENT(a) + ((u64)i << 3));
  if (b == 0) return JV_UNDEFINED;
  return porf_unpack(b);
}


${st}u32 porf_arr_grow(u32 a, i32 need) {
  i32 cap = PORF_ARR_CAP(a);
  if (need <= cap) return PORF_ARR_ENT(a);
  const i32 copy = PORF_ARR_LEN(a) < cap ? PORF_ARR_LEN(a) : cap;
  while (cap < need) cap += cap >> 1 > 4 ? cap >> 1 : 4;
  const u32 ent = porf_alloc((u32)cap << 3, 0);
  memcpy(MEM + ent, MEM + PORF_ARR_ENT(a), (size_t)copy << 3);
  memset(MEM + ent + ((u64)copy << 3), 0, ((size_t)cap - (size_t)copy) << 3);
  porf_gc_entries_moved(PORF_ARR_ENT(a) != a + 16u ? PORF_ARR_ENT(a) : 0u, ent);
  PORF_ARR_ENT(a) = ent; PORF_ARR_CAP(a) = cap;
  porf_gc_barrier(a, ${TYPES.array});
  return ent;
}

${sti}void porf_arr_set(u32 a, u32 i, jsval v) {
  const i32 len = PORF_ARR_LEN(a);
  if (i >= (u32)PORF_ARR_CAP(a)) porf_arr_grow(a, (i32)i + 1);
  if (i >= (u32)len) PORF_ARR_LEN(a) = (i32)i + 1;
  const u32 ent = PORF_ARR_ENT(a);
  *(jsbits*)(MEM + ent + ((u64)i << 3)) = porf_arr_pack(v);
  // separate entries take the slot's card, the header's would rescan every element
  if (porf_gc_type_can_reference(v.type)) {
    if (ent != a + 16u) porf_gc_barrier_slot(a, ent, ent + (i << 3));
      else porf_gc_barrier(a, ${TYPES.array});
  }
}
${iterClose ? `
${st}void porf_iter_link(jsval rec) {
  porf_arr_set((u32)rec.val, 4, porf_iter_open);
  porf_arr_set((u32)rec.val, 5, porf_box_num((f64)(porf_try_depth - porf_iter_base)));
  porf_iter_open = rec;
}

${st}void porf_iter_unlink(void) {
  porf_iter_open = porf_arr_get((u32)porf_iter_open.val, 4);
}

PORF_CC jsval ${iterClose}(jsval);

// close the records a throw leaves, dropping errors from closing unless it is a generator return
static void porf_iter_unwind(void) {
  jsval exception = porf_exception;
  while (porf_jv_type(porf_iter_open) != ${TYPES.undefined} &&
         porf_iter_base + (i32)porf_arr_get((u32)porf_iter_open.val, 5).val >= porf_try_depth) {
    const jsval rec = porf_iter_open;
    porf_iter_open = porf_arr_get((u32)rec.val, 4);
    const i32 depth = porf_try_depth++;
    if (_setjmp(porf_try_ensure()[depth]) == 0) ${iterClose}(rec);
      else if (porf_jv_eq(exception, porf_box(0.0, ${TYPES.__porffor_generator}))) exception = porf_exception;
    porf_try_depth = depth;
  }
  porf_exception = exception;
}
` : ''}
${st}void porf_arr_delete(u32 a, u32 i) {
  if (i >= (u32)PORF_ARR_LEN(a) || i >= (u32)PORF_ARR_CAP(a)) return;
  *(jsbits*)(MEM + PORF_ARR_ENT(a) + ((u64)i << 3)) = 0;
}

${st}void porf_arr_set_len(u32 a, u32 new_len) {
  const u32 old_len = (u32)PORF_ARR_LEN(a);
  if (new_len < old_len) {
    const u32 cap = (u32)PORF_ARR_CAP(a);
    const u32 clear = old_len < cap ? old_len : cap;
    if (new_len < clear) memset(MEM + PORF_ARR_ENT(a) + ((u64)new_len << 3), 0, ((size_t)clear - new_len) << 3);
  }
  PORF_ARR_LEN(a) = (i32)new_len;
}

${st}jsval porf_arr_push(u32 a, jsval v) {
  const i32 len = PORF_ARR_LEN(a);
  const u32 ent = porf_arr_grow(a, len + 1);
  *(jsbits*)(MEM + ent + ((u64)len << 3)) = porf_arr_pack(v);
  PORF_ARR_LEN(a) = len + 1;
  if (porf_gc_type_can_reference(v.type)) {
    if (ent != a + 16u) porf_gc_barrier_slot(a, ent, ent + ((u32)len << 3));
      else porf_gc_barrier(a, ${TYPES.array});
  }
  return porf_box_num((f64)(len + 1));
}

${st}u32 porf_bstr_new(u32 len) {
  const u32 s = porf_alloc(4 + len, ${TYPES.bytestring});
  *(u32*)(MEM + s) = len;
  return s;
}

${st}jsval porf_str_append(jsval a, jsval b) {
  volatile u32 keep_a = (u32)a.val, keep_b = (u32)b.val;
  const u32 pa = keep_a, pb = keep_b;
  const u32 la = *(u32*)(MEM + pa), lb = *(u32*)(MEM + pb);
  if (lb == 0) return a;
  const u32 wide = a.type == ${TYPES.string} || b.type == ${TYPES.string};
  u32 slot = 0, free = PORF_STR_BUILDERS;
  for (; slot < PORF_STR_BUILDERS; slot++) {
    if (porf_str_builder_caps[slot] == 0) { if (free == PORF_STR_BUILDERS) free = slot; }
      else if (porf_str_builders[slot] == pa) break;
  }

  u32 s = pa;
  if (slot == PORF_STR_BUILDERS || la + lb > porf_str_builder_caps[slot] || (wide && a.type == ${TYPES.bytestring})) {
    const u32 cap = (la + lb) * 2 + 16;
    s = porf_alloc(4 + (cap << wide), wide ? ${TYPES.string} : ${TYPES.bytestring});
    if (wide && a.type == ${TYPES.bytestring}) {
      u16* out = (u16*)(MEM + s + 4);
      for (u32 i = 0; i < la; i++) out[i] = MEM[pa + 4 + i];
    } else {
      memcpy(MEM + s + 4, MEM + pa + 4, (size_t)la << wide);
    }
    // full: evict the newest builder, nested ones are short lived
    if (slot == PORF_STR_BUILDERS) slot = porf_str_builder_last = free == PORF_STR_BUILDERS ? porf_str_builder_last : free;
    porf_str_builders[slot] = s;
    porf_str_builder_caps[slot] = cap;
  }

  if (!wide) {
    memcpy(MEM + s + 4 + la, MEM + pb + 4, lb);
  } else if (b.type == ${TYPES.string}) {
    memcpy(MEM + s + 4 + la * 2, MEM + pb + 4, (size_t)lb * 2);
  } else {
    u16* out = (u16*)(MEM + s + 4) + la;
    for (u32 i = 0; i < lb; i++) out[i] = MEM[pb + 4 + i];
  }
  *(u32*)(MEM + s) = la + lb;
  return porf_box((f64)s, wide ? ${TYPES.string} : ${TYPES.bytestring});
}

${sti}jsval porf_str_seal(jsval v) {
  if (v.type == ${TYPES.string} || v.type == ${TYPES.bytestring}) {
    for (u32 i = 0; i < PORF_STR_BUILDERS; i++) if (porf_str_builders[i] == (u32)v.val) porf_str_builder_caps[i] = 0;
  }
  return v;
}

${sti}__attribute__((always_inline)) jsval porf_str_concat(jsval a, jsval b) {
  volatile u32 keep_a = (u32)a.val, keep_b = (u32)b.val;
  const u32 pa = keep_a, pb = keep_b;
  const u32 la = *(u32*)(MEM + pa), lb = *(u32*)(MEM + pb);
  if (a.type == ${TYPES.bytestring} && b.type == ${TYPES.bytestring}) {
    const u32 s = porf_alloc(4 + la + lb, ${TYPES.bytestring});
    *(u32*)(MEM + s) = la + lb;
    memcpy(MEM + s + 4, MEM + pa + 4, la);
    memcpy(MEM + s + 4 + la, MEM + pb + 4, lb);
    return porf_box((f64)s, ${TYPES.bytestring});
  }

  const u32 s = porf_alloc(4 + (la + lb) * 2, ${TYPES.string});
  *(u32*)(MEM + s) = la + lb;
  u16* out = (u16*)(MEM + s + 4);
  if (a.type == ${TYPES.bytestring}) {
    for (u32 i = 0; i < la; i++) out[i] = MEM[pa + 4 + i];
  } else {
    memcpy(out, MEM + pa + 4, (size_t)la * 2);
  }
  out += la;
  if (b.type == ${TYPES.bytestring}) {
    for (u32 i = 0; i < lb; i++) out[i] = MEM[pb + 4 + i];
  } else {
    memcpy(out, MEM + pb + 4, (size_t)lb * 2);
  }
  return porf_box((f64)s, ${TYPES.string});
}

// rope:   [len u32 @0][buf u32 @4][flat u32 @8], the first len chars of buf, flat once made
// buffer: [used u32 @0][cap u32 @4][wide u32 @8][chars @12], the newest view appends in place
${st}u32 porf_rope_buffer(u32 cap, u32 wide) {
  const u32 buf = porf_alloc(12 + (cap << wide), 0);
  *(u32*)(MEM + buf + 4) = cap;
  *(u32*)(MEM + buf + 8) = wide;
  return buf;
}

${st}jsval porf_rope_new(u32 len, u32 buf) {
  volatile u32 keep_buf = buf;
  const u32 r = porf_alloc(12, ${TYPES.__porffor_rope});
  *(u32*)(MEM + r) = len;
  *(u32*)(MEM + r + 4) = keep_buf;
  *(u32*)(MEM + r + 8) = 0;
  return porf_box((f64)r, ${TYPES.__porffor_rope});
}

${sti}void porf_rope_copy(u32 buf, const u8* from, u32 n, u32 from_wide) {
  const u32 used = *(u32*)(MEM + buf), wide = *(u32*)(MEM + buf + 8);
  if (wide == from_wide) {
    memcpy(MEM + buf + 12 + (used << wide), from, (size_t)n << wide);
  } else {
    u16* out = (u16*)(MEM + buf + 12) + used;
    for (u32 i = 0; i < n; i++) out[i] = from[i];
  }
  *(u32*)(MEM + buf) = used + n;
}

${st}jsval porf_rope_append(jsval r, jsval s) {
  volatile u32 keep_r = (u32)r.val, keep_s = (u32)s.val;
  const u32 pr = keep_r, ps = keep_s;
  const u32 len = *(u32*)(MEM + pr), ls = *(u32*)(MEM + ps), wide = s.type == ${TYPES.string};
  if (ls == 0) return r;
  u32 buf = *(u32*)(MEM + pr + 4);
  const u32 buf_wide = *(u32*)(MEM + buf + 8);
  if (len != *(u32*)(MEM + buf) || len + ls > *(u32*)(MEM + buf + 4) || wide > buf_wide) {
    const u32 grown = porf_rope_buffer((len + ls) * 2, wide | buf_wide);
    porf_rope_copy(grown, MEM + buf + 12, len, buf_wide);
    buf = grown;
  }
  volatile u32 keep_buf = buf;
  porf_rope_copy(buf, MEM + ps + 4, ls, wide);
  return porf_rope_new(len + ls, keep_buf);
}

// a + b of strings for x[k] += b: long results become ropes
${st}jsval porf_rope_add(jsval a, jsval b) {
  volatile u32 keep_a = (u32)a.val, keep_b = (u32)b.val;
  if (a.type != ${TYPES.__porffor_rope}) {
    if (*(u32*)(MEM + keep_a) + *(u32*)(MEM + keep_b) < 1024) return porf_str_concat(a, b);
    a = porf_rope_append(porf_rope_new(0, porf_rope_buffer(0, 0)), a);
  }
  return porf_rope_append(a, b);
}

${st}jsval porf_rope_flat(jsval r) {
  volatile u32 keep_r = (u32)r.val;
  const u32 pr = keep_r, wide = *(u32*)(MEM + *(u32*)(MEM + pr + 4) + 8);
  if (*(u32*)(MEM + pr + 8) == 0) {
    const u32 len = *(u32*)(MEM + pr);
    const u32 flat = porf_alloc(4 + (len << wide), wide ? ${TYPES.string} : ${TYPES.bytestring});
    *(u32*)(MEM + flat) = len;
    memcpy(MEM + flat + 4, MEM + *(u32*)(MEM + pr + 4) + 12, (size_t)len << wide);
    *(u32*)(MEM + pr + 8) = flat;
    porf_gc_barrier(pr, ${TYPES.__porffor_rope});
  }
  return porf_box((f64)*(u32*)(MEM + pr + 8), wide ? ${TYPES.string} : ${TYPES.bytestring});
}

${sti}i32 porf_str_eq(jsval a, jsval b) {
  const u32 pa = (u32)a.val, pb = (u32)b.val;
  if (pa == pb) return 1;
  const u32 la = *(u32*)(MEM + pa);
  if (la != *(u32*)(MEM + pb)) return 0;
  const i32 ta = porf_jv_type(a), tb = porf_jv_type(b);
  if (ta == tb) {
    const u8* x = MEM + pa + 4;
    const u8* y = MEM + pb + 4;
    const size_t n = (size_t)la * (ta == ${TYPES.string} ? 2 : 1);
    // short ones (most keys): first and last word, overlapping
    if (n >= 8 && n <= 16) {
      u64 x0, y0, x1, y1;
      memcpy(&x0, x, 8); memcpy(&y0, y, 8); memcpy(&x1, x + n - 8, 8); memcpy(&y1, y + n - 8, 8);
      return x0 == y0 && x1 == y1;
    }
    if (n >= 4 && n < 8) {
      u32 x0, y0, x1, y1;
      memcpy(&x0, x, 4); memcpy(&y0, y, 4); memcpy(&x1, x + n - 4, 4); memcpy(&y1, y + n - 4, 4);
      return x0 == y0 && x1 == y1;
    }
    return memcmp(x, y, n) == 0;
  }
  if (ta == ${TYPES.bytestring}) {
    for (u32 i = 0; i < la; i++) if ((u16)MEM[pa + 4 + i] != *(u16*)(MEM + pb + 4 + i * 2)) return 0;
  } else {
    for (u32 i = 0; i < la; i++) if (*(u16*)(MEM + pa + 4 + i * 2) != (u16)MEM[pb + 4 + i]) return 0;
  }
  return 1;
}

${st}jsval porf_bstr_of(const char* buf, u32 len) {
  const u32 s = porf_bstr_new(len);
  memcpy(MEM + s + 4, buf, len);
  return porf_box((f64)s, ${TYPES.bytestring});
}

// would rounding x * 10^k to an integer hit an exact tie
static int porf_num_tie(f64 x, i32 k) {
  x = fabs(x);
  if (k >= 0) {
    const f64 t = ldexp(x, k + 1);
    return t == trunc(t) && fmod(t, 2.0) == 1.0;
  }
  if (k < -22) return 0;
  f64 m = 1;
  for (i32 i = 0; i < -k; i++) m *= 10;
  return fmod(x, m) == m / 2;
}

static int porf_digits_inc(char* s, i32 n) {
  for (i32 i = n - 1; i >= 0; i--) {
    if (s[i] == '.') continue;
    if (s[i] != '9') {
      s[i]++;
      return 0;
    }
    s[i] = '0';
  }
  return 1;
}

// C rounds exact ties to even, JS away from zero
static i32 porf_num_digits(f64 x, i32 prec, char* digits) {
  char buf[128];
  snprintf(buf, sizeof buf, "%.*e", prec - 1, x);
  i32 e = atoi(strchr(buf, 'e') + 1);
  const int tie = porf_num_tie(x, prec - 1 - e);
  if (tie) snprintf(buf, sizeof buf, "%.*e", prec, x);
  digits[0] = buf[0];
  memcpy(digits + 1, buf + 2, (size_t)(prec - 1));
  if (tie && porf_digits_inc(digits, prec)) {
    digits[0] = '1';
    e++;
  }
  return e;
}

static i32 porf_num_shortest(f64 x, char* digits, i32* e) {
  char buf[32];
  i32 prec = isnormal(x) ? 15 : 1;
  for (; prec < 17; prec++) {
    snprintf(buf, sizeof buf, "%.*e", prec - 1, x);
    if (strtod(buf, NULL) == x) break;
  }
  if (prec == 17) snprintf(buf, sizeof buf, "%.16e", x);
  *e = atoi(strchr(buf, 'e') + 1);
  digits[0] = buf[0];
  memcpy(digits + 1, buf + 2, (size_t)(prec - 1));
  while (prec > 1 && digits[prec - 1] == '0') prec--;
  return prec;
}

static char* porf_num_write_exp(char* p, const char* digits, i32 k, i32 e) {
  *p++ = digits[0];
  if (k > 1) {
    *p++ = '.';
    memcpy(p, digits + 1, (size_t)(k - 1));
    p += k - 1;
  }
  return p + sprintf(p, "e%+d", e);
}

${st}jsval porf_num_to_str(f64 d) {
  if (d != d) return porf_bstr_of("NaN", 3);
  if (d == INFINITY) return porf_bstr_of("Infinity", 8);
  if (d == -INFINITY) return porf_bstr_of("-Infinity", 9);

  char buf[32];
  char* p = buf;
  if (d < 0) {
    *p++ = '-';
    d = -d;
  }

  if (d == trunc(d) && d < 9007199254740992.0) {
    char tmp[16];
    i32 n = 0;
    u64 v = (u64)d;
    do tmp[n++] = (char)('0' + v % 10u); while (v /= 10u);
    while (n) *p++ = tmp[--n];
    return porf_bstr_of(buf, (u32)(p - buf));
  }

  char digits[17];
  i32 e;
  const i32 k = porf_num_shortest(d, digits, &e), n = e + 1;
  if (k <= n && n <= 21) {
    memcpy(p, digits, (size_t)k);
    memset(p + k, '0', (size_t)(n - k));
    p += n;
  } else if (0 < n && n <= 21) {
    memcpy(p, digits, (size_t)n);
    p += n;
    *p++ = '.';
    memcpy(p, digits + n, (size_t)(k - n));
    p += k - n;
  } else if (-6 < n && n <= 0) {
    *p++ = '0';
    *p++ = '.';
    memset(p, '0', (size_t)-n);
    p += -n;
    memcpy(p, digits, (size_t)k);
    p += k;
  } else p = porf_num_write_exp(p, digits, k, n - 1);
  return porf_bstr_of(buf, (u32)(p - buf));
}

${st}jsval porf_num_to_fixed(f64 d, i32 f) {
  if (!(fabs(d) < 1e21)) return porf_num_to_str(d);
  if (d == 0) d = 0;
  char buf[128];
  if (!porf_num_tie(d, f)) return porf_bstr_of(buf, (u32)snprintf(buf, sizeof buf, "%.*f", f, d));

  i32 n = snprintf(buf, sizeof buf, "%.*f", f + 1, d) - (f == 0 ? 2 : 1);
  const i32 start = d < 0;
  if (porf_digits_inc(buf + start, n - start)) {
    memmove(buf + start + 1, buf + start, (size_t)(n - start));
    buf[start] = '1';
    n++;
  }
  return porf_bstr_of(buf, (u32)n);
}

// f < 0: as many digits as needed
${st}jsval porf_num_to_exponential(f64 d, i32 f) {
  if (!isfinite(d)) return porf_num_to_str(d);
  char buf[128], digits[101];
  char* p = buf;
  if (d < 0) {
    *p++ = '-';
    d = -d;
  }

  i32 k, e = 0;
  if (d == 0) {
    k = f < 0 ? 1 : f + 1;
    memset(digits, '0', (size_t)k);
  } else if (f < 0) k = porf_num_shortest(d, digits, &e);
    else e = porf_num_digits(d, k = f + 1, digits);
  p = porf_num_write_exp(p, digits, k, e);
  return porf_bstr_of(buf, (u32)(p - buf));
}

${st}jsval porf_num_to_precision(f64 d, i32 prec) {
  if (!isfinite(d)) return porf_num_to_str(d);
  char buf[128], digits[100];
  char* p = buf;
  if (d < 0) {
    *p++ = '-';
    d = -d;
  }

  i32 e = 0;
  if (d == 0) memset(digits, '0', (size_t)prec);
    else e = porf_num_digits(d, prec, digits);
  if (e < -6 || e >= prec) p = porf_num_write_exp(p, digits, prec, e);
  else if (e >= 0) {
    memcpy(p, digits, (size_t)(e + 1));
    p += e + 1;
    if (e + 1 < prec) {
      *p++ = '.';
      memcpy(p, digits + e + 1, (size_t)(prec - e - 1));
      p += prec - e - 1;
    }
  } else {
    *p++ = '0';
    *p++ = '.';
    memset(p, '0', (size_t)(-e - 1));
    p += -e - 1;
    memcpy(p, digits, (size_t)prec);
    p += prec;
  }
  return porf_bstr_of(buf, (u32)(p - buf));
}

${st}jsval porf_num_to_radix(f64 d, i32 radix) {
  if (radix == 10 || !isfinite(d)) return porf_num_to_str(d);
  static const char chars[] = "0123456789abcdefghijklmnopqrstuvwxyz";
  char buf[2200];
  i32 lo = 1100, hi = 1100;
  const int negative = d < 0;
  if (negative) d = -d;

  f64 integer = floor(d), fraction = d - integer;
  f64 delta = fmax(0.5 * (nextafter(d, INFINITY) - d), nextafter(0.0, 1.0));
  if (fraction >= delta) {
    buf[hi++] = '.';
    do {
      fraction *= radix;
      delta *= radix;
      const i32 digit = (i32)fraction;
      buf[hi++] = chars[digit];
      fraction -= digit;
      if ((fraction > 0.5 || (fraction == 0.5 && (digit & 1))) && fraction + delta > 1) {
        while (1) {
          if (--hi == 1100) {
            integer += 1;
            break;
          }
          const char c = buf[hi];
          const i32 v = c > '9' ? c - 'a' + 10 : c - '0';
          if (v + 1 < radix) {
            buf[hi++] = chars[v + 1];
            break;
          }
        }
        break;
      }
    } while (fraction >= delta);
  }

  while (integer / radix >= 9007199254740992.0) {
    integer /= radix;
    buf[--lo] = '0';
  }
  do {
    const f64 r = fmod(integer, radix);
    buf[--lo] = chars[(i32)r];
    integer = (integer - r) / radix;
  } while (integer > 0);

  if (negative) buf[--lo] = '-';
  return porf_bstr_of(buf + lo, (u32)(hi - lo));
}

// non-ascii as 0x7f so strtod stops there
static char* porf_str_cstr(jsval s, char* small, u32 cap) {
  const u32 p = (u32)s.val, len = *(u32*)(MEM + p);
  char* buf = len < cap ? small : (char*)malloc(len + 1);
  for (u32 i = 0; i < len; i++) {
    const u32 c = s.type == ${TYPES.string} ? ((u16*)(MEM + p + 4))[i] : MEM[p + 4 + i];
    buf[i] = c < 0x80 ? (char)c : 0x7f;
  }
  buf[len] = 0;
  return buf;
}

static f64 porf_digits_radix(const char* q, i32 radix, const char** end) {
  f64 n = 0;
  for (;; q++) {
    const i32 v = *q >= '0' && *q <= '9' ? *q - '0' : (*q | 32) >= 'a' && (*q | 32) <= 'z' ? (*q | 32) - 'a' + 10 : 36;
    if (v >= radix) break;
    n = n * radix + v;
  }
  *end = q;
  return n;
}

${st}f64 porf_str_to_num(jsval s, i32 strict) {
  char small[256];
  char* buf = porf_str_cstr(s, small, sizeof small);
  const char* q = buf + (buf[0] == '+' || buf[0] == '-');
  const char* end = q;
  f64 n = NAN;

  // strtod also takes hex floats, inf and nan
  if (q[0] == '0' && ((q[1] | 32) == 'x' || (q[1] | 32) == 'o' || (q[1] | 32) == 'b')) {
    const i32 radix = (q[1] | 32) == 'x' ? 16 : (q[1] | 32) == 'o' ? 8 : 2;
    if (strict) {
      if (q == buf && q[2]) n = porf_digits_radix(q + 2, radix, &end);
    } else {
      n = buf[0] == '-' ? -0.0 : 0;
      end = q + 1;
    }
  } else if ((q[0] | 32) == 'i' || (q[0] | 32) == 'n') {
    if (strncmp(q, "Infinity", 8) == 0) {
      n = buf[0] == '-' ? -INFINITY : INFINITY;
      end = q + 8;
    }
  } else n = strtod(buf, (char**)&end);

  // the string may hold nul, only its real end counts
  if (end <= q || (strict && end != buf + *(u32*)(MEM + (u32)s.val))) n = NAN;
  if (buf != small) free(buf);
  return n;
}

${st}f64 porf_parse_int(jsval s, i32 radix) {
  char small[256];
  char* buf = porf_str_cstr(s, small, sizeof small);
  char* q = buf + (buf[0] == '+' || buf[0] == '-');
  f64 n = NAN;
  if (radix == 0 || radix == 16) {
    if (q[0] == '0' && (q[1] | 32) == 'x') {
      q += 2;
      radix = 16;
    }
  }
  if (radix == 0) radix = 10;

  if (radix >= 2 && radix <= 36) {
    const char* end;
    n = porf_digits_radix(q, radix, &end);
    if (end == q) n = NAN;
    else if (radix == 10) {
      const char c = *end;
      *(char*)end = 0;
      n = strtod(q, NULL);
      *(char*)end = c;
    }
    if (buf[0] == '-') n = -n;
  }
  if (buf != small) free(buf);
  return n;
}

// ToString for + and template literals
${st}jsval porf_to_str(jsval v);
${sti}jsval porf_str_concat(jsval a, jsval b);
${st}jsval porf_to_str(jsval v) {
  if (porf_jv_is_num(v)) return porf_num_to_str(v.val);
  const i32 t = v.type;
  if (t == ${TYPES.bytestring} || t == ${TYPES.string}) return v;
  if (t == ${TYPES.array}) {
    // join(',')
    const u32 a = (u32)v.val;
    const i32 n = PORF_ARR_LEN(a);
    jsval acc = porf_box((f64)porf_bstr_new(0), ${TYPES.bytestring});
    for (i32 i = 0; i < n; i++) {
      if (i) {
        const u32 c = porf_bstr_new(1); MEM[c + 4] = 44;
        acc = porf_str_concat(acc, porf_box((f64)c, ${TYPES.bytestring}));
      }
      const jsval e = porf_arr_get(a, (u32)i);
      const i32 et = porf_jv_type(e);
      if (et != ${TYPES.undefined} && !(et == ${TYPES.object} && (u32)e.val == 0))
        acc = porf_str_concat(acc, porf_to_str(e));
    }
    return acc;
  }
  const char* lit =
    t == ${TYPES.undefined} ? "undefined" :
    t == ${TYPES.boolean} ? ((u32)v.val ? "true" : "false") :
    t == ${TYPES.object} && (u32)v.val == 0 ? "null" :
    t == ${TYPES.function} ? "function" : "[object Object]";
  const u32 len = (u32)strlen(lit);
  const u32 s = porf_bstr_new(len);
  memcpy(MEM + s + 4, lit, len);
  return porf_box((f64)s, ${TYPES.bytestring});
}

// template literals: primitives become strings, then one allocation for the whole result
${st}jsval porf_str_join(i32 n, jsval* parts) {
  u32 len = 0;
  int wide = 0;
  for (i32 i = 0; i < n; i++) {
    if (parts[i].type != ${TYPES.bytestring} && parts[i].type != ${TYPES.string}) parts[i] = porf_to_str(parts[i]);
    len += *(u32*)(MEM + (u32)parts[i].val);
    wide |= parts[i].type == ${TYPES.string};
  }
  if (!wide) {
    const u32 s = porf_bstr_new(len);
    u8* out = MEM + s + 4;
    for (i32 i = 0; i < n; i++) {
      const u32 p = (u32)parts[i].val, l = *(u32*)(MEM + p);
      memcpy(out, MEM + p + 4, l);
      out += l;
    }
    return porf_box((f64)s, ${TYPES.bytestring});
  }
  const u32 s = porf_alloc(4 + len * 2, ${TYPES.string});
  *(u32*)(MEM + s) = len;
  u16* out = (u16*)(MEM + s + 4);
  for (i32 i = 0; i < n; i++) {
    const u32 p = (u32)parts[i].val, l = *(u32*)(MEM + p);
    if (parts[i].type == ${TYPES.bytestring}) for (u32 k = 0; k < l; k++) out[k] = MEM[p + 4 + k];
      else memcpy(out, MEM + p + 4, (size_t)l * 2);
    out += l;
  }
  return porf_box((f64)s, ${TYPES.string});
}

// basic ToNumber (string parsing arrives with builtins port)
${sti}f64 porf_to_num(jsval v) {
  if (porf_jv_is_num(v)) return v.val;
  const i32 t = v.type;
  if (t == ${TYPES.boolean}) return (f64)(u32)v.val;
  if (t == ${TYPES.object} && (u32)v.val == 0) return 0.0; // null
  return porf_bits_to_f64(0x7FF8000000000000ull); // NaN
}

static inline int porf_bigint_is_heap(jsval v) {
  return v.type == ${TYPES.bigint} && v.val >= 2251799813685248.0;
}

static inline u32 porf_bigint_ptr(jsval v) {
  return (u32)(v.val - 2251799813685248.0);
}

static inline int porf_bigint_is_negative(jsval v) {
  return porf_bigint_is_heap(v) ? *(u8*)(MEM + porf_bigint_ptr(v)) != 0 : v.val < 0;
}

static u32 porf_bigint_trimmed_len(u32 p) {
  const u32 len = *(u16*)(MEM + p + 2);
  u32 i = 0;
  while (i < len && *(u32*)(MEM + p + 4 + (i << 2)) == 0) i++;
  return len - i;
}

static i32 porf_bigint_cmp_abs(jsval a, jsval b) {
  const int ah = porf_bigint_is_heap(a), bh = porf_bigint_is_heap(b);
  if (!ah && !bh) {
    const f64 av = a.val < 0 ? -a.val : a.val;
    const f64 bv = b.val < 0 ? -b.val : b.val;
    return av < bv ? -1 : av > bv ? 1 : 0;
  }
  if (ah != bh) {
    // heap vs inline: heap bigints can hold small values too (see porf_pack)
    const u32 hp = porf_bigint_ptr(ah ? a : b);
    const u32 hlen = porf_bigint_trimmed_len(hp);
    i32 c = 1;
    if (hlen <= 2) {
      const u32 hstart = *(u16*)(MEM + hp + 2) - hlen;
      u64 hv = 0;
      for (u32 i = 0; i < hlen; i++) hv = (hv << 32) | *(u32*)(MEM + hp + 4 + ((hstart + i) << 2));
      const f64 iv = ah ? b.val : a.val;
      const u64 im = (u64)(iv < 0 ? -iv : iv);
      c = hv < im ? -1 : hv > im ? 1 : 0;
    }
    return ah ? c : -c;
  }

  const u32 ap = porf_bigint_ptr(a), bp = porf_bigint_ptr(b);
  const u32 alen = porf_bigint_trimmed_len(ap), blen = porf_bigint_trimmed_len(bp);
  if (alen != blen) return alen < blen ? -1 : 1;

  const u32 astart = *(u16*)(MEM + ap + 2) - alen;
  const u32 bstart = *(u16*)(MEM + bp + 2) - blen;
  for (u32 i = 0; i < alen; i++) {
    const u32 av = *(u32*)(MEM + ap + 4 + ((astart + i) << 2));
    const u32 bv = *(u32*)(MEM + bp + 4 + ((bstart + i) << 2));
    if (av != bv) return av < bv ? -1 : 1;
  }
  return 0;
}

static u32 porf_bigint_heapify(f64 d) {
  const int neg = d < 0;
  f64 a = neg ? -d : d;
  u32 digits[40];
  u32 n = 0;
  while (a >= 1.0 && n < 40) {
    const f64 q = floor(a / 4294967296.0);
    digits[n++] = (u32)(a - q * 4294967296.0);
    a = q;
  }
  if (n == 0) digits[n++] = 0;
  const u32 ptr = porf_alloc((4 + n * 4 + 7) & ~7u, ${TYPES.bigint});
  *(u8*)(MEM + ptr) = (u8)neg;
  *(u16*)(MEM + ptr + 2) = (u16)n;
  for (u32 i = 0; i < n; i++) *(u32*)(MEM + ptr + 4 + (i << 2)) = digits[n - 1 - i];
  return ptr;
}

// bigints not fitting the 32-bit payload are packed as a heap pointer, flagged by bit 42
static jsbits porf_pack_bigint(f64 d) {
  const u32 ptr = d >= 2251799813685248.0 && d < 2251804108652544.0 ? (u32)(d - 2251799813685248.0) : porf_bigint_heapify(d);
  return JV_PATTERN | ((u64)${TYPES.bigint} << 43) | (1ull << 42) | (u64)ptr;
}

static PORF_NOINLINE i32 porf_bigint_cmp(jsval a, jsval b) {
  const int an = porf_bigint_is_negative(a), bn = porf_bigint_is_negative(b);
  if (an != bn) return an ? -1 : 1;
  const i32 c = porf_bigint_cmp_abs(a, b);
  return an ? -c : c;
}

${sti}int porf_is_strlike(jsval v) {
  if (porf_jv_is_num(v)) return 0;
  const i32 t = v.type;
  return t == ${TYPES.bytestring} || t == ${TYPES.string} ||
    t == ${TYPES.object} && (u32)v.val != 0 || t == ${TYPES.array} || t == ${TYPES.function};
}

// JS + : string-ish on either side concats; else numeric coercion
${sti}jsval porf_add(jsval a, jsval b) {
  if (porf_jv_is_num(a) && porf_jv_is_num(b))
    return porf_box_num(a.val + b.val);
  if (porf_is_strlike(a) || porf_is_strlike(b)) {
    jsval sa = porf_to_str(a);
    volatile u32 keep_sa = porf_gc_type_can_reference(sa.type) ? (u32)sa.val : 0u;
    jsval sb = porf_to_str(b);
    (void)keep_sa;
    return porf_str_concat(sa, sb);
  }
  return porf_box_num(porf_to_num(a) + porf_to_num(b));
}

// numeric -, *, / on two unknown-typed operands: a single combined both-number fast-path (one
// hoistable/unswitchable condition) rather than two independent porf_to_num branches.
${sti}jsval porf_sub(jsval a, jsval b) {
  if (porf_jv_is_num(a) && porf_jv_is_num(b)) return porf_box_num(a.val - b.val);
  return porf_box_num(porf_to_num(a) - porf_to_num(b));
}
${sti}jsval porf_mul(jsval a, jsval b) {
  if (porf_jv_is_num(a) && porf_jv_is_num(b)) return porf_box_num(a.val * b.val);
  return porf_box_num(porf_to_num(a) * porf_to_num(b));
}
${sti}jsval porf_div(jsval a, jsval b) {
  if (porf_jv_is_num(a) && porf_jv_is_num(b)) return porf_box_num(a.val / b.val);
  return porf_box_num(porf_to_num(a) / porf_to_num(b));
}

// JS abstract relational comparison: -1/0/1, 2 = unordered (NaN involved).
// 3 = needs ToPrimitive/StringToNumber/BigInt mixing: codegen falls back to __Porffor_compare
static inline int porf_cmp_numish(jsval v) {
  const i32 t = porf_jv_type(v);
  return t == ${TYPES.number} || t == ${TYPES.boolean} || t == ${TYPES.undefined} || (t == ${TYPES.object} && (u32)v.val == 0);
}

${sti}i32 porf_cmp(jsval a, jsval b) {
  const i32 ta = porf_jv_type(a), tb = porf_jv_type(b);
${bigints ? `  if (ta == ${TYPES.bigint} && tb == ${TYPES.bigint}) return porf_bigint_cmp(a, b);
` : ''}  if ((ta == ${TYPES.bytestring} || ta == ${TYPES.string}) && (tb == ${TYPES.bytestring} || tb == ${TYPES.string})) {
    const u32 pa = (u32)a.val, pb = (u32)b.val;
    const u32 la = *(u32*)(MEM + pa), lb = *(u32*)(MEM + pb);
    const u32 n = la < lb ? la : lb;
    if (ta == ${TYPES.bytestring} && tb == ${TYPES.bytestring}) {
      const int c = memcmp(MEM + pa + 4, MEM + pb + 4, n);
      if (c != 0) return c < 0 ? -1 : 1;
    } else {
      for (u32 i = 0; i < n; i++) {
        const u32 ca = ta == ${TYPES.string} ? (u32)MEM[pa + 4 + i * 2] | (u32)MEM[pa + 5 + i * 2] << 8 : MEM[pa + 4 + i];
        const u32 cb = tb == ${TYPES.string} ? (u32)MEM[pb + 4 + i * 2] | (u32)MEM[pb + 5 + i * 2] << 8 : MEM[pb + 4 + i];
        if (ca != cb) return ca < cb ? -1 : 1;
      }
    }
    return la == lb ? 0 : la < lb ? -1 : 1;
  }
  if (!porf_cmp_numish(a) || !porf_cmp_numish(b)) return 3;
  const f64 x = porf_to_num(a), y = porf_to_num(b);
  if (x != x || y != y) return 2;
  return x < y ? -1 : x > y ? 1 : 0;
}

// loose ==: 0/1, or 2 when coercion is needed: codegen falls back to __Porffor_looseEq
static inline int porf_is_prim_type(i32 t) {
  return t == ${TYPES.undefined} || t == ${TYPES.number} || t == ${TYPES.boolean} || t == ${TYPES.string} ||
    t == ${TYPES.bytestring} || t == ${TYPES.bigint} || t == ${TYPES.symbol};
}

${sti}i32 porf_loose_eq(jsval a, jsval b) {
  const i32 ta = porf_jv_type(a), tb = porf_jv_type(b);
  if (ta == ${TYPES.number} && tb == ${TYPES.number}) return a.val == b.val;
  const int an = ta == ${TYPES.undefined} || (ta == ${TYPES.object} && (u32)a.val == 0);
  const int bn = tb == ${TYPES.undefined} || (tb == ${TYPES.object} && (u32)b.val == 0);
  if (an || bn) return an && bn;
  const int sa = ta == ${TYPES.bytestring} || ta == ${TYPES.string}, sb = tb == ${TYPES.bytestring} || tb == ${TYPES.string};
  if (sa && sb) return porf_str_eq(a, b);
  if (ta == ${TYPES.boolean}) return porf_loose_eq(porf_box_num((f64)(u32)a.val), b);
  if (tb == ${TYPES.boolean}) return porf_loose_eq(a, porf_box_num((f64)(u32)b.val));
${bigints ? `  if (ta == ${TYPES.bigint} && tb == ${TYPES.bigint}) return porf_bigint_cmp(a, b) == 0;
` : ''}  const int pa = porf_is_prim_type(ta), pb = porf_is_prim_type(tb);
  if (!pa && !pb) return porf_jv_eq(a, b);
  if (pa && pb) {
    // string/number and BigInt/string|number coerce, symbols only equal themselves
    if (ta == ${TYPES.symbol} || tb == ${TYPES.symbol}) return porf_jv_eq(a, b);
    if (ta == tb) return porf_jv_eq(a, b);
  }
  return 2;
}

// == inside builtins: pointer/zero checks (x == 0) must not coerce, strings only equal 0 when empty
${sti}i32 porf_loose_eq_raw(jsval a, jsval b) {
  const i32 r = porf_loose_eq(a, b);
  if (r != 2) return r;
  if (porf_jv_type(a) == ${TYPES.boolean}) a = porf_box_num((f64)(u32)a.val);
  if (porf_jv_type(b) == ${TYPES.boolean}) b = porf_box_num((f64)(u32)b.val);
  const i32 ta = porf_jv_type(a), tb = porf_jv_type(b);
  if ((ta == ${TYPES.bytestring} || ta == ${TYPES.string}) && tb == ${TYPES.number})
    return b.val == 0.0 && ((u32)a.val == 0u || *(u32*)(MEM + (u32)a.val) == 0u);
  if (ta == ${TYPES.number} && (tb == ${TYPES.bytestring} || tb == ${TYPES.string}))
    return a.val == 0.0 && ((u32)b.val == 0u || *(u32*)(MEM + (u32)b.val) == 0u);
  return 0;
}

// === : numbers as f64, strings by content, else identity
${sti}i32 porf_strict_eq(jsval a, jsval b) {
  if (porf_jv_is_num(a)) return porf_jv_is_num(b) && a.val == b.val;
  const i32 ta = porf_jv_type(a), tb = porf_jv_type(b);
  if ((ta == ${TYPES.bytestring} || ta == ${TYPES.string}) && (tb == ${TYPES.bytestring} || tb == ${TYPES.string})) return porf_str_eq(a, b);
  if (ta != tb) return 0;
${bigints ? `  if (ta == ${TYPES.bigint}) return porf_bigint_cmp(a, b) == 0;
` : ''}  return (u32)a.val == (u32)b.val;
}

static int porf_argc;
static char** porf_argv;
static void porf_init(int argc, char** argv) {
  porf_argc = argc;
  porf_argv = argv;
  porf_arena_init();
}

`;
};

const PROMISE_DIRECT_RUNTIME = () => `static jsval porf_promise_pending(void) {
  const u32 p = porf_alloc(PORF_PROMISE_SIZE, ${TYPES.promise});
  *(jsbits*)(MEM + p + PORF_PROMISE_RESULT) = JV_UNDEFINED_BITS;
  *(u32*)(MEM + p + PORF_PROMISE_FULFILL_HEAD) = 0;
  *(u32*)(MEM + p + PORF_PROMISE_FULFILL_TAIL) = 0;
  *(u32*)(MEM + p + PORF_PROMISE_REJECT_HEAD) = 0;
  *(u32*)(MEM + p + PORF_PROMISE_REJECT_TAIL) = 0;
  *(jsbits*)(MEM + p + PORF_PROMISE_PAYLOAD) = JV_UNDEFINED_BITS;
  *(u8*)(MEM + p + PORF_PROMISE_STATE) = 0;
  *(u8*)(MEM + p + PORF_PROMISE_FLAGS) = 0;
  *(u8*)(MEM + p + PORF_PROMISE_HANDLED) = 0;
  return porf_box((f64)p, ${TYPES.promise});
}

static void porf_promise_trigger_reactions(u32 reaction, jsval value) {
  while (reaction != 0) {
    const u32 next = *(u32*)(MEM + reaction + PORF_REACTION_NEXT);
    *(u32*)(MEM + reaction + PORF_REACTION_NEXT) = 0;
    *(jsbits*)(MEM + reaction + PORF_REACTION_VALUE) = porf_pack(value);
    porf_gc_barrier(reaction, PORF_GC_KIND_PROMISE_REACTION);
    porf_promise_enqueue_job(reaction);
    reaction = next;
  }
}

static void porf_promise_settle_direct(jsval promise, jsval value, i32 state) {
  if (promise.type != ${TYPES.promise}) return;
  const u32 p = (u32)promise.val;
  if (*(u8*)(MEM + p + PORF_PROMISE_STATE) != 0) return;
  const u32 reactions = *(u32*)(MEM + p + (state == 1 ? PORF_PROMISE_FULFILL_HEAD : PORF_PROMISE_REJECT_HEAD));
  *(jsbits*)(MEM + p + PORF_PROMISE_RESULT) = porf_pack(value);
  *(u32*)(MEM + p + PORF_PROMISE_FULFILL_HEAD) = 0;
  *(u32*)(MEM + p + PORF_PROMISE_FULFILL_TAIL) = 0;
  *(u32*)(MEM + p + PORF_PROMISE_REJECT_HEAD) = 0;
  *(u32*)(MEM + p + PORF_PROMISE_REJECT_TAIL) = 0;
  *(u8*)(MEM + p + PORF_PROMISE_STATE) = (u8)state;
  porf_gc_barrier(p, ${TYPES.promise});
  porf_promise_trigger_reactions(reactions, value);
}
`;

const CORO_RUNTIME = () => `// record: header, frame, args. a generator is its record
typedef struct porf_coro_call {
  jsval callee;
  jsval thisv;
  jsval newtv;
  jsval result;
  jsval channel;          // value (or thrown exception) crossing the boundary
  jsval iter_open;        // porf_iter_open inside it
  jsval caller_iter_open;
  struct porf_coro_call* parent;
  u32 heap;               // block offset in the GC heap, 0 while on the C stack
  u32 idx;
  u32 env;
  u32 frame_size;
  i32 argc;
  i32 state;              // 0 idle, 1 running, 2 suspended, 3 done
  i32 resume;             // suspend point to re-enter at, 0 = start
  i32 throw_pending;      // resume delivers channel as a throw at the suspend point
  i32 raw;                // channel is an iterator result to pass through as-is
  i32 awaiting;           // suspended at an await (channel is its promise), not a yield
  i32 caller_iter_base;
} porf_coro_call;
#define PORF_CORO_HDR ((u32)((sizeof(porf_coro_call) + 7u) & ~7u))
#define PORF_CORO_BYTES(frame, argc) (PORF_CORO_HDR + (frame) + (u32)(argc) * 8u)

static porf_coro_call* porf_coro_cur = 0;
#define PORF_CORO_RETURN porf_box(0.0, ${TYPES.__porffor_generator})
static i32 porf_coro_mode = 0;
static jsval porf_coro_dispatch(porf_coro_call* call);
static u32 porf_coro_frame_bytes(u32 idx);
#ifndef PORF_GC_KIND_CORO
#define PORF_GC_KIND_CORO 247u
#endif

static inline void* porf_coro_frame(porf_coro_call* c) { return (u8*)c + PORF_CORO_HDR; }
static inline jsbits* porf_coro_argv(porf_coro_call* c) { return (jsbits*)((u8*)c + PORF_CORO_HDR + c->frame_size); }
static inline void porf_coro_touch(porf_coro_call* c) { if (c->heap) porf_gc_barrier(c->heap, 0); }

static u32 porf_promise_new_coro_reaction(porf_coro_call* call, jsval out_promise, i32 is_throw) {
  const u32 reaction = porf_alloc(PORF_REACTION_SIZE, 0);
  *(u64*)(MEM + reaction + PORF_REACTION_HANDLER) = (u64)call->heap;
  *(jsbits*)(MEM + reaction + PORF_REACTION_OUT_PROMISE) = porf_pack(out_promise);
  *(jsbits*)(MEM + reaction + PORF_REACTION_VALUE) = JV_UNDEFINED_BITS;
  *(u32*)(MEM + reaction + PORF_REACTION_NEXT) = 0;
  *(u32*)(MEM + reaction + PORF_REACTION_PAYLOAD) = (u32)is_throw;
  *(u8*)(MEM + reaction + PORF_REACTION_KIND) = 11;
  *(u8*)(MEM + reaction + PORF_REACTION_FLAGS) = 0;
  *(jsbits*)(MEM + reaction + PORF_REACTION_CONTEXT) = porf_async_context;
  *(u32*)(MEM + reaction + PORF_REACTION_CPU) = porf_cpu_cur;
  porf_gc_barrier(reaction, PORF_GC_KIND_PROMISE_REACTION);
  return reaction;
}

static void porf_promise_append_raw_reaction(u32 promise, u32 reaction, i32 reject) {
  const u32 head_off = reject ? PORF_PROMISE_REJECT_HEAD : PORF_PROMISE_FULFILL_HEAD;
  const u32 tail_off = reject ? PORF_PROMISE_REJECT_TAIL : PORF_PROMISE_FULFILL_TAIL;
  const u32 tail = *(u32*)(MEM + promise + tail_off);
  if (tail == 0) {
    *(u32*)(MEM + promise + head_off) = reaction;
  } else {
    *(u32*)(MEM + tail + PORF_REACTION_NEXT) = reaction;
    porf_gc_barrier(tail, PORF_GC_KIND_PROMISE_REACTION);
  }
  *(u32*)(MEM + promise + tail_off) = reaction;
  porf_gc_barrier(promise, ${TYPES.promise});
}

static void porf_promise_attach_coro(jsval awaited, porf_coro_call* call, jsval out_promise) {
  if (awaited.type != ${TYPES.promise}) porf_unreachable("coroutine awaited non-promise");
  const u32 p = (u32)awaited.val;
  *(u8*)(MEM + p + PORF_PROMISE_HANDLED) = 1;
  const u8 state = *(u8*)(MEM + p + PORF_PROMISE_STATE);
  if (state != 0) {
    // already settled: resume in a job, like then on a settled promise
    const u32 reaction = porf_promise_new_coro_reaction(call, out_promise, state == 2);
    *(jsbits*)(MEM + reaction + PORF_REACTION_VALUE) = *(jsbits*)(MEM + p + PORF_PROMISE_RESULT);
    porf_gc_barrier(reaction, PORF_GC_KIND_PROMISE_REACTION);
    porf_promise_enqueue_job(reaction);
    return;
  }
  porf_promise_append_raw_reaction(p, porf_promise_new_coro_reaction(call, out_promise, 0), 0);
  porf_promise_append_raw_reaction(p, porf_promise_new_coro_reaction(call, out_promise, 1), 1);
}

static void porf_coro_init(porf_coro_call* c, u32 heap, u32 frame, u32 idx, jsval callee, u32 env, jsval thisv, jsval newtv, i32 argc, jsbits* argv) {
  c->callee = callee;
  c->thisv = thisv;
  c->newtv = newtv;
  c->result = JV_UNDEFINED;
  c->channel = JV_UNDEFINED;
  c->parent = 0;
  c->heap = heap;
  c->idx = idx;
  c->env = env;
  c->frame_size = frame;
  c->argc = argc;
  c->state = 0;
  c->resume = 0;
  c->throw_pending = 0;
  c->raw = 0;
  c->awaiting = 0;
  c->iter_open = JV_UNDEFINED;
  c->caller_iter_open = JV_UNDEFINED;
  jsbits* a = porf_coro_argv(c);
  for (i32 i = 0; i < argc; i++) a[i] = argv[i];
}

static porf_coro_call* porf_coro_alloc(u32 kind, u32 frame, i32 argc) {
  const u32 p = porf_alloc(PORF_CORO_BYTES(frame, argc), kind);
#if PORF_GC_ENABLED
  porf_gc_set_kind((i32)p, kind);
#endif
  porf_coro_call* c = (porf_coro_call*)(MEM + p);
  c->heap = p;
  return c;
}

static void porf_coro_finish(porf_coro_call* c) {
  c->state = 3;
  c->resume = 0;
}

// yield* gets throw/return as values, porf_yield_mode says which
static inline jsval porf_coro_received(porf_coro_call* c, i32 delegate) {
  c->resume = 0;
  if (c->throw_pending) {
    c->throw_pending = 0;
    if (!delegate) porf_throw(c->channel);
    porf_coro_mode = porf_jv_eq(c->channel, PORF_CORO_RETURN) ? 2 : 1;
    return porf_coro_mode == 2 ? c->result : c->channel;
  }
  porf_coro_mode = 0;
  return c->channel;
}

#if PORF_GC_ENABLED
static void porf_coro_gc_scan(porf_coro_call* call) {
  porf_gc_mark_js(call->callee.val, call->callee.type);
  porf_gc_mark_js(call->thisv.val, call->thisv.type);
  porf_gc_mark_js(call->newtv.val, call->newtv.type);
  porf_gc_mark_js(call->result.val, call->result.type);
  porf_gc_mark_js(call->channel.val, call->channel.type);
  porf_gc_mark_js(call->iter_open.val, call->iter_open.type);
  if (call->state == 1) porf_gc_mark_js(call->caller_iter_open.val, call->caller_iter_open.type);
  const jsbits* argv = porf_coro_argv(call);
  for (i32 i = 0; i < call->argc; i++) porf_gc_mark_jsbits(argv[i]);
  if (call->state == 2) {
    const u8* frame = (const u8*)porf_coro_frame(call);
    porf_gc_cons_scan_range((const u64*)frame, (const u64*)(frame + call->frame_size));
  }
}
#endif

static void porf_coro_restore_caller(porf_coro_call* c) {
  porf_coro_cur = c->parent;
  c->iter_open = porf_iter_open;
  porf_iter_open = c->caller_iter_open;
  porf_iter_base = c->caller_iter_base;
  porf_coro_touch(c);
}

static i32 porf_coro_run(porf_coro_call* c) {
  c->state = 1;
  c->parent = porf_coro_cur;
  porf_coro_cur = c;
  c->caller_iter_open = porf_iter_open;
  c->caller_iter_base = porf_iter_base;
  porf_coro_touch(c);
  porf_iter_open = c->iter_open;
  porf_iter_base = porf_try_depth;
  const jsval r = porf_coro_dispatch(c);
  if (c->resume == 0) c->result = r;
  porf_coro_restore_caller(c);
  c->state = c->resume != 0 ? 2 : 3;
  return c->state == 3;
}

static i32 porf_coro_call_step(porf_coro_call* call, jsval value, i32 is_throw) {
  if (call->state == 0) return porf_coro_run(call);
  if (call->state != 2) porf_unreachable("resume of non-suspended coroutine");
  call->channel = value;
  call->raw = 0;
  call->awaiting = 0;
  call->throw_pending = is_throw;
  porf_coro_touch(call);
  return porf_coro_run(call);
}

static void porf_coro_abort(porf_coro_call* call) {
  porf_coro_restore_caller(call);
  porf_coro_finish(call);
}

static porf_coro_call* porf_coro_promote(porf_coro_call* c) {
  if (c->heap) return c;
  porf_coro_call* h = porf_coro_alloc(PORF_GC_KIND_CORO, c->frame_size, 0);
  const u32 heap = h->heap;
  memcpy(h, c, PORF_CORO_HDR + c->frame_size);
  h->heap = heap;
  h->argc = 0;
  h->parent = 0;
  return h;
}

static i32 porf_yield_mode(void) {
  return porf_coro_mode;
}

`;
