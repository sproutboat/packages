import type {} from './porffor.d.ts';

export const __Porffor_strcmp = (a: any, b: any): boolean => {
  // a and b must be string or bytestring
  // fast path: check if pointers are equal
  if (Porffor.IR.ptr(a) == Porffor.IR.ptr(b)) return true;

  const al: i32 = Porffor.IR.loadI32(a, 0);
  const bl: i32 = Porffor.IR.loadI32(b, 0);

  // fast path: check if lengths are inequal
  if (al != bl) return false;

  const aBytes: boolean = Porffor.type(a) == Porffor.TYPES.bytestring;
  const bBytes: boolean = Porffor.type(b) == Porffor.TYPES.bytestring;
  for (let i: i32 = 0; i < al; i++) {
    const ac: i32 = aBytes ? Porffor.IR.loadU8(Porffor.IR.ptr(a) + i, 4) : Porffor.IR.loadU16(Porffor.IR.ptr(a) + i * 2, 4);
    const bc: i32 = bBytes ? Porffor.IR.loadU8(Porffor.IR.ptr(b) + i, 4) : Porffor.IR.loadU16(Porffor.IR.ptr(b) + i * 2, 4);
    if (ac != bc) return false;
  }

  return true;
};

export const __Porffor_strcat = (a: any, b: any): any => {
  // a and b must be string or bytestring

  const al: i32 = Porffor.IR.loadI32(a, 0);
  const bl: i32 = Porffor.IR.loadI32(b, 0);
  const aPtr: i32 = Porffor.IR.ptr(a);
  const bPtr: i32 = Porffor.IR.ptr(b);

  if (Porffor.type(a) == Porffor.TYPES.bytestring) {
    if (Porffor.type(b) == Porffor.TYPES.bytestring) {
      // bytestring, bytestring
      const out: bytestring = Porffor.malloc(6 + al + bl);

      Porffor.IR.storeI32(out, 0, al + bl);

      // copy left (fast memcpy)
      Porffor.IR.copy(Porffor.IR.ptr(out) + 4, aPtr + 4, al);

      // copy right (fast memcpy)
      Porffor.IR.copy(Porffor.IR.ptr(out) + 4 + al, bPtr + 4, bl);

      return out;
    } else {
      // bytestring, string
      const out: string = Porffor.malloc(6 + (al + bl) * 2);

      Porffor.IR.storeI32(out, 0, al + bl);

      // copy left (slow bytestring -> string)
      for (let i: i32 = 0; i < al; i++) {
        Porffor.IR.storeU16(Porffor.IR.ptr(out) + i*2, 4, Porffor.IR.loadU8(aPtr + i, 4));
      }

      // copy right (fast memcpy)
      Porffor.IR.copy(Porffor.IR.ptr(out) + 4 + al*2, bPtr + 4, bl * 2);

      return out;
    }
  } else {
    if (Porffor.type(b) == Porffor.TYPES.bytestring) {
      // string, bytestring
      const out: string = Porffor.malloc(6 + (al + bl) * 2);

      Porffor.IR.storeI32(out, 0, al + bl);

      // copy left (fast memcpy)
      Porffor.IR.copy(Porffor.IR.ptr(out) + 4, aPtr + 4, al * 2);

      // copy right (slow bytestring -> string)
      let ptr: i32 = Porffor.IR.ptr(out) + al*2;
      for (let i: i32 = 0; i < bl; i++) {
        Porffor.IR.storeU16(ptr + i*2, 4, Porffor.IR.loadU8(bPtr + i, 4));
      }

      return out;
    } else {
      // string, string
      const out: string = Porffor.malloc(6 + (al + bl) * 2);

      Porffor.IR.storeI32(out, 0, al + bl);

      // copy left (fast memcpy)
      Porffor.IR.copy(Porffor.IR.ptr(out) + 4, aPtr + 4, al * 2);

      // copy right (fast memcpy)
      Porffor.IR.copy(Porffor.IR.ptr(out) + 4 + al*2, bPtr + 4, bl * 2);

      return out;
    }
  }
};


export const __String_prototype_at = function (this: string, _index: any) {
  const len: i32 = this.length;
  let index: number = ecma262.ToIntegerOrInfinity(_index);

  if (index < 0) index = len + index;
  if (Porffor.fastOr(index < 0, index >= len)) return undefined;

  const out: string = Porffor.malloc(8);
  Porffor.IR.storeI32(out, 0, 1); // out.length = 1

  Porffor.IR.storeU16(Porffor.IR.ptr(out), 4, Porffor.IR.loadU16(Porffor.IR.ptr(this) + index * 2, 4));
  return out;
};

export const __ByteString_prototype_at = function (this: bytestring, _index: any) {
  const len: i32 = this.length;
  let index: number = ecma262.ToIntegerOrInfinity(_index);

  if (index < 0) index = len + index;
  if (Porffor.fastOr(index < 0, index >= len)) return undefined;

  return __Porffor_bytestring_char(Porffor.IR.loadU8(Porffor.IR.ptr(this) + index, 4));
};

export const __String_prototype_charAt = function (this: string, _index: any) {
  const len: i32 = this.length;
  const index: number = ecma262.ToIntegerOrInfinity(_index);

  if (Porffor.fastOr(index < 0, index >= len)) return '';

  const out: string = Porffor.malloc(8);
  Porffor.IR.storeI32(out, 0, 1); // out.length = 1

  Porffor.IR.storeU16(Porffor.IR.ptr(out), 4, Porffor.IR.loadU16(Porffor.IR.ptr(this) + index * 2, 4));
  return out;
};

export const __ByteString_prototype_charAt = function (this: bytestring, _index: any) {
  const len: i32 = this.length;
  const index: number = ecma262.ToIntegerOrInfinity(_index);

  if (Porffor.fastOr(index < 0, index >= len)) return '';

  return __Porffor_bytestring_char(Porffor.IR.loadU8(Porffor.IR.ptr(this) + index, 4));
};

// str[index], out of range or non-integer indices are property lookups
export const __Porffor_string_get = (str: any, index: number): any => {
  if (Porffor.fastOr(index < 0, index >= str.length, Math.trunc(index) != index)) return __Porffor_object_get(str, index);

  if (Porffor.type(str) == Porffor.TYPES.bytestring) return __Porffor_bytestring_char(Porffor.IR.loadU8(Porffor.IR.ptr(str) + index, 4));

  const out: string = Porffor.malloc(8);
  Porffor.IR.storeI32(out, 0, 1);
  Porffor.IR.storeU16(Porffor.IR.ptr(out), 4, Porffor.IR.loadU16(Porffor.IR.ptr(str) + index * 2, 4));
  return out;
};

// sproutboat: Unicode case mapping
export const __Porffor_caseFind = (chr: i32, runs: string): i32 => {
  let lo: i32 = 0, hi: i32 = runs.length / 4 - 1, found: i32 = -1;
  while (lo <= hi) {
    const mid: i32 = (lo + hi) >> 1;
    if (runs.charCodeAt(mid * 4) <= chr) { found = mid; lo = mid + 1; } else hi = mid - 1;
  }
  if (found < 0) return chr;
  const start: i32 = runs.charCodeAt(found * 4);
  if (chr > runs.charCodeAt(found * 4 + 1)) return chr;
  if ((chr - start) % runs.charCodeAt(found * 4 + 3) != 0) return chr;
  return runs.charCodeAt(found * 4 + 2) + (chr - start);
};
export const __Porffor_caseLower = (chr: i32): i32 => __Porffor_caseFind(chr, '\u00c0\u00d6\u00e0\u0001\u00d8\u00de\u00f8\u0001\u0100\u012e\u0101\u0002\u0132\u0136\u0133\u0002\u0139\u0147\u013a\u0002\u014a\u0176\u014b\u0002\u0178\u0178\u00ff\u0001\u0179\u017d\u017a\u0002\u0181\u0181\u0253\u0001\u0182\u0184\u0183\u0002\u0186\u0186\u0254\u0001\u0187\u0187\u0188\u0001\u0189\u018a\u0256\u0001\u018b\u018b\u018c\u0001\u018e\u018e\u01dd\u0001\u018f\u018f\u0259\u0001\u0190\u0190\u025b\u0001\u0191\u0191\u0192\u0001\u0193\u0193\u0260\u0001\u0194\u0194\u0263\u0001\u0196\u0196\u0269\u0001\u0197\u0197\u0268\u0001\u0198\u0198\u0199\u0001\u019c\u019c\u026f\u0001\u019d\u019d\u0272\u0001\u019f\u019f\u0275\u0001\u01a0\u01a4\u01a1\u0002\u01a6\u01a6\u0280\u0001\u01a7\u01a7\u01a8\u0001\u01a9\u01a9\u0283\u0001\u01ac\u01ac\u01ad\u0001\u01ae\u01ae\u0288\u0001\u01af\u01af\u01b0\u0001\u01b1\u01b2\u028a\u0001\u01b3\u01b5\u01b4\u0002\u01b7\u01b7\u0292\u0001\u01b8\u01b8\u01b9\u0001\u01bc\u01bc\u01bd\u0001\u01c4\u01c4\u01c6\u0001\u01c5\u01c5\u01c6\u0001\u01c7\u01c7\u01c9\u0001\u01c8\u01c8\u01c9\u0001\u01ca\u01ca\u01cc\u0001\u01cb\u01db\u01cc\u0002\u01de\u01ee\u01df\u0002\u01f1\u01f1\u01f3\u0001\u01f2\u01f4\u01f3\u0002\u01f6\u01f6\u0195\u0001\u01f7\u01f7\u01bf\u0001\u01f8\u021e\u01f9\u0002\u0220\u0220\u019e\u0001\u0222\u0232\u0223\u0002\u023a\u023a\u2c65\u0001\u023b\u023b\u023c\u0001\u023d\u023d\u019a\u0001\u023e\u023e\u2c66\u0001\u0241\u0241\u0242\u0001\u0243\u0243\u0180\u0001\u0244\u0244\u0289\u0001\u0245\u0245\u028c\u0001\u0246\u024e\u0247\u0002\u0370\u0372\u0371\u0002\u0376\u0376\u0377\u0001\u037f\u037f\u03f3\u0001\u0386\u0386\u03ac\u0001\u0388\u038a\u03ad\u0001\u038c\u038c\u03cc\u0001\u038e\u038f\u03cd\u0001\u0391\u03a1\u03b1\u0001\u03a3\u03ab\u03c3\u0001\u03cf\u03cf\u03d7\u0001\u03d8\u03ee\u03d9\u0002\u03f4\u03f4\u03b8\u0001\u03f7\u03f7\u03f8\u0001\u03f9\u03f9\u03f2\u0001\u03fa\u03fa\u03fb\u0001\u03fd\u03ff\u037b\u0001\u0400\u040f\u0450\u0001\u0410\u042f\u0430\u0001\u0460\u0480\u0461\u0002\u048a\u04be\u048b\u0002\u04c0\u04c0\u04cf\u0001\u04c1\u04cd\u04c2\u0002\u04d0\u052e\u04d1\u0002\u0531\u0556\u0561\u0001\u10a0\u10c5\u2d00\u0001\u10c7\u10c7\u2d27\u0001\u10cd\u10cd\u2d2d\u0001\u13a0\u13ef\uab70\u0001\u13f0\u13f5\u13f8\u0001\u1c90\u1cba\u10d0\u0001\u1cbd\u1cbf\u10fd\u0001\u1e00\u1e94\u1e01\u0002\u1e9e\u1e9e\u00df\u0001\u1ea0\u1efe\u1ea1\u0002\u1f08\u1f0f\u1f00\u0001\u1f18\u1f1d\u1f10\u0001\u1f28\u1f2f\u1f20\u0001\u1f38\u1f3f\u1f30\u0001\u1f48\u1f4d\u1f40\u0001\u1f59\u1f5f\u1f51\u0002\u1f68\u1f6f\u1f60\u0001\u1f88\u1f8f\u1f80\u0001\u1f98\u1f9f\u1f90\u0001\u1fa8\u1faf\u1fa0\u0001\u1fb8\u1fb9\u1fb0\u0001\u1fba\u1fbb\u1f70\u0001\u1fbc\u1fbc\u1fb3\u0001\u1fc8\u1fcb\u1f72\u0001\u1fcc\u1fcc\u1fc3\u0001\u1fd8\u1fd9\u1fd0\u0001\u1fda\u1fdb\u1f76\u0001\u1fe8\u1fe9\u1fe0\u0001\u1fea\u1feb\u1f7a\u0001\u1fec\u1fec\u1fe5\u0001\u1ff8\u1ff9\u1f78\u0001\u1ffa\u1ffb\u1f7c\u0001\u1ffc\u1ffc\u1ff3\u0001\u2126\u2126\u03c9\u0001\u212a\u212a\u006b\u0001\u212b\u212b\u00e5\u0001\u2132\u2132\u214e\u0001\u2160\u216f\u2170\u0001\u2183\u2183\u2184\u0001\u24b6\u24cf\u24d0\u0001\u2c00\u2c2f\u2c30\u0001\u2c60\u2c60\u2c61\u0001\u2c62\u2c62\u026b\u0001\u2c63\u2c63\u1d7d\u0001\u2c64\u2c64\u027d\u0001\u2c67\u2c6b\u2c68\u0002\u2c6d\u2c6d\u0251\u0001\u2c6e\u2c6e\u0271\u0001\u2c6f\u2c6f\u0250\u0001\u2c70\u2c70\u0252\u0001\u2c72\u2c72\u2c73\u0001\u2c75\u2c75\u2c76\u0001\u2c7e\u2c7f\u023f\u0001\u2c80\u2ce2\u2c81\u0002\u2ceb\u2ced\u2cec\u0002\u2cf2\u2cf2\u2cf3\u0001\ua640\ua66c\ua641\u0002\ua680\ua69a\ua681\u0002\ua722\ua72e\ua723\u0002\ua732\ua76e\ua733\u0002\ua779\ua77b\ua77a\u0002\ua77d\ua77d\u1d79\u0001\ua77e\ua786\ua77f\u0002\ua78b\ua78b\ua78c\u0001\ua78d\ua78d\u0265\u0001\ua790\ua792\ua791\u0002\ua796\ua7a8\ua797\u0002\ua7aa\ua7aa\u0266\u0001\ua7ab\ua7ab\u025c\u0001\ua7ac\ua7ac\u0261\u0001\ua7ad\ua7ad\u026c\u0001\ua7ae\ua7ae\u026a\u0001\ua7b0\ua7b0\u029e\u0001\ua7b1\ua7b1\u0287\u0001\ua7b2\ua7b2\u029d\u0001\ua7b3\ua7b3\uab53\u0001\ua7b4\ua7c2\ua7b5\u0002\ua7c4\ua7c4\ua794\u0001\ua7c5\ua7c5\u0282\u0001\ua7c6\ua7c6\u1d8e\u0001\ua7c7\ua7c9\ua7c8\u0002\ua7d0\ua7d0\ua7d1\u0001\ua7d6\ua7d8\ua7d7\u0002\ua7f5\ua7f5\ua7f6\u0001\uff21\uff3a\uff41\u0001');
export const __Porffor_caseUpper = (chr: i32): i32 => __Porffor_caseFind(chr, '\u00b5\u00b5\u039c\u0001\u00e0\u00f6\u00c0\u0001\u00f8\u00fe\u00d8\u0001\u00ff\u00ff\u0178\u0001\u0101\u012f\u0100\u0002\u0131\u0131\u0049\u0001\u0133\u0137\u0132\u0002\u013a\u0148\u0139\u0002\u014b\u0177\u014a\u0002\u017a\u017e\u0179\u0002\u017f\u017f\u0053\u0001\u0180\u0180\u0243\u0001\u0183\u0185\u0182\u0002\u0188\u0188\u0187\u0001\u018c\u018c\u018b\u0001\u0192\u0192\u0191\u0001\u0195\u0195\u01f6\u0001\u0199\u0199\u0198\u0001\u019a\u019a\u023d\u0001\u019e\u019e\u0220\u0001\u01a1\u01a5\u01a0\u0002\u01a8\u01a8\u01a7\u0001\u01ad\u01ad\u01ac\u0001\u01b0\u01b0\u01af\u0001\u01b4\u01b6\u01b3\u0002\u01b9\u01b9\u01b8\u0001\u01bd\u01bd\u01bc\u0001\u01bf\u01bf\u01f7\u0001\u01c5\u01c5\u01c4\u0001\u01c6\u01c6\u01c4\u0001\u01c8\u01c8\u01c7\u0001\u01c9\u01c9\u01c7\u0001\u01cb\u01cb\u01ca\u0001\u01cc\u01cc\u01ca\u0001\u01ce\u01dc\u01cd\u0002\u01dd\u01dd\u018e\u0001\u01df\u01ef\u01de\u0002\u01f2\u01f2\u01f1\u0001\u01f3\u01f3\u01f1\u0001\u01f5\u01f5\u01f4\u0001\u01f9\u021f\u01f8\u0002\u0223\u0233\u0222\u0002\u023c\u023c\u023b\u0001\u023f\u0240\u2c7e\u0001\u0242\u0242\u0241\u0001\u0247\u024f\u0246\u0002\u0250\u0250\u2c6f\u0001\u0251\u0251\u2c6d\u0001\u0252\u0252\u2c70\u0001\u0253\u0253\u0181\u0001\u0254\u0254\u0186\u0001\u0256\u0257\u0189\u0001\u0259\u0259\u018f\u0001\u025b\u025b\u0190\u0001\u025c\u025c\ua7ab\u0001\u0260\u0260\u0193\u0001\u0261\u0261\ua7ac\u0001\u0263\u0263\u0194\u0001\u0265\u0265\ua78d\u0001\u0266\u0266\ua7aa\u0001\u0268\u0268\u0197\u0001\u0269\u0269\u0196\u0001\u026a\u026a\ua7ae\u0001\u026b\u026b\u2c62\u0001\u026c\u026c\ua7ad\u0001\u026f\u026f\u019c\u0001\u0271\u0271\u2c6e\u0001\u0272\u0272\u019d\u0001\u0275\u0275\u019f\u0001\u027d\u027d\u2c64\u0001\u0280\u0280\u01a6\u0001\u0282\u0282\ua7c5\u0001\u0283\u0283\u01a9\u0001\u0287\u0287\ua7b1\u0001\u0288\u0288\u01ae\u0001\u0289\u0289\u0244\u0001\u028a\u028b\u01b1\u0001\u028c\u028c\u0245\u0001\u0292\u0292\u01b7\u0001\u029d\u029d\ua7b2\u0001\u029e\u029e\ua7b0\u0001\u0345\u0345\u0399\u0001\u0371\u0373\u0370\u0002\u0377\u0377\u0376\u0001\u037b\u037d\u03fd\u0001\u03ac\u03ac\u0386\u0001\u03ad\u03af\u0388\u0001\u03b1\u03c1\u0391\u0001\u03c2\u03c2\u03a3\u0001\u03c3\u03cb\u03a3\u0001\u03cc\u03cc\u038c\u0001\u03cd\u03ce\u038e\u0001\u03d0\u03d0\u0392\u0001\u03d1\u03d1\u0398\u0001\u03d5\u03d5\u03a6\u0001\u03d6\u03d6\u03a0\u0001\u03d7\u03d7\u03cf\u0001\u03d9\u03ef\u03d8\u0002\u03f0\u03f0\u039a\u0001\u03f1\u03f1\u03a1\u0001\u03f2\u03f2\u03f9\u0001\u03f3\u03f3\u037f\u0001\u03f5\u03f5\u0395\u0001\u03f8\u03f8\u03f7\u0001\u03fb\u03fb\u03fa\u0001\u0430\u044f\u0410\u0001\u0450\u045f\u0400\u0001\u0461\u0481\u0460\u0002\u048b\u04bf\u048a\u0002\u04c2\u04ce\u04c1\u0002\u04cf\u04cf\u04c0\u0001\u04d1\u052f\u04d0\u0002\u0561\u0586\u0531\u0001\u10d0\u10fa\u1c90\u0001\u10fd\u10ff\u1cbd\u0001\u13f8\u13fd\u13f0\u0001\u1c80\u1c80\u0412\u0001\u1c81\u1c81\u0414\u0001\u1c82\u1c82\u041e\u0001\u1c83\u1c84\u0421\u0001\u1c85\u1c85\u0422\u0001\u1c86\u1c86\u042a\u0001\u1c87\u1c87\u0462\u0001\u1c88\u1c88\ua64a\u0001\u1d79\u1d79\ua77d\u0001\u1d7d\u1d7d\u2c63\u0001\u1d8e\u1d8e\ua7c6\u0001\u1e01\u1e95\u1e00\u0002\u1e9b\u1e9b\u1e60\u0001\u1ea1\u1eff\u1ea0\u0002\u1f00\u1f07\u1f08\u0001\u1f10\u1f15\u1f18\u0001\u1f20\u1f27\u1f28\u0001\u1f30\u1f37\u1f38\u0001\u1f40\u1f45\u1f48\u0001\u1f51\u1f57\u1f59\u0002\u1f60\u1f67\u1f68\u0001\u1f70\u1f71\u1fba\u0001\u1f72\u1f75\u1fc8\u0001\u1f76\u1f77\u1fda\u0001\u1f78\u1f79\u1ff8\u0001\u1f7a\u1f7b\u1fea\u0001\u1f7c\u1f7d\u1ffa\u0001\u1fb0\u1fb1\u1fb8\u0001\u1fbe\u1fbe\u0399\u0001\u1fd0\u1fd1\u1fd8\u0001\u1fe0\u1fe1\u1fe8\u0001\u1fe5\u1fe5\u1fec\u0001\u214e\u214e\u2132\u0001\u2170\u217f\u2160\u0001\u2184\u2184\u2183\u0001\u24d0\u24e9\u24b6\u0001\u2c30\u2c5f\u2c00\u0001\u2c61\u2c61\u2c60\u0001\u2c65\u2c65\u023a\u0001\u2c66\u2c66\u023e\u0001\u2c68\u2c6c\u2c67\u0002\u2c73\u2c73\u2c72\u0001\u2c76\u2c76\u2c75\u0001\u2c81\u2ce3\u2c80\u0002\u2cec\u2cee\u2ceb\u0002\u2cf3\u2cf3\u2cf2\u0001\u2d00\u2d25\u10a0\u0001\u2d27\u2d27\u10c7\u0001\u2d2d\u2d2d\u10cd\u0001\ua641\ua66d\ua640\u0002\ua681\ua69b\ua680\u0002\ua723\ua72f\ua722\u0002\ua733\ua76f\ua732\u0002\ua77a\ua77c\ua779\u0002\ua77f\ua787\ua77e\u0002\ua78c\ua78c\ua78b\u0001\ua791\ua793\ua790\u0002\ua794\ua794\ua7c4\u0001\ua797\ua7a9\ua796\u0002\ua7b5\ua7c3\ua7b4\u0002\ua7c8\ua7ca\ua7c7\u0002\ua7d1\ua7d1\ua7d0\u0001\ua7d7\ua7d9\ua7d6\u0002\ua7f6\ua7f6\ua7f5\u0001\uab53\uab53\ua7b3\u0001\uab70\uabbf\u13a0\u0001\uff41\uff5a\uff21\u0001');

export const __String_prototype_toUpperCase = function (this: string) {
  // todo: unicode not just ascii
  const len: i32 = this.length;

  const out: string = Porffor.malloc(6 + len * 2);
  Porffor.IR.storeI32(out, 0, len);

  let i: i32 = Porffor.IR.ptr(this),
      j: i32 = Porffor.IR.ptr(out);

  const endPtr: i32 = i + len * 2;
  while (i < endPtr) {
    let chr: i32 = Porffor.IR.loadU16(i, 4);
    i += 2;

    if (chr < 128) { if (chr >= 97) if (chr <= 122) chr -= 32; } else chr = __Porffor_caseUpper(chr);

    Porffor.IR.storeU16(j, 4, chr);
    j += 2;
  }

  return out;
};

export const __ByteString_prototype_toUpperCase = function (this: bytestring) {
  const len: i32 = this.length;

  const out: bytestring = Porffor.malloc(6 + len);
  Porffor.IR.storeI32(out, 0, len);

  let i: i32 = Porffor.IR.ptr(this),
      j: i32 = Porffor.IR.ptr(out);

  const endPtr: i32 = i + len;
  while (i < endPtr) {
    let chr: i32 = Porffor.IR.loadU8(i++, 4);

    if (chr >= 97) { if (chr <= 122) chr -= 32; else if (chr >= 224) if (chr <= 254) if (chr != 247) chr -= 32; }

    Porffor.IR.storeU8(j++, 4, chr);
  }

  return out;
};

export const __String_prototype_toLowerCase = function (this: string) {
  // todo: unicode not just ascii
  const len: i32 = this.length;

  const out: string = Porffor.malloc(6 + len * 2);
  Porffor.IR.storeI32(out, 0, len);

  let i: i32 = Porffor.IR.ptr(this),
      j: i32 = Porffor.IR.ptr(out);

  const endPtr: i32 = i + len * 2;
  while (i < endPtr) {
    let chr: i32 = Porffor.IR.loadU16(i, 4);
    i += 2;

    if (chr < 128) { if (chr >= 65) if (chr <= 90) chr += 32; } else chr = __Porffor_caseLower(chr);

    Porffor.IR.storeU16(j, 4, chr);
    j += 2;
  }

  return out;
};

export const __ByteString_prototype_toLowerCase = function (this: bytestring) {
  const len: i32 = this.length;

  const out: bytestring = Porffor.malloc(6 + len);
  Porffor.IR.storeI32(out, 0, len);

  let i: i32 = Porffor.IR.ptr(this),
      j: i32 = Porffor.IR.ptr(out);

  const endPtr: i32 = i + len;
  while (i < endPtr) {
    let chr: i32 = Porffor.IR.loadU8(i++, 4);

    if (chr >= 65) { if (chr <= 90) chr += 32; else if (chr >= 192) if (chr <= 222) if (chr != 215) chr += 32; }

    Porffor.IR.storeU8(j++, 4, chr);
  }

  return out;
};

export const __String_prototype_toLocaleUpperCase = function (this: string) { return Porffor.callThis(__String_prototype_toUpperCase, this); };
export const __ByteString_prototype_toLocaleUpperCase = function (this: bytestring) { return Porffor.callThis(__ByteString_prototype_toUpperCase, this); };
export const __String_prototype_toLocaleLowerCase = function (this: string) { return Porffor.callThis(__String_prototype_toLowerCase, this); };
export const __ByteString_prototype_toLocaleLowerCase = function (this: bytestring) { return Porffor.callThis(__ByteString_prototype_toLowerCase, this); };

export const __String_prototype_codePointAt = function (this: string, _index: any) {
  const len: i32 = this.length;
  const index: number = ecma262.ToIntegerOrInfinity(_index);

  if (Porffor.fastOr(index < 0, index >= len)) return undefined;

  const c1: i32 = Porffor.IR.loadU16(Porffor.IR.ptr(this) + index * 2, 4);
  if (Porffor.fastAnd(c1 >= 0xD800, c1 <= 0xDBFF)) {
    // 1st char is leading surrogate, handle 2nd char
    // check oob
    if (index + 1 >= len) return c1;

    const c2: i32 = Porffor.IR.loadU16(Porffor.IR.ptr(this) + index * 2 + 2, 4);
    if (Porffor.fastAnd(c2 >= 0xDC00, c2 <= 0xDFFF)) {
      // 2nd char is trailing surrogate, return code point
      return (c1 << 10) + c2 - 56613888;
    }
  }

  return c1;
};

export const __ByteString_prototype_codePointAt = function (this: bytestring, _index: any) {
  const len: i32 = this.length;
  const index: number = ecma262.ToIntegerOrInfinity(_index);

  if (Porffor.fastOr(index < 0, index >= len)) return undefined;

  // bytestrings cannot have surrogates, so just do charCodeAt
  return Porffor.IR.loadU8(Porffor.IR.ptr(this) + index, 4);
};

export const __Porffor_string_searchArg = (searchString: any): any => {
  if (Porffor.object.isObject(searchString)) {
    let isRegExp: boolean = false;
    if (Porffor.comptime.flag`hasType.regexp`) {
      isRegExp = __Porffor_regex_isRegExp(searchString);
    } else {
      const matcher: any = Porffor.object.get(searchString, Symbol.match);
      isRegExp = matcher !== undefined && !!matcher;
    }
    if (isRegExp) throw new TypeError('First argument must not be a regular expression');
  }
  if ((Porffor.type(searchString) | 0b10000000) == Porffor.TYPES.bytestring) return searchString;
  return ecma262.ToString(searchString);
};

export const __Porffor_string_clampPos = (pos: any, len: i32): i32 => {
  const n: number = ecma262.ToIntegerOrInfinity(pos);
  if (n <= 0) return 0;
  if (n >= len) return len;
  return n;
};

export const __String_prototype_startsWith = function (this: string, searchString: any, position: any = undefined) {
  searchString = __Porffor_string_searchArg(searchString);
  const len: i32 = this.length;
  const start: i32 = __Porffor_string_clampPos(position, len);
  if (Porffor.type(searchString) == Porffor.TYPES.bytestring) searchString = Porffor.bytestringToString(searchString);

  const searchLen: i32 = searchString.length;
  if (searchLen > len - start) return false;

  const thisPtr: i32 = Porffor.IR.ptr(this) + start * 2;
  const searchPtr: i32 = Porffor.IR.ptr(searchString);
  for (let i: i32 = 0; i < searchLen * 2; i += 2) {
    if (Porffor.IR.loadU16(thisPtr + i, 4) != Porffor.IR.loadU16(searchPtr + i, 4)) return false;
  }
  return true;
};

export const __ByteString_prototype_startsWith = function (this: bytestring, searchString: any, position: any = undefined) {
  searchString = __Porffor_string_searchArg(searchString);
  const len: i32 = this.length;
  const start: i32 = __Porffor_string_clampPos(position, len);
  if (Porffor.type(searchString) != Porffor.TYPES.bytestring) return Porffor.callThis(__String_prototype_startsWith, Porffor.bytestringToString(this), searchString, start);

  const searchLen: i32 = searchString.length;
  if (searchLen > len - start) return false;

  const thisPtr: i32 = Porffor.IR.ptr(this) + start;
  const searchPtr: i32 = Porffor.IR.ptr(searchString);
  for (let i: i32 = 0; i < searchLen; i++) {
    if (Porffor.IR.loadU8(thisPtr + i, 4) != Porffor.IR.loadU8(searchPtr + i, 4)) return false;
  }
  return true;
};

export const __String_prototype_endsWith = function (this: string, searchString: any, endPosition: any = undefined) {
  searchString = __Porffor_string_searchArg(searchString);
  const len: i32 = this.length;
  const end: i32 = endPosition === undefined ? len : __Porffor_string_clampPos(endPosition, len);
  if (Porffor.type(searchString) == Porffor.TYPES.bytestring) searchString = Porffor.bytestringToString(searchString);

  const searchLen: i32 = searchString.length;
  const start: i32 = end - searchLen;
  if (start < 0) return false;

  const thisPtr: i32 = Porffor.IR.ptr(this) + start * 2;
  const searchPtr: i32 = Porffor.IR.ptr(searchString);
  for (let i: i32 = 0; i < searchLen * 2; i += 2) {
    if (Porffor.IR.loadU16(thisPtr + i, 4) != Porffor.IR.loadU16(searchPtr + i, 4)) return false;
  }
  return true;
};

export const __ByteString_prototype_endsWith = function (this: bytestring, searchString: any, endPosition: any = undefined) {
  searchString = __Porffor_string_searchArg(searchString);
  const len: i32 = this.length;
  const end: i32 = endPosition === undefined ? len : __Porffor_string_clampPos(endPosition, len);
  if (Porffor.type(searchString) != Porffor.TYPES.bytestring) return Porffor.callThis(__String_prototype_endsWith, Porffor.bytestringToString(this), searchString, end);

  const searchLen: i32 = searchString.length;
  const start: i32 = end - searchLen;
  if (start < 0) return false;

  const thisPtr: i32 = Porffor.IR.ptr(this) + start;
  const searchPtr: i32 = Porffor.IR.ptr(searchString);
  for (let i: i32 = 0; i < searchLen; i++) {
    if (Porffor.IR.loadU8(thisPtr + i, 4) != Porffor.IR.loadU8(searchPtr + i, 4)) return false;
  }
  return true;
};


export const __String_prototype_indexOf = function (this: string, searchString: any, position: any = 0) {
  searchString = ecma262.ToString(searchString);
  if (Porffor.type(searchString) == Porffor.TYPES.bytestring) {
    searchString = Porffor.bytestringToString(searchString);
  }
  position = ecma262.ToIntegerOrInfinity(position);

  let thisPtr: i32 = Porffor.IR.ptr(this);
  const searchPtr: i32 = Porffor.IR.ptr(searchString);

  const searchLenX2: i32 = searchString.length * 2;

  // todo/perf: make position oob handling optional (via pref or fast variant?)
  const len: i32 = this.length;
  if (position > 0) {
    if (position > len) position = len;
  } else position = 0;

  // longer search than rest: negative end would saturate (i32) and scan all memory
  if (searchString.length > len) return -1;

  const thisPtrEnd: i32 = thisPtr + (len * 2) - searchLenX2;

  thisPtr += position * 2;

  while (thisPtr <= thisPtrEnd) {
    let match: boolean = true;
    for (let i: i32 = 0; i < searchLenX2; i += 2) {
      let chr: i32 = Porffor.IR.loadU16(thisPtr + i, 4);
      let expected: i32 = Porffor.IR.loadU16(searchPtr + i, 4);

      if (chr != expected) {
        match = false;
        break;
      }
    }

    if (match) return (thisPtr - Porffor.IR.ptr(this)) / 2;

    thisPtr += 2;
  }

  return -1;
};

export const __ByteString_prototype_indexOf = function (this: bytestring, searchString: any, position: any = 0) {
  searchString = ecma262.ToString(searchString);
  if (Porffor.type(searchString) != Porffor.TYPES.bytestring) {
    return Porffor.callThis(__String_prototype_indexOf, Porffor.bytestringToString(this), searchString, position);
  }
  position = ecma262.ToIntegerOrInfinity(position);

  let thisPtr: i32 = Porffor.IR.ptr(this);
  const searchPtr: i32 = Porffor.IR.ptr(searchString);

  const searchLen: i32 = searchString.length;

  // todo/perf: make position oob handling optional (via pref or fast variant?)
  const len: i32 = this.length;
  if (position > 0) {
    if (position > len) position = len;
  } else position = 0;

  // longer search than rest: negative end would saturate (i32) and scan all memory
  if (searchLen > len) return -1;

  const thisPtrEnd: i32 = thisPtr + len - searchLen;

  thisPtr += position;

  while (thisPtr <= thisPtrEnd) {
    let match: boolean = true;
    for (let i: i32 = 0; i < searchLen; i++) {
      let chr: i32 = Porffor.IR.loadU8(thisPtr + i, 4);
      let expected: i32 = Porffor.IR.loadU8(searchPtr + i, 4);

      if (chr != expected) {
        match = false;
        break;
      }
    }

    if (match) return thisPtr - Porffor.IR.ptr(this);

    thisPtr++;
  }

  return -1;
};


export const __Porffor_string_lastPos = (position: any): number => {
  const n: number = ecma262.ToNumber(position);
  if (n != n) return Infinity;
  return ecma262.ToIntegerOrInfinity(n);
};

export const __String_prototype_lastIndexOf = function (this: string, searchString: any, position: any = undefined) {
  searchString = ecma262.ToString(searchString);
  const pos: number = __Porffor_string_lastPos(position);
  if (Porffor.type(searchString) == Porffor.TYPES.bytestring) searchString = Porffor.bytestringToString(searchString);

  const len: i32 = this.length;
  const searchLen: i32 = searchString.length;
  if (searchLen > len) return -1;

  let start: i32 = len - searchLen;
  if (pos < start) start = pos < 0 ? 0 : pos;

  const thisPtr: i32 = Porffor.IR.ptr(this);
  const searchPtr: i32 = Porffor.IR.ptr(searchString);
  for (let k: i32 = start; k >= 0; k--) {
    let match: boolean = true;
    for (let i: i32 = 0; i < searchLen; i++) {
      if (Porffor.IR.loadU16(thisPtr + (k + i) * 2, 4) != Porffor.IR.loadU16(searchPtr + i * 2, 4)) {
        match = false;
        break;
      }
    }
    if (match) return k;
  }
  return -1;
};

export const __ByteString_prototype_lastIndexOf = function (this: bytestring, searchString: any, position: any = undefined) {
  searchString = ecma262.ToString(searchString);
  const pos: number = __Porffor_string_lastPos(position);
  if (Porffor.type(searchString) != Porffor.TYPES.bytestring) return Porffor.callThis(__String_prototype_lastIndexOf, Porffor.bytestringToString(this), searchString, pos);

  const len: i32 = this.length;
  const searchLen: i32 = searchString.length;
  if (searchLen > len) return -1;

  let start: i32 = len - searchLen;
  if (pos < start) start = pos < 0 ? 0 : pos;

  const thisPtr: i32 = Porffor.IR.ptr(this);
  const searchPtr: i32 = Porffor.IR.ptr(searchString);
  for (let k: i32 = start; k >= 0; k--) {
    let match: boolean = true;
    for (let i: i32 = 0; i < searchLen; i++) {
      if (Porffor.IR.loadU8(thisPtr + k + i, 4) != Porffor.IR.loadU8(searchPtr + i, 4)) {
        match = false;
        break;
      }
    }
    if (match) return k;
  }
  return -1;
};


export const __String_prototype_includes = function (this: string, searchString: any, position: any = undefined) {
  searchString = __Porffor_string_searchArg(searchString);
  position = __Porffor_string_clampPos(position, this.length);
  if (Porffor.type(searchString) == Porffor.TYPES.bytestring) {
    searchString = Porffor.bytestringToString(searchString);
  }

  let thisPtr: i32 = Porffor.IR.ptr(this);
  const searchPtr: i32 = Porffor.IR.ptr(searchString);

  const searchLenX2: i32 = searchString.length * 2;

  // todo/perf: make position oob handling optional (via pref or fast variant?)
  const len: i32 = this.length;
  if (position > 0) {
    if (position > len) position = len;
  } else position = 0;

  // longer search than rest: negative end would saturate (i32) and scan all memory
  if (searchString.length > len) return false;

  const thisPtrEnd: i32 = thisPtr + (len * 2) - searchLenX2;

  thisPtr += position * 2;

  while (thisPtr <= thisPtrEnd) {
    let match: boolean = true;
    for (let i: i32 = 0; i < searchLenX2; i += 2) {
      let chr: i32 = Porffor.IR.loadU16(thisPtr + i, 4);
      let expected: i32 = Porffor.IR.loadU16(searchPtr + i, 4);

      if (chr != expected) {
        match = false;
        break;
      }
    }

    if (match) return true;

    thisPtr += 2;
  }

  return false;
};

export const __ByteString_prototype_includes = function (this: bytestring, searchString: any, position: any = undefined) {
  searchString = __Porffor_string_searchArg(searchString);
  position = __Porffor_string_clampPos(position, this.length);
  if (Porffor.type(searchString) != Porffor.TYPES.bytestring) {
    return Porffor.callThis(__String_prototype_includes, Porffor.bytestringToString(this), searchString, position);
  }

  let thisPtr: i32 = Porffor.IR.ptr(this);
  const searchPtr: i32 = Porffor.IR.ptr(searchString);

  const searchLen: i32 = searchString.length;

  // todo/perf: make position oob handling optional (via pref or fast variant?)
  const len: i32 = this.length;
  if (position > 0) {
    if (position > len) position = len;
  } else position = 0;

  // longer search than rest: negative end would saturate (i32) and scan all memory
  if (searchLen > len) return false;

  const thisPtrEnd: i32 = thisPtr + len - searchLen;

  thisPtr += position;

  while (thisPtr <= thisPtrEnd) {
    let match: boolean = true;
    for (let i: i32 = 0; i < searchLen; i++) {
      let chr: i32 = Porffor.IR.loadU8(thisPtr + i, 4);
      let expected: i32 = Porffor.IR.loadU8(searchPtr + i, 4);

      if (chr != expected) {
        match = false;
        break;
      }
    }

    if (match) return true;

    thisPtr++;
  }

  return false;
};


export const __String_prototype_padStart = function (this: string, _targetLength: any, padString: any = undefined) {
  const len: i32 = this.length;
  const targetLength: number = ecma262.ToLength(_targetLength);
  const todo: i32 = targetLength - len;
  const out: string = Porffor.malloc((todo > 0 ? len + todo : len) * 2 + 6);

  let outPtr: i32 = Porffor.IR.ptr(out);
  let thisPtr: i32 = Porffor.IR.ptr(this);

  if (todo > 0) {
    if (Porffor.type(padString) == Porffor.TYPES.undefined) {
      for (let i: i32 = 0; i < todo; i++) {
        Porffor.IR.storeU16(outPtr, 4, 32);
        outPtr += 2;
      }

      out.length = targetLength;
    } else {
      padString = ecma262.ToString(padString);
      // utf-16 access below needs a full string
      if (Porffor.type(padString) == Porffor.TYPES.bytestring) {
        padString = Porffor.bytestringToString(padString);
      }
      const padStringLen: i32 = padString.length;
      if (padStringLen > 0) {
        for (let i: i32 = 0; i < todo; i++) {
          Porffor.IR.storeU16(outPtr, 4, Porffor.IR.loadU16(Porffor.IR.ptr(padString) + (i % padStringLen) * 2, 4));
          outPtr += 2;
        }
        out.length = targetLength;
      } else out.length = len;
    }
  } else out.length = len;

  const thisPtrEnd: i32 = thisPtr + len * 2;

  while (thisPtr < thisPtrEnd) {
    Porffor.IR.storeU16(outPtr, 4, Porffor.IR.loadU16(thisPtr, 4));

    thisPtr += 2;
    outPtr += 2;
  }

  return out;
};

export const __ByteString_prototype_padStart = function (this: bytestring, _targetLength: any, padString: any = undefined) {
  const len: i32 = this.length;
  const targetLength: number = ecma262.ToLength(_targetLength);
  const todo: i32 = targetLength - len;
  const out: bytestring = Porffor.malloc((todo > 0 ? len + todo : len) + 5);

  let outPtr: i32 = Porffor.IR.ptr(out);
  let thisPtr: i32 = Porffor.IR.ptr(this);

  if (todo > 0) {
    if (Porffor.type(padString) == Porffor.TYPES.undefined) {
      for (let i: i32 = 0; i < todo; i++) {
        Porffor.IR.storeU8(outPtr++, 4, 32);
      }

      out.length = targetLength;
    } else {
      padString = ecma262.ToString(padString);
      // non-bytestring pad: delegate to the string version
      if (Porffor.type(padString) != Porffor.TYPES.bytestring) {
        return Porffor.callThis(__String_prototype_padStart, Porffor.bytestringToString(this), targetLength, padString);
      }
      const padStringLen: i32 = padString.length;
      if (padStringLen > 0) {
        for (let i: i32 = 0; i < todo; i++) {
          Porffor.IR.storeU8(outPtr++, 4, Porffor.IR.loadU8(Porffor.IR.ptr(padString) + (i % padStringLen), 4));
        }

        out.length = targetLength;
      } else out.length = len;
    }
  } else out.length = len;

  const thisPtrEnd: i32 = thisPtr + len;

  while (thisPtr < thisPtrEnd) {
    Porffor.IR.storeU8(outPtr++, 4, Porffor.IR.loadU8(thisPtr++, 4));
  }

  return out;
};


export const __String_prototype_padEnd = function (this: string, _targetLength: any, padString: any = undefined) {
  const len: i32 = this.length;
  const targetLength: number = ecma262.ToLength(_targetLength);
  const todo: i32 = targetLength - len;
  const out: string = Porffor.malloc((todo > 0 ? len + todo : len) * 2 + 6);

  let outPtr: i32 = Porffor.IR.ptr(out);
  let thisPtr: i32 = Porffor.IR.ptr(this);

  const thisPtrEnd: i32 = thisPtr + len * 2;

  while (thisPtr < thisPtrEnd) {
    Porffor.IR.storeU16(outPtr, 4, Porffor.IR.loadU16(thisPtr, 4));

    thisPtr += 2;
    outPtr += 2;
  }

  if (todo > 0) {
    if (Porffor.type(padString) == Porffor.TYPES.undefined) {
      for (let i: i32 = 0; i < todo; i++) {
        Porffor.IR.storeU16(outPtr, 4, 32);
        outPtr += 2;
      }

      out.length = targetLength;
    } else {
      padString = ecma262.ToString(padString);
      // utf-16 access below needs a full string
      if (Porffor.type(padString) == Porffor.TYPES.bytestring) {
        padString = Porffor.bytestringToString(padString);
      }
      const padStringLen: i32 = padString.length;
      if (padStringLen > 0) {
        for (let i: i32 = 0; i < todo; i++) {
          Porffor.IR.storeU16(outPtr, 4, Porffor.IR.loadU16(Porffor.IR.ptr(padString) + (i % padStringLen) * 2, 4));
          outPtr += 2;
        }
        out.length = targetLength;
      } else out.length = len;
    }
  } else out.length = len;
  return out;
};

export const __ByteString_prototype_padEnd = function (this: bytestring, _targetLength: any, padString: any = undefined) {
  const len: i32 = this.length;
  const targetLength: number = ecma262.ToLength(_targetLength);
  const todo: i32 = targetLength - len;
  const out: bytestring = Porffor.malloc((todo > 0 ? len + todo : len) + 5);

  let outPtr: i32 = Porffor.IR.ptr(out);
  let thisPtr: i32 = Porffor.IR.ptr(this);

  const thisPtrEnd: i32 = thisPtr + len;

  while (thisPtr < thisPtrEnd) {
    Porffor.IR.storeU8(outPtr++, 4, Porffor.IR.loadU8(thisPtr++, 4));
  }

  if (todo > 0) {
    if (Porffor.type(padString) == Porffor.TYPES.undefined) {
      for (let i: i32 = 0; i < todo; i++) {
        Porffor.IR.storeU8(outPtr++, 4, 32);
      }

      out.length = targetLength;
    } else {
      padString = ecma262.ToString(padString);
      // non-bytestring pad: delegate to the string version
      if (Porffor.type(padString) != Porffor.TYPES.bytestring) {
        return Porffor.callThis(__String_prototype_padEnd, Porffor.bytestringToString(this), targetLength, padString);
      }
      const padStringLen: i32 = padString.length;
      if (padStringLen > 0) {
        for (let i: i32 = 0; i < todo; i++) {
          Porffor.IR.storeU8(outPtr++, 4, Porffor.IR.loadU8(Porffor.IR.ptr(padString) + (i % padStringLen), 4));
        }

        out.length = targetLength;
      } else out.length = len;
    }
  } else out.length = len;
  return out;
};


export const __Porffor_string_substringToBest = (str: string, start: number, end: number): bytestring|string => {
  const outLen: i32 = end - start;
  let thisPtr: i32 = Porffor.IR.ptr(str);
  const thisPtrEnd: i32 = thisPtr + end * 2;
  thisPtr += start * 2;

  let string: boolean = false;
  let scanPtr: i32 = thisPtr;
  while (scanPtr < thisPtrEnd) {
    if (Porffor.IR.loadU16(scanPtr, 4) > 0xff) {
      string = true;
      break;
    }

    scanPtr += 2;
  }

  if (!string) {
    const out: bytestring = Porffor.malloc(6 + outLen);
    let outPtr: i32 = Porffor.IR.ptr(out);
    while (thisPtr < thisPtrEnd) {
      Porffor.IR.storeU8(outPtr++, 4, Porffor.IR.loadU16(thisPtr, 4));
      thisPtr += 2;
    }

    out.length = outLen;
    return out;
  }

  const out: string = Porffor.malloc(6 + outLen * 2);
  if (outLen > 0) Porffor.IR.copy(Porffor.IR.ptr(out) + 4, Porffor.IR.ptr(str) + 4 + start * 2, outLen * 2);

  out.length = outLen;
  return out;
};

export const __String_prototype_substring = function (this: string, _start: any, _end: any) {
  const len: i32 = this.length;
  if (Porffor.type(_end) == Porffor.TYPES.undefined) _end = len;

  let start: number = ecma262.ToIntegerOrInfinity(_start);
  let end: number = ecma262.ToIntegerOrInfinity(_end);

  if (start < 0) start = 0;
  if (start > len) start = len;
  if (end < 0) end = 0;
  if (end > len) end = len;

  if (start > end) {
    const tmp: i32 = end;
    end = start;
    start = tmp;
  }

  return __Porffor_string_substringToBest(this, start, end);
};

export const __ByteString_prototype_substring = function (this: bytestring, _start: any, _end: any) {
  const len: i32 = this.length;
  if (Porffor.type(_end) == Porffor.TYPES.undefined) _end = len;

  let start: number = ecma262.ToIntegerOrInfinity(_start);
  let end: number = ecma262.ToIntegerOrInfinity(_end);

  if (start < 0) start = 0;
  if (start > len) start = len;
  if (end < 0) end = 0;
  if (end > len) end = len;

  if (start > end) {
    const tmp: i32 = end;
    end = start;
    start = tmp;
  }

  return __Porffor_bytestring_sub(this, start, end);
};


export const __String_prototype_substr = function (this: string, _start: any, _length: any) {
  const len: i32 = this.length;
  let start: number = ecma262.ToIntegerOrInfinity(_start);
  if (start < 0) {
    start = len + start;
    if (start < 0) start = 0;
  }

  if (Porffor.type(_length) == Porffor.TYPES.undefined) _length = len - start;

  let length: number = ecma262.ToIntegerOrInfinity(_length);
  if (start + length > len) length = len - start;

  return __Porffor_string_substringToBest(this, start, start + length);
};

export const __ByteString_prototype_substr = function (this: bytestring, _start: any, _length: any) {
  const len: i32 = this.length;
  let start: number = ecma262.ToIntegerOrInfinity(_start);
  if (start < 0) {
    start = len + start;
    if (start < 0) start = 0;
  }

  if (Porffor.type(_length) == Porffor.TYPES.undefined) _length = len - start;

  if (start > len) start = len;
  let length: number = ecma262.ToIntegerOrInfinity(_length);
  if (start + length > len) length = len - start;
  if (length < 0) length = 0;

  return __Porffor_bytestring_sub(this, start, start + length);
};


export const __String_prototype_slice = function (this: string, _start: any, _end: any) {
  const len: i32 = this.length;
  if (Porffor.type(_end) == Porffor.TYPES.undefined) _end = len;

  let start: number = ecma262.ToIntegerOrInfinity(_start);
  let end: number = ecma262.ToIntegerOrInfinity(_end);

  if (start < 0) {
    start = len + start;
    if (start < 0) start = 0;
  }
  if (start > len) start = len;
  if (end < 0) {
    end = len + end;
    if (end < 0) end = 0;
  }
  if (end > len) end = len;

  if (start > end) end = start;

  return __Porffor_string_substringToBest(this, start, end);
};

export const __ByteString_prototype_slice = function (this: bytestring, _start: any, _end: any) {
  const len: i32 = this.length;
  if (Porffor.type(_end) == Porffor.TYPES.undefined) _end = len;

  let start: number = ecma262.ToIntegerOrInfinity(_start);
  let end: number = ecma262.ToIntegerOrInfinity(_end);

  if (start < 0) {
    start = len + start;
    if (start < 0) start = 0;
  }
  if (start > len) start = len;
  if (end < 0) {
    end = len + end;
    if (end < 0) end = 0;
  }
  if (end > len) end = len;

  if (start > end) end = start;

  return __Porffor_bytestring_sub(this, start, end);
};


// WhiteSpace and LineTerminator code units
export const __Porffor_string_isSpace = (c: i32): boolean =>
  Porffor.fastOr(c == 0x20, Porffor.fastAnd(c >= 0x9, c <= 0xd), c == 0xa0, c == 0x1680, Porffor.fastAnd(c >= 0x2000, c <= 0x200a), c == 0x2028, c == 0x2029, c == 0x202f, c == 0x205f, c == 0x3000, c == 0xfeff);

export const __Porffor_string_sub = (str: string, start: i32, end: i32): string => {
  if (Porffor.fastAnd(start == 0, end == str.length)) return str;
  const out: string = Porffor.malloc(6 + (end - start) * 2);
  Porffor.IR.copy(Porffor.IR.ptr(out) + 4, Porffor.IR.ptr(str) + 4 + start * 2, (end - start) * 2);
  out.length = end - start;
  return out;
};

export const __Porffor_bytestring_sub = (str: bytestring, start: i32, end: i32): bytestring => {
  if (Porffor.fastAnd(start == 0, end == str.length)) return str;
  const out: bytestring = Porffor.malloc(6 + (end - start));
  Porffor.IR.copy(Porffor.IR.ptr(out) + 4, Porffor.IR.ptr(str) + 4 + start, end - start);
  out.length = end - start;
  return out;
};

export const __String_prototype_trimStart = function (this: string) {
  const len: i32 = this.length, ptr: i32 = Porffor.IR.ptr(this);
  let start: i32 = 0;
  while (start < len && __Porffor_string_isSpace(Porffor.IR.loadU16(ptr + start * 2, 4))) start++;
  return __Porffor_string_sub(this, start, len);
};

export const __ByteString_prototype_trimStart = function (this: bytestring) {
  const len: i32 = this.length, ptr: i32 = Porffor.IR.ptr(this);
  let start: i32 = 0;
  while (start < len && __Porffor_string_isSpace(Porffor.IR.loadU8(ptr + start, 4))) start++;
  return __Porffor_bytestring_sub(this, start, len);
};

export const __String_prototype_trimEnd = function (this: string) {
  const ptr: i32 = Porffor.IR.ptr(this);
  let end: i32 = this.length;
  while (end > 0 && __Porffor_string_isSpace(Porffor.IR.loadU16(ptr + end * 2 - 2, 4))) end--;
  return __Porffor_string_sub(this, 0, end);
};

export const __ByteString_prototype_trimEnd = function (this: bytestring) {
  const ptr: i32 = Porffor.IR.ptr(this);
  let end: i32 = this.length;
  while (end > 0 && __Porffor_string_isSpace(Porffor.IR.loadU8(ptr + end - 1, 4))) end--;
  return __Porffor_bytestring_sub(this, 0, end);
};

export const __String_prototype_trim = function (this: string) {
  const ptr: i32 = Porffor.IR.ptr(this);
  let start: i32 = 0, end: i32 = this.length;
  while (start < end && __Porffor_string_isSpace(Porffor.IR.loadU16(ptr + start * 2, 4))) start++;
  while (end > start && __Porffor_string_isSpace(Porffor.IR.loadU16(ptr + end * 2 - 2, 4))) end--;
  return __Porffor_string_sub(this, start, end);
};

export const __ByteString_prototype_trim = function (this: bytestring) {
  const ptr: i32 = Porffor.IR.ptr(this);
  let start: i32 = 0, end: i32 = this.length;
  while (start < end && __Porffor_string_isSpace(Porffor.IR.loadU8(ptr + start, 4))) start++;
  while (end > start && __Porffor_string_isSpace(Porffor.IR.loadU8(ptr + end - 1, 4))) end--;
  return __Porffor_bytestring_sub(this, start, end);
};


export const __String_prototype_concat = function (this: string, ...vals: any[]) {
  let out: any = this;
  const valsLen: i32 = vals.length;
  for (let i: i32 = 0; i < valsLen; i++) {
    out = __Porffor_concatStrings(out, vals[i]);
  }

  return out;
};

export const __ByteString_prototype_concat = function (this: bytestring, ...vals: any[]) {
  let out: any = this;
  const valsLen: i32 = vals.length;
  for (let i: i32 = 0; i < valsLen; i++) {
    out = __Porffor_concatStrings(out, vals[i]);
  }

  return out;
};

export const __String_prototype_repeat = function (this: string, cnt: any) {
  const count: number = ecma262.ToIntegerOrInfinity(cnt);
  if (Porffor.fastOr(count < 0, count == Infinity)) throw new RangeError('Invalid count value');

  const thisLen: i32 = this.length * 2;
  if (thisLen == 0) return '';

  const out: string = Porffor.malloc(6 + thisLen * count);
  // sproutboat B16: doubling repeat
  const total: i32 = thisLen * count;
  if (total > 0) {
    Porffor.IR.copy(Porffor.IR.ptr(out) + 4, Porffor.IR.ptr(this) + 4, thisLen);
    let filled: i32 = thisLen;
    while (filled * 2 <= total) {
      Porffor.IR.copy(Porffor.IR.ptr(out) + 4 + filled, Porffor.IR.ptr(out) + 4, filled);
      filled *= 2;
    }
    if (filled < total) Porffor.IR.copy(Porffor.IR.ptr(out) + 4 + filled, Porffor.IR.ptr(out) + 4, total - filled);
  }

  Porffor.IR.storeI32(out, 0, this.length * count);
  return out;
};

export const __ByteString_prototype_repeat = function (this: bytestring, cnt: any) {
  const count: number = ecma262.ToIntegerOrInfinity(cnt);
  if (Porffor.fastOr(count < 0, count == Infinity)) throw new RangeError('Invalid count value');

  const thisLen: i32 = this.length;
  if (thisLen == 0) return '';

  const out: bytestring = Porffor.malloc(6 + thisLen * count);
  // sproutboat B16: doubling repeat
  const total: i32 = thisLen * count;
  if (total > 0) {
    Porffor.IR.copy(Porffor.IR.ptr(out) + 4, Porffor.IR.ptr(this) + 4, thisLen);
    let filled: i32 = thisLen;
    while (filled * 2 <= total) {
      Porffor.IR.copy(Porffor.IR.ptr(out) + 4 + filled, Porffor.IR.ptr(out) + 4, filled);
      filled *= 2;
    }
    if (filled < total) Porffor.IR.copy(Porffor.IR.ptr(out) + 4 + filled, Porffor.IR.ptr(out) + 4, total - filled);
  }

  Porffor.IR.storeI32(out, 0, thisLen * count);
  return out;
};

export const __Porffor_string_substringLike = (str: any, start: number, end: number) => {
  if (Porffor.type(str) == Porffor.TYPES.bytestring) {
    return Porffor.callThis(__ByteString_prototype_substring, str, start, end);
  }

  return Porffor.callThis(__String_prototype_substring, str, start, end);
};

export const __Porffor_string_indexOfLike = (str: any, searchString: any, position: any = 0) => {
  if (Porffor.type(str) == Porffor.TYPES.bytestring) {
    return Porffor.callThis(__ByteString_prototype_indexOf, str, searchString, position);
  }

  return Porffor.callThis(__String_prototype_indexOf, str, searchString, position);
};

export const __Porffor_string_emptyLike = (str: any) => __Porffor_string_substringLike(str, 0, 0);

export const __Porffor_string_getSubstitution = (str: any, match: any[], position: number, replacement: any) => {
  replacement = ecma262.ToString(replacement);

  let out: any = __Porffor_string_emptyLike(replacement);
  let i: i32 = 0;
  const len: i32 = replacement.length;

  while (i < len) {
    if (replacement.charCodeAt(i) != 36 || i + 1 >= len) {
      out = __Porffor_strcat(out, __Porffor_string_substringLike(replacement, i, i + 1));
      i++;
      continue;
    }

    const next: i32 = replacement.charCodeAt(i + 1);
    if (next == 36) {
      out = __Porffor_strcat(out, __Porffor_string_substringLike(replacement, i, i + 1));
      i += 2;
      continue;
    }

    if (next == 38) {
      const matchValue: any = match[0];
      out = __Porffor_strcat(out, matchValue);
      i += 2;
      continue;
    }

    if (next == 96) {
      out = __Porffor_strcat(out, __Porffor_string_substringLike(str, 0, position));
      i += 2;
      continue;
    }

    if (next == 39) {
      const matchValue: any = match[0];
      const matchLen: i32 = matchValue.length;
      const thisLen: i32 = str.length;
      out = __Porffor_strcat(out, __Porffor_string_substringLike(str, position + matchLen, thisLen));
      i += 2;
      continue;
    }

    if (next == 60) { // $<name>
      const groups: any = match.groups;
      if (groups !== undefined) {
        let gt: i32 = -1;
        for (let j: i32 = i + 2; j < len; j++) {
          if (replacement.charCodeAt(j) == 62) { gt = j; break; }
        }
        if (gt != -1) {
          const name: any = __Porffor_string_substringLike(replacement, i + 2, gt);
          const capture: any = Porffor.object.get(groups, name);
          if (capture !== undefined) out = __Porffor_strcat(out, ecma262.ToString(capture));
          i = gt + 1;
          continue;
        }
      }
    }

    if (next >= 48 && next <= 57) {
      let captureIndex: i32 = next - 48;
      let consumed: i32 = 2;

      if (i + 2 < len) {
        const nextNext: i32 = replacement.charCodeAt(i + 2);
        if (captureIndex != 0 && nextNext >= 48 && nextNext <= 57) {
          const twoDigit: i32 = captureIndex * 10 + nextNext - 48;
          if (twoDigit < match.length) {
            captureIndex = twoDigit;
            consumed = 3;
          }
        }
      }

      if (captureIndex > 0 && captureIndex < match.length) {
        const capture: any = match[captureIndex];
        if (capture !== undefined) out = __Porffor_strcat(out, capture);
        i += consumed;
        continue;
      }
    }

    out = __Porffor_strcat(out, __Porffor_string_substringLike(replacement, i, i + 1));
    i++;
  }

  return out;
};

export const __Porffor_array_getI32 = (arr: any[], index: i32): any => {
  return arr[index];
};

export const __Porffor_string_applyReplacer = (str: any, match: any[], position: number, replaceValue: any) => {
  if (Porffor.type(replaceValue) == Porffor.TYPES.function) {
    const len: i32 = match.length;
    const m0: any = __Porffor_array_getI32(match, 0);
    if (len <= 1) return ecma262.ToString(replaceValue(m0, position, str));
    const m1: any = __Porffor_array_getI32(match, 1);
    if (len == 2) return ecma262.ToString(replaceValue(m0, m1, position, str));
    const m2: any = __Porffor_array_getI32(match, 2);
    if (len == 3) return ecma262.ToString(replaceValue(m0, m1, m2, position, str));
    const m3: any = __Porffor_array_getI32(match, 3);
    if (len == 4) return ecma262.ToString(replaceValue(m0, m1, m2, m3, position, str));
    const m4: any = __Porffor_array_getI32(match, 4);
    if (len == 5) return ecma262.ToString(replaceValue(m0, m1, m2, m3, m4, position, str));

    throw new RangeError('String.prototype.replace callback supports up to 4 capture groups');
  }

  return __Porffor_string_getSubstitution(str, match, position, replaceValue);
};

export const __Porffor_string_replace = (str: any, searchValue: any, replaceValue: any) => {
  if (Porffor.object.isObject(searchValue)) {
    const replacer: any = __Porffor_regex_getData(searchValue, Symbol.replace);
    if (Porffor.comptime.flag`hasType.regexp`) {
      if (replacer === __RegExp_prototype_Symbol_replace) return Porffor.callThis(__RegExp_prototype_Symbol_replace, searchValue, str, replaceValue);
    }
    if (replacer != null) return Porffor.callThis(replacer, searchValue, str, replaceValue);
  }

  if ((Porffor.type(str) | 0b10000000) != Porffor.TYPES.bytestring) str = ecma262.ToString(str);
  const thisLen: i32 = str.length;
  searchValue = ecma262.ToString(searchValue);
  if (Porffor.type(replaceValue) != Porffor.TYPES.function) replaceValue = ecma262.ToString(replaceValue);
  const searchLen: i32 = searchValue.length;
  const matchIndex: i32 = searchLen == 0 ? 0 : __Porffor_string_indexOfLike(str, searchValue, 0);
  if (matchIndex == -1) return str;

  const match: any[] = Porffor.array.new(1);
  match[0] = searchValue;
  match.index = matchIndex;
  match.input = str;

  let out: any = __Porffor_string_emptyLike(str);
  out = __Porffor_strcat(out, __Porffor_string_substringLike(str, 0, matchIndex));
  out = __Porffor_strcat(out, __Porffor_string_applyReplacer(str, match, matchIndex, replaceValue));
  return __Porffor_strcat(out, __Porffor_string_substringLike(str, matchIndex + searchLen, thisLen));
};

export const __String_prototype_replace = function (this: any, searchValue: any, replaceValue: any) {
  if (this == null) throw new TypeError('String.prototype.replace called on null or undefined');
  return __Porffor_string_replace(this, searchValue, replaceValue);
};

export const __ByteString_prototype_replace = function (this: bytestring, searchValue: any, replaceValue: any) {
  return __Porffor_string_replace(this, searchValue, replaceValue);
};

export const __Porffor_string_replaceAll = (str: any, searchValue: any, replaceValue: any) => {
  if (Porffor.object.isObject(searchValue)) {
    if (__Porffor_regex_isRegExp(searchValue)) {
      const flags: any = __Porffor_regex_getData(searchValue, 'flags');
      if (flags == null) throw new TypeError('RegExp flags is null or undefined');
      if (!__Porffor_regex_flagIn(ecma262.ToString(flags), 103)) throw new TypeError('String.prototype.replaceAll called with a non-global RegExp argument');
    }

    const replacer: any = __Porffor_regex_getData(searchValue, Symbol.replace);
    if (Porffor.comptime.flag`hasType.regexp`) {
      if (replacer === __RegExp_prototype_Symbol_replace) return Porffor.callThis(__RegExp_prototype_Symbol_replace, searchValue, str, replaceValue);
    }
    if (replacer != null) return Porffor.callThis(replacer, searchValue, str, replaceValue);
  }

  if ((Porffor.type(str) | 0b10000000) != Porffor.TYPES.bytestring) str = ecma262.ToString(str);
  const thisLen: i32 = str.length;
  searchValue = ecma262.ToString(searchValue);
  if (Porffor.type(replaceValue) != Porffor.TYPES.function) replaceValue = ecma262.ToString(replaceValue);
  const searchLen: i32 = searchValue.length;
  const match: any[] = Porffor.array.new(1);
  match[0] = searchValue;
  match.input = str;

  // sproutboat #237: pieces joined once, not a strcat (full copy) per match.
  const pieces: any[] = Porffor.array.new(0);
  let appendIndex: i32 = 0;
  let searchIndex: i32 = 0;
  let matched: boolean = false;

  while (searchIndex <= thisLen) {
    const matchIndex: i32 = searchLen == 0 ? searchIndex : __Porffor_string_indexOfLike(str, searchValue, searchIndex);
    if (matchIndex == -1) break;

    matched = true;
    match.index = matchIndex;
    Porffor.array.fastPush(pieces, __Porffor_string_substringLike(str, appendIndex, matchIndex));
    Porffor.array.fastPush(pieces, __Porffor_string_applyReplacer(str, match, matchIndex, replaceValue));

    appendIndex = matchIndex + searchLen;
    if (searchLen == 0) {
      if (matchIndex >= thisLen) break;
      searchIndex = matchIndex + 1;
      continue;
    }

    searchIndex = appendIndex;
  }

  if (!matched) return str;
  Porffor.array.fastPush(pieces, __Porffor_string_substringLike(str, appendIndex, thisLen));
  return Porffor.callThis(__Array_prototype_join, pieces, '');
};

export const __String_prototype_replaceAll = function (this: any, searchValue: any, replaceValue: any) {
  if (this == null) throw new TypeError('String.prototype.replaceAll called on null or undefined');
  return __Porffor_string_replaceAll(this, searchValue, replaceValue);
};

export const __ByteString_prototype_replaceAll = function (this: bytestring, searchValue: any, replaceValue: any) {
  return __Porffor_string_replaceAll(this, searchValue, replaceValue);
};



// regex split per spec: split between separator matches, splicing captures in, uses the engine's positions mode
export const __Porffor_string_splitRegex = (str: any, separator: any, limit: number, out: any[]): any[] => {
  let outLen: i32 = 0;
  const strType: i32 = Porffor.type(str);
  const thisLen: i32 = str.length;
  const nCaps: i32 = Porffor.IR.loadU16(separator, 6);
  const uv: boolean = (Porffor.IR.loadU16(separator, 4) & 0b10010000) != 0;

  if (thisLen == 0) {
    const e0: i32 = __Porffor_regex_interpretFrom(separator, str, 2, 0);
    out.length = 0;
    if (e0 == -1) Porffor.array.fastPush(out, str);
    return out;
  }

  let p: i32 = 0;
  let q: i32 = 0;
  while (q < thisLen) {
    const e: i32 = __Porffor_regex_interpretFrom(separator, str, 2, q);
    if (e == -1) break;
    const mi: i32 = __Porffor_regex_matchStart();
    if (mi >= thisLen) break; // only matches starting before the end split
    if (e == p) { // empty match at previous split point: advance
      q = mi + 1;
      if (uv && strType == Porffor.TYPES.string && q < thisLen) {
        const u1: i32 = Porffor.IR.loadU16(Porffor.IR.ptr(str) + (q - 1) * 2, 4);
        const u2: i32 = Porffor.IR.loadU16(Porffor.IR.ptr(str) + q * 2, 4);
        if (u1 >= 0xD800 && u1 <= 0xDBFF && u2 >= 0xDC00 && u2 <= 0xDFFF) q += 1;
      }
      continue;
    }

    outLen = Porffor.array.fastPush(out, __Porffor_regex_inputSubstring(str, strType, p, mi));
    if (outLen >= limit) { out.length = outLen; return out; }
    for (let k: i32 = 0; k < nCaps; k++) {
      const cs: i32 = __Porffor_regex_capsRead(k * 2);
      const ce: i32 = __Porffor_regex_capsRead(k * 2 + 1);
      if (cs != -1 && ce != -1) outLen = Porffor.array.fastPush(out, __Porffor_regex_inputSubstring(str, strType, cs, ce));
        else outLen = Porffor.array.fastPush(out, undefined);
      if (outLen >= limit) { out.length = outLen; return out; }
    }
    p = e;
    q = e;
  }

  outLen = Porffor.array.fastPush(out, __Porffor_regex_inputSubstring(str, strType, p, thisLen));
  out.length = outLen;
  return out;
};

export const __String_prototype_split = function (this: string, separator: any, limit: any) {
  if (Porffor.object.isObject(separator)) {
    const splitter: any = __Porffor_regex_getData(separator, Symbol.split);
    if (Porffor.comptime.flag`hasType.regexp`) {
      if (splitter === __RegExp_prototype_Symbol_split) return Porffor.callThis(__RegExp_prototype_Symbol_split, separator, this, limit);
    }
    if (splitter != null) return Porffor.callThis(splitter, separator, this, limit);
  }

  const out: any[] = Porffor.array.new(4);
  let outLen: i32 = 0;
  limit = __Porffor_regex_splitLimit(limit);

  if (Porffor.type(separator) == Porffor.TYPES.undefined) {
    if (limit == 0) {
      out.length = 0;
      return out;
    }

    out.length = 1;
    Porffor.IR.storeJv(Porffor.IR.loadI32(out, 4), 0, this);
    return out;
  }

  separator = ecma262.ToString(separator);
  if (limit == 0) {
    out.length = 0;
    return out;
  }

  const thisLen: i32 = this.length, sepLen: i32 = separator.length;
  if (sepLen == 1) {
    // fast path: single char separator
    const sepChar: i32 = separator.charCodeAt(0);
    let start: i32 = 0;
    for (let i: i32 = 0; i < thisLen; i++) {
      const x: i32 = Porffor.IR.loadU16(Porffor.IR.ptr(this) + i * 2, 4);

      if (x == sepChar) {
        if (outLen >= limit) {
          out.length = outLen;
          return out;
        }

        outLen = Porffor.array.fastPush(out, Porffor.callThis(__String_prototype_substring, this, start, i));
        start = i + 1;
      }
    }

    if (outLen < limit) {
      outLen = Porffor.array.fastPush(out, Porffor.callThis(__String_prototype_substring, this, start, thisLen));
    }
  } else if (sepLen == 0) {
    let produced: i32 = 0;
    for (let i = 0; i < thisLen && produced < limit; i++) {
      outLen = Porffor.array.fastPush(out, Porffor.callThis(__String_prototype_substring, this, i, i + 1));
      produced++;
    }
  } else if (sepLen > thisLen) {
    outLen = Porffor.array.fastPush(out, this);
  } else {
    let start: i32 = 0;
    const maxStart: i32 = thisLen - sepLen;
    let i: i32 = 0;
    while (i <= maxStart) {
      let match: boolean = true;
      for (let j: i32 = 0; j < sepLen; j++) {
        const x: i32 = Porffor.IR.loadU16(Porffor.IR.ptr(this) + (i + j) * 2, 4);
        if (x != separator.charCodeAt(j)) {
          match = false;
          break;
        }
      }

      if (match) {
        if (outLen >= limit) {
          out.length = outLen;
          return out;
        }

        outLen = Porffor.array.fastPush(out, Porffor.callThis(__String_prototype_substring, this, start, i));
        i += sepLen;
        start = i;
        continue;
      }

      i++;
    }

    if (outLen < limit) {
      outLen = Porffor.array.fastPush(out, Porffor.callThis(__String_prototype_substring, this, start, thisLen));
    }
  }

  out.length = outLen;
  return out;
};

export const __ByteString_prototype_split = function (this: bytestring, separator: any, limit: any) {
  if (Porffor.object.isObject(separator)) {
    const splitter: any = __Porffor_regex_getData(separator, Symbol.split);
    if (Porffor.comptime.flag`hasType.regexp`) {
      if (splitter === __RegExp_prototype_Symbol_split) return Porffor.callThis(__RegExp_prototype_Symbol_split, separator, this, limit);
    }
    if (splitter != null) return Porffor.callThis(splitter, separator, this, limit);
  }

  const out: any[] = Porffor.array.new(4);
  let outLen: i32 = 0;
  limit = __Porffor_regex_splitLimit(limit);

  if (Porffor.type(separator) == Porffor.TYPES.undefined) {
    if (limit == 0) {
      out.length = 0;
      return out;
    }

    out.length = 1;
    Porffor.IR.storeJv(Porffor.IR.loadI32(out, 4), 0, this);
    return out;
  }

  separator = ecma262.ToString(separator);
  if (limit == 0) {
    out.length = 0;
    return out;
  }

  const thisLen: i32 = this.length, sepLen: i32 = separator.length;
  if (sepLen == 1) {
    // fast path: single char separator
    const sepChar: i32 = separator.charCodeAt(0);
    let start: i32 = 0;
    for (let i: i32 = 0; i < thisLen; i++) {
      const x: i32 = Porffor.IR.loadU8(Porffor.IR.ptr(this) + i, 4);

      if (x == sepChar) {
        if (outLen >= limit) {
          out.length = outLen;
          return out;
        }

        outLen = Porffor.array.fastPush(out, Porffor.callThis(__ByteString_prototype_substring, this, start, i));
        start = i + 1;
      }
    }

    if (outLen < limit) {
      outLen = Porffor.array.fastPush(out, Porffor.callThis(__ByteString_prototype_substring, this, start, thisLen));
    }
  } else if (sepLen == 0) {
    let produced: i32 = 0;
    for (let i = 0; i < thisLen && produced < limit; i++) {
      outLen = Porffor.array.fastPush(out, Porffor.callThis(__ByteString_prototype_substring, this, i, i + 1));
      produced++;
    }
  } else if (sepLen > thisLen) {
    outLen = Porffor.array.fastPush(out, this);
  } else {
    let start: i32 = 0;
    const maxStart: i32 = thisLen - sepLen;
    let i: i32 = 0;
    while (i <= maxStart) {
      let match: boolean = true;
      for (let j: i32 = 0; j < sepLen; j++) {
        const x: i32 = Porffor.IR.loadU8(Porffor.IR.ptr(this) + i + j, 4);
        if (x != separator.charCodeAt(j)) {
          match = false;
          break;
        }
      }

      if (match) {
        if (outLen >= limit) {
          out.length = outLen;
          return out;
        }

        outLen = Porffor.array.fastPush(out, Porffor.callThis(__ByteString_prototype_substring, this, start, i));
        i += sepLen;
        start = i;
        continue;
      }

      i++;
    }

    if (outLen < limit) {
      outLen = Porffor.array.fastPush(out, Porffor.callThis(__ByteString_prototype_substring, this, start, thisLen));
    }
  }

  out.length = outLen;
  return out;
};


// todo: unicode normalization
export const __Porffor_string_normalizeForm = (form: any): void => {
  if (Porffor.type(form) == Porffor.TYPES.undefined) return;
  form = ecma262.ToString(form);
  if (form != 'NFC' && form != 'NFD' && form != 'NFKC' && form != 'NFKD') throw new RangeError('Invalid normalization form');
};

export const __String_prototype_normalize = function (this: string, form: any = undefined) {
  __Porffor_string_normalizeForm(form);
  return this;
};
export const __ByteString_prototype_normalize = function (this: bytestring, form: any = undefined) {
  __Porffor_string_normalizeForm(form);
  return this;
};


export const __String_prototype_localeCompare = function (this: string, compareString: any) {
  compareString = ecma262.ToString(compareString);

  const thisLen: i32 = this.length;
  const compareLen: i32 = compareString.length;
  const maxLen: i32 = thisLen > compareLen ? thisLen : compareLen;
  const thisPtr: i32 = Porffor.IR.ptr(this);
  const comparePtr: i32 = Porffor.IR.ptr(compareString);
  const thisString: boolean = Porffor.type(this) == Porffor.TYPES.string;
  const compareStringType: i32 = Porffor.type(compareString);
  const compareStringString: boolean = compareStringType == Porffor.TYPES.string;

  for (let i: i32 = 0; i < maxLen; i++) {
    const a: i32 = thisString ? Porffor.IR.loadU16(thisPtr + i * 2, 4) : Porffor.IR.loadU8(thisPtr + i, 4);
    const b: i32 = compareStringString ? Porffor.IR.loadU16(comparePtr + i * 2, 4) : Porffor.IR.loadU8(comparePtr + i, 4);

    if (a > b) return 1;
    if (b > a) return -1;
  }

  if (thisLen > compareLen) return 1;
  if (compareLen > thisLen) return -1;

  return 0;
};

export const __ByteString_prototype_localeCompare = function (this: bytestring, compareString: any) {
  compareString = ecma262.ToString(compareString);

  const thisLen: i32 = this.length;
  const compareLen: i32 = compareString.length;
  const maxLen: i32 = thisLen > compareLen ? thisLen : compareLen;
  const thisPtr: i32 = Porffor.IR.ptr(this);
  const comparePtr: i32 = Porffor.IR.ptr(compareString);
  const compareStringType: i32 = Porffor.type(compareString);
  const compareStringString: boolean = compareStringType == Porffor.TYPES.string;

  for (let i: i32 = 0; i < maxLen; i++) {
    const a: i32 = Porffor.IR.loadU8(thisPtr + i, 4);
    const b: i32 = compareStringString ? Porffor.IR.loadU16(comparePtr + i * 2, 4) : Porffor.IR.loadU8(comparePtr + i, 4);

    if (a > b) return 1;
    if (b > a) return -1;
  }

  if (thisLen > compareLen) return 1;
  if (compareLen > thisLen) return -1;

  return 0;
};


export const __String_prototype_isWellFormed = function (this: string) {
  let ptr: i32 = Porffor.IR.ptr(this);
  const endPtr: i32 = ptr + this.length * 2;
  while (ptr < endPtr) {
    const c1: i32 = Porffor.IR.loadU16(ptr, 4);

    if (Porffor.fastAnd(c1 >= 0xDC00, c1 <= 0xDFFF)) {
      // lone trailing surrogate, bad
      return false;
    }

    if (Porffor.fastAnd(c1 >= 0xD800, c1 <= 0xDBFF)) {
      // leading surrogate, peek if next is trailing
      const c2: i32 = ptr + 2 < endPtr ? Porffor.IR.loadU16(ptr + 2, 4) : 0;

      if (Porffor.fastAnd(c2 >= 0xDC00, c2 <= 0xDFFF)) {
        // next is trailing surrogate, skip it too
        ptr += 2;
      } else {
        // lone leading surrogate, bad
        return false;
      }
    }

    ptr += 2;
  }

  return true;
};

export const __ByteString_prototype_isWellFormed = function (this: bytestring) {
  // bytestrings cannot have surrogates, so always true
  return true;
};

export const __String_prototype_toWellFormed = function (this: string) {
  const len: i32 = this.length;
  const out: string = Porffor.malloc(6 + len * 2);
  Porffor.IR.copy(out, this, 4 + len * 2);

  let ptr: i32 = Porffor.IR.ptr(out);
  const endPtr: i32 = ptr + len * 2;
  while (ptr < endPtr) {
    const c1: i32 = Porffor.IR.loadU16(ptr, 4);

    if (Porffor.fastAnd(c1 >= 0xDC00, c1 <= 0xDFFF)) {
      // lone trailing surrogate, bad
      Porffor.IR.storeU16(ptr, 4, 0xFFFD);
    }

    if (Porffor.fastAnd(c1 >= 0xD800, c1 <= 0xDBFF)) {
      // leading surrogate, peek if next is trailing
      const c2: i32 = ptr + 2 < endPtr ? Porffor.IR.loadU16(ptr + 2, 4) : 0;

      if (Porffor.fastAnd(c2 >= 0xDC00, c2 <= 0xDFFF)) {
        // next is trailing surrogate, skip it too
        ptr += 2;
      } else {
        // lone leading surrogate, bad
        Porffor.IR.storeU16(ptr, 4, 0xFFFD);
      }
    }

    ptr += 2;
  }

  return out;
};

export const __ByteString_prototype_toWellFormed = function (this: bytestring) {
  // bytestrings cannot have surrogates, so just return this
  return this;
};


// 22.1.3.29 String.prototype.toString ()
// https://tc39.es/ecma262/#sec-string.prototype.tostring
export const __String_prototype_toString = function (this: any) {
  // 1. Return ? ThisStringValue(this value).
  if (Porffor.type(this) == Porffor.TYPES.stringobject) return this as string;
  if ((Porffor.type(this) | 0b10000000) != Porffor.TYPES.bytestring) throw new TypeError('String.prototype.toString requires that \'this\' be a String');
  return this;
};

export const __ByteString_prototype_toString = function (this: bytestring) {
  // 1. Return ? ThisStringValue(this value).
  return this;
};

export const __String_prototype_toLocaleString = function (this: string) { return Porffor.callThis(__String_prototype_toString, this); };
export const __ByteString_prototype_toLocaleString = function (this: bytestring) { return Porffor.callThis(__ByteString_prototype_toString, this); };

// 22.1.3.35 String.prototype.valueOf ()
// https://tc39.es/ecma262/#sec-string.prototype.valueof
export const __String_prototype_valueOf = function (this: any) {
  // 1. Return ? ThisStringValue(this value).
  if (Porffor.type(this) == Porffor.TYPES.stringobject) return this as string;
  if ((Porffor.type(this) | 0b10000000) != Porffor.TYPES.bytestring) throw new TypeError('String.prototype.valueOf requires that \'this\' be a String');
  return this;
};

export const __ByteString_prototype_valueOf = function (this: bytestring) {
  // 1. Return ? ThisStringValue(this value).
  return this;
};

export const __String_prototype_Symbol_iterator = function (this: string) {
  return __Porffor_StringIterator_new(this);
};
