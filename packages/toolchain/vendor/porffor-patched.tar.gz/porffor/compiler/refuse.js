import './prefs.js';

// sproutboat: code compiled on someone else's behalf never names the compiler's own intrinsics.
//
// `Porffor.c` puts its template text verbatim into the C output, and `Porffor.IR`, `Porffor.malloc`, `Porffor.link`,
// `Porffor.dlopen` and the global `__Porffor_*` / `__<Builtin>_*` functions are as raw. All of them are resolved
// statically, from identifiers, so this refuses the identifiers: in every module the platform did not write (see
// `isUntrusted` in modules.js) and in the code of every compile-time `eval`, `Function` and `vm` source. The check is on
// the AST, so strings and comments never trigger it, and unicode escapes are already decoded by the parser.
//
// `--sb-allow-intrinsics` (exactly that flag) switches it off: the platform's own template compile, runtime development.
export const REFUSED_MARK = 'SB_INPUT_REFUSED';
// What a builder reports (TOOLCHAIN.json `intrinsic_refusal`): the feature level of this tree. @sproutboat/toolchain's INTRINSIC_REFUSAL says what is expected.
export const REFUSAL_LEVEL = 1;

// `Porffor` itself, and the builtin namespaces' dunder names: __Porffor_malloc, __Array_prototype_join,
// __ecma262_ToString, __Uint8Array___proto__, __RegExp_$1$get ... A name that is only a flag, `__DEV__`, `__proto__`,
// `__esModule`, `__dirname`, has no letter after its second underscore and passes.
const INTRINSIC = /^__[A-Za-z][A-Za-z0-9]*_(?!_*$)/;
// Only a name in a builtin namespace is an intrinsic: the first segment after `__` is the namespace of a builtin or a standard global. Anything
// else with the same shape is the program's own name and passes: Rolldown's `__toESMCache_node`, React's `__COMPILER_RUNTIME` and
// `__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED`, zod's `__zod_*`, rou3's `__rou3_*`, kysely's `__kysely_*`, partyserver's
// `__unsafe_ensureInitialized`. The exhaustive test in packages/toolchain refuses every builtin dunder name of the shipped tree, so a namespace a
// Porffor upgrade adds fails that test until it is listed here.
const INTRINSIC_NAMESPACES = new Set([ 'Array', 'ArrayBuffer', 'AsyncDisposableStack', 'Atomics', 'BigInt', 'Boolean', 'ByteString', 'DataView', 'Date', 'DisposableStack', 'Error', 'FinalizationRegistry', 'Function', 'Iterator', 'JSON', 'Map', 'Math', 'Number', 'Object', 'Porffor', 'Promise', 'Proxy', 'Reflect', 'RegExp', 'Set', 'SharedArrayBuffer', 'String', 'Symbol', 'TypedArray', 'Uint8Array', 'WeakMap', 'WeakRef', 'WeakSet', 'console', 'ecma262', 'performance', 'AggregateError', 'EvalError', 'RangeError', 'ReferenceError', 'SyntaxError', 'TypeError', 'URIError', 'Int8Array', 'Uint8ClampedArray', 'Int16Array', 'Uint16Array', 'Int32Array', 'Uint32Array', 'Float16Array', 'Float32Array', 'Float64Array', 'BigInt64Array', 'BigUint64Array', 'Intl', 'Temporal', 'globalThis', 'SuppressedError', 'navigator' ]);
export const isIntrinsicName = name => name === 'Porffor' || (INTRINSIC.test(name) && INTRINSIC_NAMESPACES.has(name.slice(2, name.indexOf('_', 2))));

const SKIP = new Set([ 'start', 'end', 'loc', 'range' ]);

const find = node => {
  const stack = [ node ];
  while (stack.length) {
    const n = stack.pop();
    if (n === null || typeof n !== 'object') continue;
    if (Array.isArray(n)) { for (let i = 0; i < n.length; i++) stack.push(n[i]); continue; }
    if (n.type === 'Identifier' && typeof n.name === 'string' && isIntrinsicName(n.name)) return n;
    for (const key in n) {
      if (key[0] === '_' || SKIP.has(key)) continue;
      const v = n[key];
      if (v !== null && typeof v === 'object') stack.push(v);
    }
  }
  return null;
};

/** Throws when `ast` names an intrinsic. `what` says whose code it was (a module path, `eval`, `Function`, `vm`). Returns `ast`. */
export const refuseIntrinsics = (ast, what) => {
  if (Prefs.sbAllowIntrinsics === true) return ast;
  const hit = find(ast);
  if (hit) {
    const at = typeof hit.start === 'number' ? ` at offset ${hit.start}` : '';
    throw new Error(`${REFUSED_MARK}: ${what} uses the compiler's internal \`${hit.name}\`${at}. Porffor.c and the other Porffor intrinsics (Porffor.IR, Porffor.malloc, __Porffor_*, __<Builtin>_*) are not available here`);
  }
  return ast;
};
